"""Alternate paired issue 60 checks against two persistent worker processes."""

import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

from benchmark import DATABASE, NATIVE_CASES, ROOT, digest, emit


def main(args):
    args.output.mkdir(exist_ok=False)
    curve_cases = json.loads(args.cases_json.read_text()) if args.curves else []
    metadata = {"database_sha256": digest(DATABASE), "runs": args.runs, "warmups": args.warmups, "cases": NATIVE_CASES + curve_cases, "seeds": args.seeds, "budgets_overridden": False}
    rows = []
    with (args.output / "samples.jsonl").open("w", encoding="utf-8") as stream:
        for seed in args.seeds:
            env = {**os.environ, "PYTHONHASHSEED": str(seed), "IP_HASH_SECRET": "issue60-benchmark", "ADMIN_API_KEY": "issue60-benchmark", "DATABASE_URL": f"sqlite:///file:{DATABASE}?mode=ro&uri=true", "DISABLE_BG_MIGRATE": "1", "EFTFORGE_EXPLORE_WORKERS": "8", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
            processes = {}
            logs = []
            try:
                for revision, backend in (("baseline", ROOT / ".issue60-audit/baseline/backend"), ("candidate", ROOT / "backend")):
                    log = (args.output / f"{revision}-seed{seed}.stderr.log").open("w")
                    logs.append(log)
                    process = subprocess.Popen([sys.executable, str(ROOT / ".issue60-audit/benchmark.py"), "--worker", "--backend", str(backend.resolve())], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, env=env)
                    processes[revision] = process
                    header = process.stdout.readline()
                    if not header:
                        raise RuntimeError(f"Worker failed to start; inspect {revision}-seed{seed}.stderr.log")
                    metadata[f"{revision}:seed{seed}"] = json.loads(header)
                (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
                cases = [{"kind": "native", **case} for case in NATIVE_CASES]
                if seed == 0:
                    cases.extend({"kind": "curve", **case} for case in curve_cases)
                for iteration in range(args.warmups + args.runs):
                    for case_index, case in enumerate(cases):
                        revisions = ("baseline", "candidate") if (iteration + case_index) % 2 == 0 else ("candidate", "baseline")
                        for revision in revisions:
                            process = processes[revision]
                            emit(case, process.stdin)
                            line = process.stdout.readline()
                            if not line:
                                raise RuntimeError(f"Worker failed during {case['id']}; inspect {revision}-seed{seed}.stderr.log")
                            row = {"seed": seed, "round": iteration, "phase": "warmup" if iteration < args.warmups else "measured", "revision": revision, **json.loads(line)}
                            if row["invalid_build_checks"]:
                                raise RuntimeError(f"Invalid returned build: {case['id']} {revision} seed{seed}")
                            if row["wall_ms"] > 31000:
                                raise RuntimeError(f"Exceeded request budget by over one second: {case['id']}")
                            rows.append(row)
                            emit(row, stream)
                            emit({key: row[key] for key in ("seed", "round", "phase", "revision", "case_id", "wall_ms", "status", "invalid_build_checks")})
            finally:
                for process in processes.values():
                    if process.poll() is None:
                        process.stdin.close()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
                for log in logs:
                    log.close()
    if digest(DATABASE) != metadata["database_sha256"]:
        raise RuntimeError("Database changed during benchmark")
    (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    summary = {}
    for row in rows:
        if row["phase"] != "measured":
            continue
        key = f"{row['case_id']}:seed{row['seed']}"
        if key in summary:
            continue
        group = [item for item in rows if item["case_id"] == row["case_id"] and item["seed"] == row["seed"] and item["phase"] == "measured"]
        entry = {}
        for revision in ("baseline", "candidate"):
            subset = [item for item in group if item["revision"] == revision]
            entry[revision] = {"n": len(subset), "wall_ms_median": statistics.median(item["wall_ms"] for item in subset), "wall_ms_range": [min(item["wall_ms"] for item in subset), max(item["wall_ms"] for item in subset)], "invalid_build_checks": sum(item["invalid_build_checks"] for item in subset), "statuses": [item["status"] for item in subset], "semantic_sha256": [item["semantic_sha256"] for item in subset]}
            if row["kind"] == "native":
                entry[revision].update(recoil_v=[item["stats"]["recoil_vertical"] for item in subset if item.get("stats")], true_ergo_delta=[item["stats"]["true_ergo_delta"] for item in subset if item.get("stats")], native_solve_count=[item.get("metrics", {}).get("solve_count") for item in subset])
            else:
                entry[revision].update(point_count=[item["point_count"] for item in subset], complete=[item["complete"] for item in subset], solve_count=[item["solve_count"] for item in subset], attempt_statuses=[item["attempt_statuses"] for item in subset])
        entry["wall_ms_ratio"] = entry["candidate"]["wall_ms_median"] / entry["baseline"]["wall_ms_median"]
        pairs = [(next(item for item in group if item["revision"] == "baseline" and item["round"] == iteration), next(item for item in group if item["revision"] == "candidate" and item["round"] == iteration)) for iteration in sorted({item["round"] for item in group})]
        entry["equal_output_pairs"] = sum(before["semantic_sha256"] == after["semantic_sha256"] for before, after in pairs)
        summary[key] = entry
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--warmups", type=int, default=1)
    parser.add_argument("--curves", action="store_true")
    parser.add_argument("--cases-json", type=Path, default=ROOT / ".issue60-audit/bench_cases.json")
    main(parser.parse_args())
