"""Audit issue 60 against persistent subprocesses and a read-only item database."""

import argparse
from dataclasses import asdict, replace
import gc
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
DATABASE = ROOT / "backend/tarkov.db"
NATIVE_BASE = {
    "selected_ammo_id": "54527a984bdc2d4e668b4567",
    "assume_full_mag": True,
    "min_mag_capacity": 60,
    "game_mode": "pvp",
    "use_tchebycheff": False,
}
NATIVE_CASES = [
    {"id": "m4_floor_minus522", "params": {**NATIVE_BASE, "min_true_ergo_delta": -5.22}},
    {"id": "m4_prevent_overswing", "params": {**NATIVE_BASE, "prevent_overswing": True}},
]


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def semantic(value):
    if isinstance(value, dict):
        return {key: semantic(item) for key, item in value.items() if key not in ("metrics", "processing_ms", "prepare_ms")}
    if isinstance(value, list):
        return [semantic(item) for item in value]
    return value


def emit(value, stream=sys.stdout):
    stream.write(json.dumps(value, allow_nan=False) + "\n")
    stream.flush()


def worker(args):
    protocol = os.fdopen(os.dup(sys.stdout.fileno()), "w", encoding="utf-8", buffering=1)
    os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
    sys.path.insert(0, str(args.backend.resolve()))
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session
    from models_items import Item
    from optimizer import explore, milp, solver
    from stats import _compute_stats, apply_full_mag_ammo, full_mag_ammo_weight

    if explore.EXPLORE_TIME_LIMIT_SECONDS != 30 or milp.SOLVE_TIME_LIMIT_SECONDS != 30:
        raise ValueError("Require the production 30-second budgets")
    engine = create_engine(f"sqlite:///file:{DATABASE}?mode=ro&uri=true")
    emit({"workers": explore.EXPLORE_WORKERS, "budget_seconds": 30, "source_hashes": {path.name: digest(path) for path in sorted((args.backend / "optimizer").glob("*.py"))}, "stats_sha256": digest(args.backend / "stats.py")}, protocol)
    original_optimize = explore.optimize_weapon
    for line in sys.stdin:
        request = json.loads(line)
        gc.collect()
        params = solver.OptimizeParams(**request["params"])
        calls = []
        with Session(engine) as db:
            def capture(*positional, **keywords):
                result = original_optimize(*positional, **keywords)
                calls.append((positional[2], result))
                return result

            explore.optimize_weapon = capture
            started = time.perf_counter()
            if request["kind"] == "native":
                prepared = solver.prepare_optimize_weapon(db, "5447a9cd4bdc2dbd208b4567", params)
                prepared.local_price_cleanup = True
                prepared.warm(db, params)
                prepare_ms = (time.perf_counter() - started) * 1000
                started = time.perf_counter()
                result = solver.optimize_weapon(db, prepared.weapon_id, params, objective_axis="recoil", prepared=prepared)
                elapsed = (time.perf_counter() - started) * 1000
                calls.append((params, result))
                events = []
                weapon = prepared.weapon
                mods = prepared.mods
            else:
                events = list(explore.explore_weapon_stream(db, request["weapon"], params, request["tradeoff"], request["steps"]))
                elapsed = (time.perf_counter() - started) * 1000
                result = events[-1]["data"]
                prepare_ms = result.get("prepare_ms", 0)
                weapon = db.get(Item, request["weapon"])
                ids = set().union(*(set(build.get("selected_items", ())) for _, build in calls))
                mods = {iid: db.get(Item, iid) for iid in ids}
            audits = []
            for call_params, build in calls:
                audit = {"status": build["status"], "termination": build.get("termination", {}), "metrics": build.get("metrics", {}), "params": asdict(call_params)}
                if build["status"] in ("optimal", "feasible"):
                    selected = build["selected_items"]
                    expected = _compute_stats(weapon, selected, mods, call_params.strength_level, call_params.equip_ergo_modifier)
                    ammo = db.get(Item, call_params.selected_ammo_id) if call_params.assume_full_mag and call_params.selected_ammo_id else None
                    ubgl = db.get(Item, call_params.selected_ubgl_ammo_id) if call_params.assume_full_mag and call_params.selected_ubgl_ammo_id else None
                    apply_full_mag_ammo(expected, {iid: mods[iid] for iid in selected}, ammo, ubgl, call_params.strength_level, call_params.equip_ergo_modifier)
                    checks = {"stats_match_builder": expected == build["final_stats"]}
                    raw_ergo = (weapon.base_ergonomics or 0) + sum(mods[iid].ergonomics_modifier or 0 for iid in selected)
                    recoil_modifier = sum(mods[iid].recoil_modifier or 0 for iid in selected)
                    raw_weight = (weapon.weight or 0) + sum((mods[iid].weight or 0) + full_mag_ammo_weight(mods[iid], ammo, ubgl) for iid in selected)
                    for name, actual, lower in (("min_ergonomics", raw_ergo, True), ("max_ergonomics", raw_ergo, False), ("max_recoil_v", (weapon.recoil_vertical or 0) * (1 + recoil_modifier), False), ("max_recoil_sum", ((weapon.recoil_vertical or 0) + (weapon.recoil_horizontal or 0)) * (1 + recoil_modifier), False), ("max_weight", raw_weight, False)):
                        bound = getattr(call_params, name)
                        if bound is not None:
                            checks[name] = actual + 1e-7 >= bound if lower else actual <= bound + 1e-7
                    checks["include_items"] = set(call_params.include_items or ()) <= set(selected)
                    checks["exclude_items"] = not set(call_params.exclude_items or ()) & set(selected)
                    if call_params.prevent_overswing:
                        checks["prevent_overswing"] = not expected["overswing"]
                    if call_params.min_true_ergo_delta is not None:
                        checks["min_true_ergo_delta"] = expected["true_ergo_delta"] >= call_params.min_true_ergo_delta - 1e-7
                    if call_params.min_mag_capacity:
                        checks["min_mag_capacity"] = max((mods[iid].magazine_capacity or 0 for iid in selected), default=0) >= call_params.min_mag_capacity
                    audit.update(stats=build["final_stats"], checks=checks, selected=selected, price=build.get("grand_total_rub"))
                audits.append(audit)
            if request["kind"] == "native":
                output = semantic(result)
                row = {"status": result["status"], "stats": result.get("final_stats"), "price": result.get("grand_total_rub"), "termination": result.get("termination"), "metrics": result.get("metrics", {})}
            else:
                output = semantic(events)
                row = {"status": result["status"], "complete": result["complete"], "point_count": len(result["points"]), "solve_count": result["solve_count"], "reused_count": result.get("reused_count", 0), "points": [{key: point.get(key) for key in ("price", "ergo", "true_ergo_delta", "recoil_v")} for point in result["points"]]}
            payload = json.dumps(output, sort_keys=True, separators=(",", ":"), allow_nan=False)
            emit({"case_id": request["id"], "kind": request["kind"], "wall_ms": elapsed, "prepare_ms": prepare_ms, "semantic_sha256": hashlib.sha256(payload.encode()).hexdigest(), "invalid_build_checks": sum(not all(audit.get("checks", {}).values()) for audit in audits), "attempt_statuses": {status: sum(audit["status"] == status for audit in audits) for status in sorted({audit["status"] for audit in audits})}, **row, "audits": audits, "events": output if request["kind"] == "curve" else []}, protocol)
    engine.dispose()


def controller(args):
    curve_cases = json.loads((ROOT / ".issue60-audit/bench_cases.json").read_text()) if args.curves else []
    args.output.mkdir(exist_ok=False)
    metadata = {"database_sha256": digest(DATABASE), "runs": args.runs, "warmups": args.warmups, "revision": args.revision, "seeds": args.seeds, "curves": curve_cases}
    records = []
    with (args.output / "samples.jsonl").open("w", encoding="utf-8") as stream:
        for seed in args.seeds:
            env = {**os.environ, "PYTHONHASHSEED": str(seed), "IP_HASH_SECRET": "issue60-benchmark", "ADMIN_API_KEY": "issue60-benchmark", "DATABASE_URL": f"sqlite:///file:{DATABASE}?mode=ro&uri=true", "DISABLE_BG_MIGRATE": "1", "EFTFORGE_EXPLORE_WORKERS": "8", "OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
            with (args.output / f"seed{seed}.stderr.log").open("w") as log:
                process = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "--worker", "--backend", str(args.backend.resolve())], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, env=env)
                try:
                    header = process.stdout.readline()
                    if not header:
                        raise RuntimeError(f"Worker failed to start; inspect seed{seed}.stderr.log")
                    metadata[str(seed)] = json.loads(header)
                    cases = [{"kind": "native", **case} for case in NATIVE_CASES]
                    if seed == 0:
                        cases.extend({"kind": "curve", **case} for case in curve_cases)
                    for iteration in range(args.warmups + args.runs):
                        for case in cases:
                            emit(case, process.stdin)
                            line = process.stdout.readline()
                            if not line:
                                raise RuntimeError(f"Worker failed during {case['id']}; inspect seed{seed}.stderr.log")
                            row = {"seed": seed, "round": iteration, "phase": "warmup" if iteration < args.warmups else "measured", "revision": args.revision, **json.loads(line)}
                            records.append(row)
                            emit(row, stream)
                            emit({key: row[key] for key in ("seed", "round", "phase", "case_id", "wall_ms", "status", "invalid_build_checks")})
                finally:
                    if process.poll() is None:
                        process.stdin.close()
                        try:
                            process.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=5)
    if digest(DATABASE) != metadata["database_sha256"]:
        raise RuntimeError("Database changed during benchmark")
    (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    summary = {}
    for row in records:
        if row["phase"] != "measured":
            continue
        key = f"{row['case_id']}:seed{row['seed']}"
        rows = [item for item in records if item["case_id"] == row["case_id"] and item["seed"] == row["seed"] and item["phase"] == "measured"]
        summary[key] = {"n": len(rows), "median_wall_ms": statistics.median(item["wall_ms"] for item in rows), "range_wall_ms": [min(item["wall_ms"] for item in rows), max(item["wall_ms"] for item in rows)], "invalid_build_checks": sum(item["invalid_build_checks"] for item in rows), "status": [item["status"] for item in rows], "semantic_sha256": [item["semantic_sha256"] for item in rows]}
        if row["kind"] == "native":
            summary[key].update(recoil_v=[item["stats"].get("recoil_vertical") if item["stats"] else None for item in rows], stats=[item["stats"] for item in rows], native_solve_count=[item.get("metrics", {}).get("solve_count") for item in rows])
        else:
            summary[key].update(point_count=[item["point_count"] for item in rows], complete=[item["complete"] for item in rows], solve_count=[item["solve_count"] for item in rows], attempt_statuses=[item["attempt_statuses"] for item in rows])
    (args.output / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--backend", type=Path, required=True)
    parser.add_argument("--revision", default="baseline")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--warmups", type=int, default=1)
    parser.add_argument("--curves", action="store_true")
    options = parser.parse_args()
    if options.worker:
        worker(options)
    else:
        controller(options)
