import json
import os
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
os.environ.update(IP_HASH_SECRET="issue60-audit", ADMIN_API_KEY="issue60-audit", DATABASE_URL=f"sqlite:///file:{root / 'backend/tarkov.db'}?mode=ro&uri=true", EFTFORGE_EXPLORE_WORKERS="1", OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")
from dataclasses import replace
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from optimizer.solver import OptimizeParams, optimize_weapon, prepare_optimize_weapon

params = OptimizeParams(selected_ammo_id="54527a984bdc2d4e668b4567", assume_full_mag=True, min_mag_capacity=60, game_mode="pvp", use_tchebycheff=False)
engine = create_engine(os.environ["DATABASE_URL"])
with Session(engine) as db:
    for changes in ({"min_true_ergo_delta": -5.22}, {"prevent_overswing": True}):
        variant = replace(params, **changes)
        prepared = prepare_optimize_weapon(db, "5447a9cd4bdc2dbd208b4567", variant)
        prepared.local_price_cleanup = True
        start = time.perf_counter()
        result = optimize_weapon(db, prepared.weapon_id, variant, objective_axis="recoil", prepared=prepared)
        print(json.dumps({"params":changes,"status":result["status"],"stats":result.get("final_stats"),"price":result.get("grand_total_rub"),"selected":result.get("selected_items"),"metrics":result.get("metrics"),"wall_ms":(time.perf_counter()-start)*1000}), flush=True)
