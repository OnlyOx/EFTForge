import json
import math
import os
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / "backend"))
os.environ.update(
    IP_HASH_SECRET="issue60-grid",
    ADMIN_API_KEY="issue60-grid",
    DATABASE_URL=f"sqlite:///file:{root / 'backend/tarkov.db'}?mode=ro&uri=true",
    EFTFORGE_EXPLORE_WORKERS="1",
    OPENBLAS_NUM_THREADS="1",
    OMP_NUM_THREADS="1",
)

from dataclasses import replace
from sqlalchemy import create_engine
from sqlalchemy.orm import Session
from optimizer.solver import OptimizeParams, optimize_weapon, prepare_optimize_weapon
from optimizer.ted_outer import TedOuterConstraint
import numpy as np
from scipy.optimize import milp, Bounds

original_add = TedOuterConstraint.add_cut
original_fill = TedOuterConstraint.fill_assignment
segments = int(sys.argv[1])
mode = sys.argv[2] if len(sys.argv) > 2 else "onehot"
use_lp = len(sys.argv) > 3 and sys.argv[3] == "lp"
use_tight_m = use_lp or (len(sys.argv) > 3 and sys.argv[3] == "tight")
original_row = TedOuterConstraint._row


def tight_row(self, slope, intercept):
    coefficients, rhs, big_m = original_row(self, slope, intercept)
    bound = max(0, intercept - max(0, self.margin) + slope * self.weight_upper_bound)
    return coefficients, rhs, min(big_m, bound + 1e-9 * max(1, abs(bound)))


if use_tight_m:
    TedOuterConstraint._row = tight_row


def add_cut(self, selected):
    if mode == "hybrid" and self.margin is not None and self.margin > 0:
        if not self.grid:
            self._add_necessary_rows()
            self.grid = [(0, 0, -1e100)]
            upper = self.weight_upper_bound
            if upper > 3:
                slope, intercept = 100 / upper, self.margin - 300 / upper
                coefficients, rhs, _big_m = self._row(slope, intercept)
                self.cb.ge(coefficients, rhs)
            original_add(self, selected)
            return True
        return original_add(self, selected)
    if not self.grid and self.margin is not None and self.weight_upper_bound > 3:
        self._add_necessary_rows()
        if mode == "logglobal":
            upper = self.weight_upper_bound
            slope, intercept = 100 / upper, self.margin - 300 / upper
            coefficients, rhs, _big_m = self._row(slope, intercept)
            self.cb.ge(coefficients, rhs)
        if use_lp:
            objective = np.zeros(self.cb.n)
            for column, coefficient in self.weight_coefficients.items():
                objective[column] = -coefficient
            upper_bounds = np.ones(self.cb.n)
            upper_bounds[len(self.idx)] = 100
            for column, bound in self.cb.column_upper_bounds.items():
                upper_bounds[column] = bound
            started = time.perf_counter()
            result = milp(objective, constraints=self.cb.build(), bounds=Bounds(np.zeros(self.cb.n), upper_bounds), integrality=np.zeros(self.cb.n), options={"time_limit": .05})
            if result.success:
                self.weight_upper_bound = min(self.weight_upper_bound, self.weight_constant - result.fun + 1e-5)
                self.cb.le(self.weight_coefficients, self.weight_upper_bound - self.weight_constant)
            print(json.dumps({"lp_ms": (time.perf_counter() - started) * 1000, "upper": self.weight_upper_bound, "status": int(result.status)}), flush=True)
        upper = self.weight_upper_bound
        low, high = 1 / math.sqrt(3), 1 / math.sqrt(upper)
        points = [1 / (low + (high - low) * i / segments) ** 2 for i in range(segments + 1)]
        points[0], points[-1] = 3.0, upper
        if mode == "local":
            _ergo, anchor = self._point(selected)
            left, right = max(3, anchor - .75), min(upper, anchor + .75)
            middle = [left + (right - left) * i / (segments - 2) for i in range(segments - 1)]
            points = sorted(set([3, upper, anchor, *middle]))
        if mode in ("loganchor", "logglobal"):
            _ergo, anchor = self._point(selected)
            if 3 < anchor < upper:
                points = sorted(set([*points, anchor]))
        grid = []
        if mode == "disaggregated":
            lower = self.weight_constant + math.fsum(min(0, value) for value in self.weight_coefficients.values())
            if lower < 3:
                points.insert(0, lower)
            weight_row = dict(self.weight_coefficients)
            ergo_row = dict(self.ergo_coefficients)
            for a, b in zip(points, points[1:]):
                width = b - a
                slope = 0 if b <= 3 else 300 / (a * b)
                value = self.margin if a <= 3 else self.margin + 100 - 300 / a
                binary = self.cb.add_binary()
                continuous = self.cb.n
                self.cb.n += 1
                self.cb.column_upper_bounds[continuous] = width
                self.cb.le({continuous: 1, binary: -width}, 0)
                weight_row[binary], weight_row[continuous] = -a, -1
                ergo_row[binary], ergo_row[continuous] = -value, -slope
                grid.append((binary, continuous, a, b, slope, value))
            self.cb.eq({row[0]: 1 for row in grid}, 1)
            self.cb.eq(weight_row, -self.weight_constant)
            self.cb.ge(ergo_row, -self.ergo_constant)
        elif mode.startswith("log"):
            bits = [self.cb.add_binary() for _ in range((len(points) - 2).bit_length())]
            self.log_bits = tuple(bits)
            for code, (a, b) in enumerate(zip(points, points[1:])):
                slope, intercept = 300 / (a * b), self.margin + 100 - 300 / a - 300 / b
                coefficients, rhs, big_m = self._row(slope, intercept)
                for position, bit in enumerate(bits):
                    coefficients[bit] = -big_m if code & (1 << position) else big_m
                self.cb.ge(coefficients, rhs - big_m * code.bit_count())
                grid.append((code, slope, intercept))
            if len(grid) < 1 << len(bits):
                self.cb.le({bit: 1 << position for position, bit in enumerate(bits)}, len(grid) - 1)
        else:
            for a, b in zip(points, points[1:]):
                slope, intercept = 300 / (a * b), self.margin + 100 - 300 / a - 300 / b
                binary = self.cb.add_binary()
                coefficients, rhs, big_m = self._row(slope, intercept)
                coefficients[binary] = -big_m
                self.cb.ge(coefficients, rhs - big_m)
                grid.append((binary, slope, intercept))
            self.cb.eq({binary: 1 for binary, _slope, _intercept in grid}, 1)
        self.grid = tuple(grid)
        ergo, weight = self._point(selected)
        if mode != "disaggregated":
            envelope = min(slope * weight + intercept for _binary, slope, intercept in grid)
        else:
            chosen = next((row for row in grid if row[2] <= weight <= row[3]), None)
            envelope = chosen[5] + chosen[4] * (weight - chosen[2]) if chosen else -math.inf
        if ergo >= envelope - 1e-7:
            original_add(self, selected)
        return True
    return original_add(self, selected)


def fill(self, assignment):
    if mode.startswith("log") and self.grid:
        ergo = self.ergo_constant + math.fsum(v * assignment[c] for c, v in self.ergo_coefficients.items())
        weight = self.weight_constant + math.fsum(v * assignment[c] for c, v in self.weight_coefficients.items())
        chosen = min(self.grid, key=lambda row: row[1] * weight + row[2])
        for position, bit in enumerate(self.log_bits):
            assignment[bit] = float(bool(chosen[0] & (1 << position)))
        if ergo < chosen[1] * weight + chosen[2] - 1e-7:
            return False
        for binary, left_slope, left_intercept, right_slope, right_intercept in self.cuts:
            if ergo >= left_slope * weight + left_intercept - 1e-7:
                assignment[binary] = 0
            elif ergo >= right_slope * weight + right_intercept - 1e-7:
                assignment[binary] = 1
            else:
                return False
        return True
    if not original_fill(self, assignment):
        return False
    if self.grid:
        ergo = self.ergo_constant + math.fsum(v * assignment[c] for c, v in self.ergo_coefficients.items())
        weight = self.weight_constant + math.fsum(v * assignment[c] for c, v in self.weight_coefficients.items())
        if mode == "disaggregated":
            chosen = next((row for row in self.grid if row[2] - 1e-7 <= weight <= row[3] + 1e-7), None)
            if chosen is None:
                return False
            for binary, continuous, a, b, slope, value in self.grid:
                assignment[binary] = float(binary == chosen[0])
                assignment[continuous] = min(b - a, max(0, weight - a)) if binary == chosen[0] else 0
            return ergo >= chosen[5] + chosen[4] * (weight - chosen[2]) - 1e-7
        else:
            chosen = min(self.grid, key=lambda row: row[1] * weight + row[2])
            for binary, _slope, _intercept in self.grid:
                assignment[binary] = float(binary == chosen[0])
            return ergo >= chosen[1] * weight + chosen[2] - 1e-7
    return True


TedOuterConstraint.add_cut = add_cut
TedOuterConstraint.fill_assignment = fill
params = OptimizeParams(selected_ammo_id="54527a984bdc2d4e668b4567", assume_full_mag=True, min_mag_capacity=60, game_mode="pvp", use_tchebycheff=False)
engine = create_engine(os.environ["DATABASE_URL"])
with Session(engine) as db:
    for iteration in range(2):
        changes_list = [{"min_true_ergo_delta": float(sys.argv[4])}] if len(sys.argv) > 4 else ({"min_true_ergo_delta": -5.22}, {"prevent_overswing": True})
        for changes in changes_list:
            variant = replace(params, **changes)
            prepared = prepare_optimize_weapon(db, "5447a9cd4bdc2dbd208b4567", variant)
            prepared.local_price_cleanup = True
            prepared.warm(db, variant)
            start = time.perf_counter()
            result = optimize_weapon(db, prepared.weapon_id, variant, objective_axis="recoil", prepared=prepared)
            stats = result.get("final_stats", {})
            print(json.dumps({"segments": segments, "mode": mode, "iteration": iteration, "params": changes, "status": result["status"], "recoil": stats.get("recoil_vertical"), "ted": stats.get("true_ergo_delta"), "solves": result.get("metrics", {}).get("solve_count"), "wall_ms": (time.perf_counter() - start) * 1000}), flush=True)
