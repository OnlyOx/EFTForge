import asyncio
import base64
import contextlib
import hashlib
import hmac
import json
import logging
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

from fastapi import BackgroundTasks, FastAPI, Body, Depends, HTTPException, Header, Request
from fastapi.responses import JSONResponse, RedirectResponse, Response, StreamingResponse
from starlette.middleware.gzip import GZipMiddleware as GZIPMiddleware
from sqlalchemy import case, func, text
from sqlalchemy.orm import Session
from typing import Annotated, List, Literal, Optional

from database import SessionLocal, engine, Base
from models_items import Item
from models_slots import Slot
from models_slot_allowed import SlotAllowedItem
from models_traders import Trader
from models_item_offers import ItemOffer  # noqa: F401 - registers table with Base.metadata
from models_weapon_presets import WeaponDefaultPreset  # noqa: F401 - registers table with Base.metadata
from stats import _compute_stats, apply_full_mag_ammo
from compatibility import CompatibilityIndex
from combo_transport import ComboResponseFormat, combo_result_event, format_combo_result
import build_images
from build_images import build_image_key, loaded_image_key
from optimizer.solver import OptimizeParams
from optimizer.gunsmith import get_gunsmith_tasks
from optimizer.explore_request import ExploreRequest
from optimizer.process_runner import run_gunsmith, run_job, stream_explore
from optimizer.cancellation import SolveCancelled, SolveCancellationMiddleware, SolveStreamingResponse
from optimizer.compat_map import build_compatibility_map
from solver_cache_epoch import SolverCacheEpochTracker, read_solver_cache_epoch
from server_semaphore import server_semaphore
from catalog_cache import DATA_VERSION_HEADER, CatalogCacheMiddleware, code_stamp, make_data_version
from database_changelog import changelog_engine, ChangelogSessionLocal, ChangelogBase
from models_stat_changelog import StatChangeLog  # noqa: F401 - registers table with ChangelogBase.metadata

from database_ratings import ratings_engine, RatingsSessionLocal, RatingsBase
from models_ratings import AttachmentVote, AttachmentRating  # noqa: F401 - registers tables

from database_builds import builds_engine, BuildsSessionLocal, BuildsBase
from models_builds import (
    PublicBuild,
    PublicBuildAuthor,
    IPBan,
    PendingNotification,
    ServerAnnouncement,
    BuildVote,
    BuildRating,
    BuildComment,
)  # noqa: F401 - registers tables

from fastapi.middleware.cors import CORSMiddleware

from config import (
    CORS_ORIGINS,
    IP_HASH_SECRET,
    ADMIN_API_KEY,
    ENABLE_API_DOCS,
    TRUSTED_PROXY_IPS,
    RUNTIME_DIR,
    DESKTOP_MODE,
    OPTIMIZER_MAX_SOLVES,
)

_docs_url = "/docs" if ENABLE_API_DOCS else None
_redoc_url = "/redoc" if ENABLE_API_DOCS else None
_openapi_url = "/openapi.json" if ENABLE_API_DOCS else None

app = FastAPI(title="EFTForge API", docs_url=_docs_url, redoc_url=_redoc_url, openapi_url=_openapi_url)
app.add_middleware(SolveCancellationMiddleware)

# Recorded once at process start - clients use this to detect a backend restart
# and bypass their local update-check TTL so a fresh deploy is noticed immediately.
SERVER_START_TIME = int(time.time())

# Validation constants
STRENGTH_LEVEL_MIN = 0
STRENGTH_LEVEL_MAX = 51  # 0 = no skill, 51 = elite
EQUIP_ERGO_MIN = -1.0  # negative = armor/rig ergonomics penalty
EQUIP_ERGO_MAX = 1.0  # positive = ergonomics bonus
VALID_GAME_MODES = {"pvp", "pve", "pvpSeason"}

# Request complexity caps - generous for real clients, block abuse of the
# CPU-heavy calculation endpoints with arbitrarily large payloads.
MAX_INSTALLED_IDS = 300
MAX_CANDIDATE_IDS = 2000
MAX_COMBO_BATCH = 5000
MAX_IMAGE_ITEMS = 150
MAX_STATS_JSON_CHARS = 2000


def _cap_list(name: str, value: list, limit: int) -> None:
    if len(value) > limit:
        raise HTTPException(status_code=422, detail=f"{name} exceeds maximum length of {limit}")


app.add_middleware(GZIPMiddleware, minimum_size=500)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE"],
    allow_headers=["Content-Type", "X-Admin-Key", "X-Client-ID"],
    expose_headers=[DATA_VERSION_HEADER],
)

# Catalog GETs tagged with ?dv= become cacheable by EdgeOne and browsers (see
# catalog_cache.py). The lambdas read module state lazily, so names defined further
# down (the sync flags) are fine here.
_data_version = make_data_version(
    db_path=os.path.abspath(engine.url.database or ""),
    read_epoch=read_solver_cache_epoch,
    sync_running=lambda: _sync_running or os.path.exists(_SYNC_IN_PROGRESS_FILE),
    stamp=code_stamp(os.path.dirname(os.path.abspath(__file__))),
    extra=lambda: str(build_images.available()),
)
app.add_middleware(CatalogCacheMiddleware, data_version=_data_version)

if DESKTOP_MODE:
    # Picked up by the Tauri launcher and forwarded to the splash screen -
    # see backend/desktop_main.py and ui-shell/index.html.
    print("EFTFORGE_STATUS=preparing_database", flush=True)

Base.metadata.create_all(bind=engine)
RatingsBase.metadata.create_all(bind=ratings_engine)
BuildsBase.metadata.create_all(bind=builds_engine)
ChangelogBase.metadata.create_all(bind=changelog_engine)


def _migrate_builds_db():
    with builds_engine.connect() as conn:
        existing = {row[1] for row in conn.execute(text("PRAGMA table_info(public_builds)"))}
        if "ammo_id" not in existing:
            conn.execute(text("ALTER TABLE public_builds ADD COLUMN ammo_id TEXT"))
            conn.commit()
        if "is_rotating" not in existing:
            conn.execute(text("ALTER TABLE public_builds ADD COLUMN is_rotating INTEGER NOT NULL DEFAULT 0"))
            conn.commit()
        if "user_display_name" not in existing:
            conn.execute(text("ALTER TABLE public_builds ADD COLUMN user_display_name TEXT"))
            conn.commit()
        if "user_avatar_url" not in existing:
            conn.execute(text("ALTER TABLE public_builds ADD COLUMN user_avatar_url TEXT"))
            conn.commit()
        if "tags_json" not in existing:
            conn.execute(text("ALTER TABLE public_builds ADD COLUMN tags_json TEXT"))
            conn.commit()

        ann_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(server_announcements)"))}
        if "dismissible" not in ann_cols:
            conn.execute(text("ALTER TABLE server_announcements ADD COLUMN dismissible INTEGER NOT NULL DEFAULT 1"))
            conn.commit()

        comment_cols = {row[1] for row in conn.execute(text("PRAGMA table_info(build_comments)"))}
        if "user_display_name" not in comment_cols:
            conn.execute(text("ALTER TABLE build_comments ADD COLUMN user_display_name TEXT"))
            conn.commit()
        if "user_avatar_url" not in comment_cols:
            conn.execute(text("ALTER TABLE build_comments ADD COLUMN user_avatar_url TEXT"))
            conn.commit()

        # Indexes for hot query paths (create_all only adds them to new tables)
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_public_builds_ip_hash ON public_builds (ip_hash)"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_build_vote_created_at ON build_votes (created_at)"))
        conn.execute(text("CREATE INDEX IF NOT EXISTS ix_build_comments_ip_hash ON build_comments (ip_hash)"))
        conn.commit()


def _migrate_items_db():
    with engine.connect() as conn:
        existing = {row[1] for row in conn.execute(text("PRAGMA table_info(items)"))}
        if "task_unlock_id" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN task_unlock_id TEXT"))
            conn.commit()
        if "task_unlock_name" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN task_unlock_name TEXT"))
            conn.commit()
        if "task_unlock_name_zh" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN task_unlock_name_zh TEXT"))
            conn.commit()
        if "sighting_range" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN sighting_range INTEGER"))
            conn.commit()
        if "bare_image_512_link" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN bare_image_512_link TEXT"))
            conn.commit()
        if "accuracy_modifier" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN accuracy_modifier REAL"))
            conn.commit()
        if "base_image_link" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN base_image_link TEXT"))
            conn.commit()
        if "ammo_damage" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN ammo_damage INTEGER"))
            conn.commit()
        if "penetration_power" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN penetration_power INTEGER"))
            conn.commit()
        if "armor_damage" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN armor_damage INTEGER"))
            conn.commit()
        if "velocity" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN velocity REAL"))
            conn.commit()
        if "tracer" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN tracer INTEGER"))
            conn.commit()
        if "tracer_color" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN tracer_color TEXT"))
            conn.commit()
        if "ammo_type" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN ammo_type TEXT"))
            conn.commit()
        if "projectile_count" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN projectile_count INTEGER"))
            conn.commit()
        if "fragmentation_chance" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN fragmentation_chance REAL"))
            conn.commit()
        if "ricochet_chance" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN ricochet_chance REAL"))
            conn.commit()
        if "stack_max_size" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN stack_max_size INTEGER"))
            conn.commit()
        if "ammo_accuracy_modifier" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN ammo_accuracy_modifier REAL"))
            conn.commit()
        if "ammo_recoil_modifier" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN ammo_recoil_modifier REAL"))
            conn.commit()
        if "light_bleed_delta" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN light_bleed_delta REAL"))
            conn.commit()
        if "heavy_bleed_delta" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN heavy_bleed_delta REAL"))
            conn.commit()
        if "penetration_chance" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN penetration_chance REAL"))
            conn.commit()
        if "penetration_power_deviation" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN penetration_power_deviation REAL"))
            conn.commit()
        if "heat_factor" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN heat_factor REAL"))
            conn.commit()
        if "cooling_factor" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN cooling_factor REAL"))
            conn.commit()
        if "durability_burn_factor" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN durability_burn_factor REAL"))
            conn.commit()
        if "velocity_modifier" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN velocity_modifier REAL"))
            conn.commit()
        if "loudness" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN loudness INTEGER"))
            conn.commit()
        if "category_ids" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN category_ids TEXT"))
            conn.commit()
        if "attachment_category" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN attachment_category TEXT"))
            conn.commit()
        if "attachment_category_zh" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN attachment_category_zh TEXT"))
            conn.commit()
        if "fire_rate" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN fire_rate INTEGER"))
            conn.commit()
        if "recoil_damping_hand_rot" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_damping_hand_rot REAL"))
            conn.commit()
        if "recoil_return_path_damping" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_return_path_damping REAL"))
            conn.commit()
        if "recoil_return_path_offset" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_return_path_offset REAL"))
            conn.commit()
        if "recoil_stable_index_shot" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_stable_index_shot INTEGER"))
            conn.commit()
        if "recoil_stable_angle_step" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_stable_angle_step REAL"))
            conn.commit()
        if "recoil_stable_angle" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_stable_angle REAL"))
            conn.commit()
        if "recoil_pos_z_mult" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_pos_z_mult REAL"))
            conn.commit()
        if "recoil_center_y" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_center_y REAL"))
            conn.commit()
        if "recoil_center_z" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN recoil_center_z REAL"))
            conn.commit()
        if "penetration_damage_mod" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN penetration_damage_mod REAL"))
            conn.commit()
        if "malf_feed_chance" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN malf_feed_chance REAL"))
            conn.commit()
        if "misfire_chance" not in existing:
            conn.execute(text("ALTER TABLE items ADD COLUMN misfire_chance REAL"))
            conn.commit()


def _migrate_slots_db():
    with engine.connect() as conn:
        existing = {row[1] for row in conn.execute(text("PRAGMA table_info(slots)"))}
        if "slot_game_name" not in existing:
            conn.execute(text("ALTER TABLE slots ADD COLUMN slot_game_name TEXT"))
            conn.commit()
        if "required" not in existing:
            conn.execute(text("ALTER TABLE slots ADD COLUMN required BOOLEAN DEFAULT 0"))
            conn.commit()


def _migrate_item_offers_db():
    with engine.connect() as conn:
        existing = {row[1] for row in conn.execute(text("PRAGMA table_info(item_offers)"))}
        if "game_mode" not in existing:
            conn.execute(text("ALTER TABLE item_offers ADD COLUMN game_mode TEXT"))
            conn.commit()


if DESKTOP_MODE:
    print("EFTFORGE_STATUS=applying_updates", flush=True)

_migrate_builds_db()
_migrate_items_db()
_migrate_slots_db()
_migrate_item_offers_db()


# ---------------------------------------------------
# Language helpers
# ---------------------------------------------------


def _item_name(item, lang: str) -> str:
    return (item.name_zh or item.name) if lang == "zh" else item.name


def _item_short_name(item, lang: str) -> str:
    return (item.short_name_zh or item.short_name) if lang == "zh" else item.short_name


def _item_category(item, lang: str) -> Optional[str]:
    return (item.attachment_category_zh or item.attachment_category) if lang == "zh" else item.attachment_category


# Sights/scopes and tactical devices should always sort to the top of the mod-
# filter's category groups, regardless of display language - keyed on
# tarkov.dev's raw category ids (stable across locales) rather than the
# localized display name. Item.category_ids carries the item's full ancestor
# chain, so checking for the "Sights" parent id catches every sight/scope leaf
# category (Ironsight, Reflex sight, Scope, ...) without listing each one.
# Within the sight tiers: Scope leads, Ironsight trails (magnified/reflex
# optics are what players actually browse this list for).
_SCOPE_CATEGORY_ID = "55818ae44bdc2dde698b456c"
_SIGHTS_CATEGORY_ID = "5448fe7a4bdc2d6f028b456b"  # "Sights" (parent of all scope/sight leaf categories)
_IRONSIGHT_CATEGORY_ID = "55818ac54bdc2d5b648b456e"
_TACTICAL_DEVICE_CATEGORY_IDS = {
    "55818b084bdc2d5b648b4571",  # Flashlight
    "55818b164bdc2ddc698b456c",  # Comb. tact. device (flashlight/IR-laser combo units)
}


def _category_priority(item) -> int:
    ids = set((item.category_ids or "").split(","))
    if _SCOPE_CATEGORY_ID in ids:
        return 0
    if _IRONSIGHT_CATEGORY_ID in ids:
        return 2
    if _SIGHTS_CATEGORY_ID in ids:
        return 1
    if ids & _TACTICAL_DEVICE_CATEGORY_IDS:
        return 3
    return 4


# ---------------------------------------------------
# Database
# ---------------------------------------------------


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_ratings_db():
    db = RatingsSessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_builds_db():
    db = BuildsSessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_changelog_db():
    db = ChangelogSessionLocal()
    try:
        yield db
    finally:
        db.close()


# ---------------------------------------------------
# Ratings helpers
# ---------------------------------------------------

_ITEM_ID_RE = re.compile(r"^[0-9a-f]{24}$")


def _validate_item_id(item_id: str) -> None:
    if not _ITEM_ID_RE.match(item_id):
        raise HTTPException(status_code=400, detail="Invalid item_id format")


def _get_client_ip(request: Request) -> str:
    """Return the real client IP. Forwarding headers are only trusted when the
    direct connection comes from a known reverse proxy (TRUSTED_PROXY_IPS)."""
    direct_ip = request.client.host if request.client else ""
    if direct_ip in TRUSTED_PROXY_IPS:
        xff = request.headers.get("X-Forwarded-For")
        if xff:
            return xff.split(",")[0].strip()
        xri = request.headers.get("X-Real-IP")
        if xri:
            return xri.strip()
    return direct_ip


# Admin brute-force lockout: ip -> (fail_count, lockout_until_monotonic, last_failure_monotonic)
_admin_failures: dict[str, tuple[int, float, float]] = {}
_ADMIN_MAX_FAILURES = 5
_ADMIN_LOCKOUT_SECONDS = 600  # 10 minutes


def _evict_expired_admin_failures(now: float) -> None:
    """Remove expired lockouts and idle below-threshold entries so the dict
    cannot grow without bound under failed-auth probes from many IPs."""
    expired = [
        ip
        for ip, (_, lockout_until, last_fail) in _admin_failures.items()
        if (lockout_until > 0 and lockout_until < now)
        or (lockout_until == 0 and now - last_fail > _ADMIN_LOCKOUT_SECONDS)
    ]
    for ip in expired:
        del _admin_failures[ip]


# Community builds kill switch.
# Persisted via a sentinel file so it survives server restarts.
_COMMUNITY_BUILDS_LOCK_FILE = os.path.join(RUNTIME_DIR, "community_builds.lock")
_community_builds_disabled: bool = os.path.exists(_COMMUNITY_BUILDS_LOCK_FILE)

# Hyperactive sync mode: re-syncs tarkov.dev data every 30 minutes instead of relying
# solely on the external daily cron. Useful immediately after a game patch when
# tarkov.dev data is still catching up to the new game state.
_HYPERACTIVE_LOCK_FILE = os.path.join(RUNTIME_DIR, "hyperactive.lock")
_hyperactive_mode: bool = os.path.exists(_HYPERACTIVE_LOCK_FILE)

# Admin kill switch for build image generation. /build-image/status also reports
# it disabled while Kitbash! isn't installed, so the frontend greys out the toggle.
_IMGGEN_DISABLED_LOCK_FILE = os.path.join(RUNTIME_DIR, "imggen_disabled.lock")
_imggen_disabled: bool = os.path.exists(_IMGGEN_DISABLED_LOCK_FILE)
_SYNC_INTERVAL_HYPERACTIVE_SECS = 1800  # 30 minutes
_sync_running: bool = False
_last_sync_at: float | None = None
_sync_trigger: asyncio.Event = asyncio.Event()
# Written before the subprocess starts and removed after - visible to all gunicorn workers.
_SYNC_IN_PROGRESS_FILE = os.path.join(RUNTIME_DIR, "sync_in_progress.lock")


def _require_admin(request: Request, x_admin_key: str = Header(None)) -> None:
    if not ADMIN_API_KEY:
        raise HTTPException(status_code=503, detail="Admin not configured")

    ip = _get_client_ip(request)
    now = time.monotonic()
    _evict_expired_admin_failures(now)

    fail_count, lockout_until, _ = _admin_failures.get(ip, (0, 0.0, 0.0))
    if lockout_until > now:
        raise HTTPException(status_code=429, detail="Too many failed attempts. Try again later.")

    if not x_admin_key or not hmac.compare_digest(x_admin_key, ADMIN_API_KEY):
        new_count = fail_count + 1
        locked_until = (now + _ADMIN_LOCKOUT_SECONDS) if new_count >= _ADMIN_MAX_FAILURES else 0.0
        _admin_failures[ip] = (new_count, locked_until, now)
        raise HTTPException(status_code=403, detail="Forbidden")

    # Success - reset counter
    _admin_failures.pop(ip, None)


# ---------------------------------------------------
# Client identity helpers (token-based, not IP-based)
# ---------------------------------------------------

# UUID v4 format: 8-4-4-4-12 hex, version nibble = 4, variant bits = 8|9|a|b
_CLIENT_ID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$")


def _get_client_id_hash(x_client_id: str | None) -> str:
    """Validate the X-Client-ID header and return its HMAC-SHA256 hash.
    Raises HTTP 400 if missing or not a valid UUID v4."""
    if not x_client_id or not _CLIENT_ID_RE.match(x_client_id.strip().lower()):
        raise HTTPException(status_code=400, detail="Missing or invalid X-Client-ID.")
    return hmac.new(
        IP_HASH_SECRET.encode(),
        x_client_id.strip().lower().encode(),
        hashlib.sha256,
    ).hexdigest()


def _get_optional_client_id_hash(x_client_id: str | None) -> str | None:
    """Return the client_id_hash if the header is present and valid, else None."""
    if not x_client_id:
        return None
    cleaned = x_client_id.strip().lower()
    if not _CLIENT_ID_RE.match(cleaned):
        return None
    return hmac.new(IP_HASH_SECRET.encode(), cleaned.encode(), hashlib.sha256).hexdigest()


# ---------------------------------------------------
# Build publish helpers
# ---------------------------------------------------

_logger = logging.getLogger(__name__)


def _safe_json_loads(s: str | None):
    """Parse a JSON string; return None and log on corruption instead of raising."""
    if not s:
        return None
    try:
        return json.loads(s)
    except (json.JSONDecodeError, ValueError):
        _logger.error("Corrupted JSON in build record: %.60r", s)
        return None


# publish rate limit: client_id_hash -> monotonic time of last successful publish
_publish_last: dict[str, float] = {}
_PUBLISH_COOLDOWN = 60.0

# comment rate limit: client_id_hash -> monotonic time of last successful comment
_comment_last: dict[str, float] = {}
_COMMENT_COOLDOWN = 60.0  # 1 minute

# account transfer rate limit
_transfer_last: dict[str, float] = {}
_TRANSFER_COOLDOWN = 60.0

# avatar upload rate limit
_avatar_last: dict[str, float] = {}
_AVATAR_COOLDOWN = 90.0

# username update rate limit
_username_last: dict[str, float] = {}
_USERNAME_COOLDOWN = 60.0


def _strip_html_tags(s: str) -> str:
    """Strip HTML tags in O(n) time.

    A backtracking regex like <[^>]+> is quadratic on adversarial input with
    many '<' and no closing '>' (each failed match rescans to the end of the
    string). This walks the string once, only searching forward from each
    '<' and giving up on the whole string once one search comes up empty.
    """
    out = []
    i, n = 0, len(s)
    no_more_close = False
    while i < n:
        if not no_more_close and s[i] == "<":
            j = s.find(">", i + 1)
            if j == -1:
                no_more_close = True
            elif j > i + 1:
                i = j + 1
                continue
        out.append(s[i])
        i += 1
    return "".join(out)


def _sanitize_build_name(raw: str) -> str:
    """Strip HTML tags and collapse whitespace."""
    return " ".join(_strip_html_tags(raw).split())


def _check_client_ban(client_id_hash: str, db: Session) -> None:
    """Raise 403 if the client is currently banned from publishing."""
    ban = db.query(IPBan).filter(IPBan.ip_hash == client_id_hash).first()
    if not ban:
        return
    if ban.banned_until is None or ban.banned_until > datetime.now(timezone.utc).replace(tzinfo=None):
        raise HTTPException(status_code=403, detail="You are banned from publishing.")


def _validate_pairs(pairs: list, db_main: Session) -> None:
    """Validate that pairs has at least one attachment and all item IDs exist."""
    if len(pairs) < 1:
        raise HTTPException(status_code=422, detail="Build must have at least one attachment.")
    item_ids = [p[1] for p in pairs]
    found = {r[0] for r in db_main.query(Item.id).filter(Item.id.in_(item_ids)).all()}
    missing = [iid for iid in item_ids if iid not in found]
    if missing:
        raise HTTPException(status_code=422, detail=f"Unknown item IDs: {missing[:5]}")


# ---------------------------------------------------
# Shared calculation helpers (no DB access)
# ---------------------------------------------------


def _dedup_by_stats(combos: list) -> list:
    """Keep one combo per unique stat fingerprint (recoil, ergo, TrueErgo, weight).
    Removes color-variant duplicates and any other items with identical stat contributions."""
    seen: dict = {}
    result: list = []
    for combo in combos:
        fp = (
            round(combo.get("recoil_vertical") or 0, 1),
            round(combo.get("total_ergo") or 0, 1),
            round(combo.get("true_ergo_delta") or 0, 2),
            round(combo.get("total_weight") or 0, 3),
        )
        if fp not in seen:
            seen[fp] = True
            result.append(combo)
    return result


def _check_conflicts(
    candidate,
    candidate_id: str,
    installed_set: set,
    installed_items_map: dict,
    slots_by_item: dict,
    slot_id: str,
    lang: str,
) -> dict:
    """Run all four conflict checks using pre-loaded data. No DB queries."""
    # Item ↔ item
    if candidate.conflicting_item_ids:
        conflict_ids = set(candidate.conflicting_item_ids.split(","))
        overlap = conflict_ids.intersection(installed_set)
        if overlap:
            conflicting = installed_items_map.get(list(overlap)[0])
            if conflicting:
                return {
                    "valid": False,
                    "reason_key": "conflict.incompatibleWith",
                    "reason_name": _item_name(conflicting, lang),
                    "conflicting_item_id": conflicting.id,
                    "conflicting_slot_id": None,
                }

    # Slot ↔ slot
    if candidate.conflicting_slot_ids:
        conflict_slots = set(candidate.conflicting_slot_ids.split(","))
        for iid in installed_set:
            for s in slots_by_item.get(iid, []):
                if s.id in conflict_slots:
                    return {
                        "valid": False,
                        "reason_key": "conflict.slot",
                        "reason_name": s.slot_name,
                        "conflicting_item_id": None,
                        "conflicting_slot_id": s.id,
                    }

    # Reverse item ↔ item
    for inst_item in installed_items_map.values():
        if inst_item.conflicting_item_ids:
            if candidate_id in set(inst_item.conflicting_item_ids.split(",")):
                return {
                    "valid": False,
                    "reason_key": "conflict.incompatibleWith",
                    "reason_name": _item_name(inst_item, lang),
                    "conflicting_item_id": inst_item.id,
                    "conflicting_slot_id": None,
                }

    # Reverse slot
    for inst_item in installed_items_map.values():
        if inst_item.conflicting_slot_ids:
            if slot_id in set(inst_item.conflicting_slot_ids.split(",")):
                return {
                    "valid": False,
                    "reason_key": "conflict.blockedBy",
                    "reason_name": _item_name(inst_item, lang),
                    "conflicting_item_id": inst_item.id,
                    "conflicting_slot_id": None,
                }

    return {
        "valid": True,
        "reason_key": None,
        "reason_name": None,
        "conflicting_item_id": None,
        "conflicting_slot_id": None,
    }


# ---------------------------------------------------
# Health check
# ---------------------------------------------------


@app.api_route("/health", methods=["GET", "HEAD"])
def health_check(request: Request, db: Session = Depends(get_db)):
    """Liveness + basic DB connectivity check for load balancers / monitoring."""
    try:
        db.execute(text("SELECT 1"))
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"DB unavailable: {exc}")
    return {"status": "ok", "started": SERVER_START_TIME}


_LAST_SYNC_FILE = os.path.join(RUNTIME_DIR, "last_sync.json")


@app.get("/sync-status")
def get_sync_status():
    """Public endpoint - lets clients show a notice when a background sync is in progress,
    and when the tarkov.dev data was last successfully synced (cron, hyperactive mode,
    or a local dev background sync all write last_sync.json via sync_tarkov_dev.py)."""
    running = _sync_running or os.path.exists(_SYNC_IN_PROGRESS_FILE)
    last_synced_at = None
    if os.path.exists(_LAST_SYNC_FILE):
        try:
            with open(_LAST_SYNC_FILE, "r", encoding="utf-8") as f:
                last_synced_at = json.load(f).get("last_synced_at")
        except (OSError, ValueError):
            pass
    return {"sync_running": running, "last_synced_at": last_synced_at}


@app.get("/data-version")
def get_data_version():
    """The token the frontend adds to catalog requests as ?dv= so the CDN can cache
    them until the next sync or deploy. Null while a sync runs: clients then send
    unversioned requests, which are never cached."""
    return JSONResponse({"version": _data_version()}, headers={"Cache-Control": "no-store"})


_DEV_SYNC_NOTICE_FILE = os.path.join(RUNTIME_DIR, "dev_sync_notice.json")


@app.get("/dev/sync-notice")
def get_dev_sync_notice():
    """Local-dev only: reset.py's background sync writes this file when it finds
    new data. Only reset.py's non-prod branch ever creates it, so in production
    this file never exists and the endpoint is a permanent no-op."""
    if not os.path.exists(_DEV_SYNC_NOTICE_FILE):
        return {"changed": False}
    try:
        os.remove(_DEV_SYNC_NOTICE_FILE)
    except OSError:
        pass
    return {"changed": True}


# ---------------------------------------------------
# Asset proxy (used by graph export to bypass CORS on assets.tarkov.dev)
# ---------------------------------------------------

_PROXY_ALLOWED_HOSTS = {"assets.tarkov.dev", "gitee.com", "raw.giteeusercontent.com"}
_PROXY_MAX_BYTES = 20 * 1024 * 1024  # 20 MB cap per proxied asset

# Shared session: connection pooling for proxy + Gitee API calls.
# Identifying user agent so upstreams can tell what
# the traffic is instead of seeing a generic python-requests default.
import requests as _requests

_http_session = _requests.Session()
_http_session.headers["User-Agent"] = "EFTForge (+https://eftforge.com; +https://github.com/SouthHorizons76/EFTForge)"


def _proxy_host_allowed(netloc: str) -> bool:
    # Exact match or subdomain of an allowed host (e.g. foruda.gitee.com for gitee.com avatars)
    return netloc in _PROXY_ALLOWED_HOSTS or any(netloc.endswith("." + h) for h in _PROXY_ALLOWED_HOSTS)


@app.get("/proxy-asset")
def proxy_asset(url: str, request: Request):
    from urllib.parse import urlparse

    parsed = urlparse(url)
    if not _proxy_host_allowed(parsed.netloc) or parsed.scheme != "https":
        raise HTTPException(status_code=400, detail="URL not in proxy allowlist")
    try:
        # Follow redirects manually so each hop is validated against the allowlist.
        # Gitee avatar URLs redirect to CDN subdomains (e.g. foruda.gitee.com) which
        # are allowed as subdomains of gitee.com but would escape a naive allow_redirects=True.
        current_url = url
        r = None
        for _ in range(5):
            r = _http_session.get(current_url, timeout=8, stream=True, allow_redirects=False)
            if 300 <= r.status_code < 400:
                r.close()
                location = r.headers.get("Location", "")
                if not location:
                    raise HTTPException(status_code=502, detail="Redirect with no Location header")
                loc_parsed = urlparse(location)
                if not _proxy_host_allowed(loc_parsed.netloc) or loc_parsed.scheme != "https":
                    raise HTTPException(status_code=502, detail="Redirect escapes proxy allowlist")
                current_url = location
                continue
            r.raise_for_status()
            break
        else:
            raise HTTPException(status_code=502, detail="Too many redirects")
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    # Only images may be proxied. gitee.com hosts arbitrary user repos, so serving
    # upstream HTML/JS from our origin would be an XSS vector.
    content_type = r.headers.get("content-type", "application/octet-stream").split(";")[0].strip().lower()
    if not (content_type.startswith("image/") or content_type == "application/octet-stream"):
        r.close()
        raise HTTPException(status_code=415, detail="Only image assets may be proxied")

    def _capped_stream():
        sent = 0
        for chunk in r.iter_content(chunk_size=65536):
            sent += len(chunk)
            if sent > _PROXY_MAX_BYTES:
                r.close()
                return
            yield chunk

    if f"/{_GITEE_FOLDER}/" in url:
        # build images never change at their URL once published (a new build gets a new
        # filename), so browsers can hold onto them indefinitely.
        cache_control = "public, max-age=604800, immutable"
    else:
        # avatars are overwritten in place on re-upload, so cache lifetime matches the
        # upload cooldown; everything else proxied here (tarkov.dev icons, live preview
        # renders) is also short-lived or one-off.
        cache_control = f"public, max-age={int(_AVATAR_COOLDOWN)}"

    return StreamingResponse(
        _capped_stream(),
        media_type=content_type,
        headers={
            "X-Content-Type-Options": "nosniff",
            "Content-Disposition": "inline",
            "Cache-Control": cache_control,
        },
    )


# ---------------------------------------------------
# Traders
# ---------------------------------------------------


@app.get("/traders")
def get_traders(db: Session = Depends(get_db)):
    traders = db.query(Trader).all()
    return [
        {
            "id": t.id,
            "name": t.name,
            "normalizedName": t.normalized_name,
            "imageLink": t.image_link,
            "image4xLink": t.image_4x_link,
        }
        for t in traders
    ]


# Weapons
# ---------------------------------------------------

# tarkov.dev serves this until it renders a new weapon's images; we draw those
# with Kitbash! instead, when it has the parts.
UNKNOWN_IMAGE_512 = "https://assets.tarkov.dev/unknown-item-512.webp"


def _gun_image_512(gun: Item, bare: bool) -> str | None:
    link = gun.bare_image_512_link if bare else gun.image_512_link
    if link != UNKNOWN_IMAGE_512 or not build_images.available():
        return link
    # Relative to the API; the frontend prefixes its API base.
    return f"/guns/{gun.id}/image" + ("?bare=1" if bare else "")


@app.get("/guns")
def get_guns(lang: str = "en", db: Session = Depends(get_db)):
    guns = db.query(Item).filter(Item.is_weapon == True).all()

    result = []

    for gun in guns:

        if gun.factory_attachment_ids:
            factory_ids = gun.factory_attachment_ids.split(",")
        else:
            factory_ids = []

        result.append(
            {
                "id": gun.id,
                "name": _item_name(gun, lang),
                "short_name": _item_short_name(gun, lang),
                "base_ergo": gun.factory_ergonomics or gun.base_ergonomics or 0,
                "weight": gun.weight or 0,
                "icon_link": gun.icon_link,
                "preset_icon_link": gun.preset_icon_link,
                "image_512_link": _gun_image_512(gun, bare=False),
                "bare_image_512_link": _gun_image_512(gun, bare=True),
                "factory_attachment_ids": factory_ids,
                "caliber": gun.caliber,
                "weapon_category": gun.weapon_category,
                "recoil_vertical": gun.recoil_vertical,
                "recoil_horizontal": gun.recoil_horizontal,
                "sighting_range": gun.sighting_range,
                "center_of_impact": gun.center_of_impact,
                "camera_snap": gun.camera_snap,
                "deviation_curve": gun.deviation_curve,
                "deviation_max": gun.deviation_max,
                "recoil_angle": gun.recoil_angle,
                "camera_recoil": gun.camera_recoil,
                "convergence": gun.convergence,
                "recoil_dispersion": gun.recoil_dispersion,
                "fire_rate": gun.fire_rate,
                "cam_angle_step": gun.cam_angle_step,
                "mount_cam_snap": gun.mount_cam_snap,
                "mount_h_rec": gun.mount_h_rec,
                "mount_v_rec": gun.mount_v_rec,
                "mount_breath": gun.mount_breath,
                "rec_hand_rot": gun.rec_hand_rot,
                "rec_force_back": gun.rec_force_back,
                "rec_force_up": gun.rec_force_up,
                "rec_return_speed": gun.rec_return_speed,
                "recoil_damping_hand_rot": gun.recoil_damping_hand_rot,
                "recoil_return_path_damping": gun.recoil_return_path_damping,
                "recoil_return_path_offset": gun.recoil_return_path_offset,
                "recoil_stable_index_shot": gun.recoil_stable_index_shot,
                "recoil_stable_angle_step": gun.recoil_stable_angle_step,
                "recoil_stable_angle": gun.recoil_stable_angle,
                "recoil_pos_z_mult": gun.recoil_pos_z_mult,
                "recoil_center_y": gun.recoil_center_y,
                "recoil_center_z": gun.recoil_center_z,
                "trader_price": gun.trader_price,
                "trader_price_rub": gun.trader_price_rub,
                "trader_currency": gun.trader_currency,
                "trader_vendor": gun.trader_vendor,
                "trader_min_level": gun.trader_min_level,
            }
        )

    return result


@app.get("/graph/searchable-items")
def get_graph_searchable_items(db: Session = Depends(get_db)):
    from sqlalchemy import exists as sa_exists

    guns = (
        db.query(Item)
        .filter(
            Item.is_weapon == True,
            Item.caliber != "Caliber26x75",
            ~Item.name.ilike("%rocket%"),
            ~Item.name.ilike("%rshg%"),
        )
        .order_by(Item.weapon_category, Item.name)
        .all()
    )
    attachments = (
        db.query(Item)
        .filter(
            Item.is_weapon == False,
            Item.is_ammo == False,
            sa_exists().where(SlotAllowedItem.allowed_item_id == Item.id),
        )
        .order_by(Item.name)
        .all()
    )
    return {
        "guns": [
            {
                "id": g.id,
                "name": g.name,
                "short_name": g.short_name,
                "name_zh": g.name_zh,
                "short_name_zh": g.short_name_zh,
                "weapon_category": g.weapon_category,
                "base_ergonomics": g.base_ergonomics,
                "factory_ergonomics": g.factory_ergonomics,
                "recoil_vertical": g.recoil_vertical,
                "recoil_horizontal": g.recoil_horizontal,
                "factory_recoil_vertical": g.factory_recoil_vertical,
                "factory_recoil_horizontal": g.factory_recoil_horizontal,
                "icon_link": g.icon_link,
                "base_image_link": g.base_image_link,
                "image_512_link": _gun_image_512(g, bare=False),
                "bare_image_512_link": _gun_image_512(g, bare=True),
            }
            for g in guns
        ],
        "attachments": [
            {
                "id": a.id,
                "name": a.name,
                "short_name": a.short_name,
                "name_zh": a.name_zh,
                "short_name_zh": a.short_name_zh,
                "ergonomics_modifier": a.ergonomics_modifier,
                "recoil_modifier": a.recoil_modifier,
                "icon_link": a.icon_link,
                "base_image_link": a.base_image_link,
            }
            for a in attachments
        ],
    }


def _ammo_dto(a, lang: str) -> dict:
    return {
        "id": a.id,
        "name": _item_name(a, lang),
        "short_name": _item_short_name(a, lang),
        "icon_link": a.icon_link,
        "weight": a.weight,
        "caliber": a.caliber,
        "ammo_type": a.ammo_type,
        "damage": a.ammo_damage,
        "penetration_power": a.penetration_power,
        "penetration_chance": a.penetration_chance,
        "penetration_power_deviation": a.penetration_power_deviation,
        "armor_damage": a.armor_damage,
        "velocity": a.velocity,
        "tracer": a.tracer,
        "tracer_color": a.tracer_color,
        "projectile_count": a.projectile_count,
        "fragmentation_chance": a.fragmentation_chance,
        "ricochet_chance": a.ricochet_chance,
        "stack_max_size": a.stack_max_size,
        "accuracy_modifier": a.ammo_accuracy_modifier,
        "recoil_modifier": a.ammo_recoil_modifier,
        "light_bleed_delta": a.light_bleed_delta,
        "heavy_bleed_delta": a.heavy_bleed_delta,
        "heat_factor": a.heat_factor,
        "durability_burn_factor": a.durability_burn_factor,
        "penetration_damage_mod": a.penetration_damage_mod,
        "malf_feed_chance": a.malf_feed_chance,
        "misfire_chance": a.misfire_chance,
        "trader_price": a.trader_price,
        "trader_price_rub": a.trader_price_rub,
        "trader_currency": a.trader_currency,
        "trader_vendor": a.trader_vendor,
        "trader_min_level": a.trader_min_level,
    }


# Calibers that are flares / signal cartridges - no meaningful ballistic stats
_AMMO_EXCLUDED_CALIBERS = {"Caliber26x75"}


@app.get("/ammo/all")
def get_all_ammo(lang: str = "en", db: Session = Depends(get_db)):
    rows = (
        db.query(Item)
        .filter(Item.is_ammo == True)
        .filter(Item.caliber.notin_(_AMMO_EXCLUDED_CALIBERS))
        .order_by(Item.caliber.asc(), Item.penetration_power.asc())
        .all()
    )
    result = {}
    for a in rows:
        cal = a.caliber or "Unknown"
        result.setdefault(cal, []).append(_ammo_dto(a, lang))
    return result


@app.get("/ammo/{caliber}")
def get_ammo_for_caliber(caliber: str, lang: str = "en", db: Session = Depends(get_db)):
    ammo = db.query(Item).filter(Item.is_ammo == True, Item.caliber == caliber).order_by(Item.weight.asc()).all()

    return [_ammo_dto(a, lang) for a in ammo]


# ---------------------------------------------------
# Item IDs (for client-side flea price prefetch)
# ---------------------------------------------------


@app.get("/items/ids")
def get_item_ids(db: Session = Depends(get_db)):
    ids = db.query(Item.id).all()
    return [row[0] for row in ids]


# ---------------------------------------------------
# Slots
# ---------------------------------------------------


@app.get("/items/{item_id}/slots")
def get_item_slots(item_id: str, db: Session = Depends(get_db)):
    slots = db.query(Slot).filter(Slot.parent_item_id == item_id).all()
    if not slots:
        return []

    slot_ids = [s.id for s in slots]

    # Count allowed items per slot in one query to avoid N+1
    counts = dict(
        db.query(SlotAllowedItem.slot_id, func.count(SlotAllowedItem.allowed_item_id))
        .filter(SlotAllowedItem.slot_id.in_(slot_ids))
        .group_by(SlotAllowedItem.slot_id)
        .all()
    )

    return [
        {
            "id": s.id,
            "parent_item_id": s.parent_item_id,
            "slot_name": s.slot_name,
            "slot_game_name": s.slot_game_name,
            "has_allowed_items": counts.get(s.id, 0) > 0,
        }
        for s in slots
    ]


# ---------------------------------------------------
# Allowed Items
# ---------------------------------------------------


@app.get("/slots/{slot_id}/allowed-items")
def get_allowed_items(slot_id: str, lang: str = "en", db: Session = Depends(get_db)):
    allowed = db.query(SlotAllowedItem).filter(SlotAllowedItem.slot_id == slot_id).all()

    ids = [a.allowed_item_id for a in allowed]

    items = db.query(Item).filter(Item.id.in_(ids)).all()

    return [
        {
            "id": item.id,
            "name": _item_name(item, lang),
            "short_name": _item_short_name(item, lang),
            "weight": item.weight,
            "ergonomics_modifier": item.ergonomics_modifier,
            "recoil_modifier": item.recoil_modifier,
            "accuracy_modifier": item.accuracy_modifier,
            "center_of_impact": item.center_of_impact,
            "deviation_curve": item.deviation_curve,
            "deviation_max": item.deviation_max,
            "sighting_range": item.sighting_range,
            "heat_factor": item.heat_factor,
            "cooling_factor": item.cooling_factor,
            "durability_burn_factor": item.durability_burn_factor,
            "velocity_modifier": item.velocity_modifier,
            "loudness": item.loudness,
            "icon_link": item.icon_link,
            "base_image_link": item.base_image_link,
            "conflicting_item_ids": item.conflicting_item_ids,
            "conflicting_slot_ids": item.conflicting_slot_ids,
            "magazine_capacity": item.magazine_capacity,
            "caliber": item.caliber,
            "is_weapon": item.is_weapon,
            "trader_price": item.trader_price,
            "trader_price_rub": item.trader_price_rub,
            "trader_currency": item.trader_currency,
            "trader_vendor": item.trader_vendor,
            "trader_min_level": item.trader_min_level,
            "task_unlock_id": item.task_unlock_id,
            "task_unlock_name": item.task_unlock_name,
            "task_unlock_name_zh": item.task_unlock_name_zh,
        }
        for item in items
    ]


# ---------------------------------------------------
# Batch endpoints for build reconstruction
# ---------------------------------------------------


@app.post("/slots/allowed-items/batch")
def get_allowed_items_batch(
    slot_ids: List[str] = Body(...),
    lang: str = Body(default="en"),
    db: Session = Depends(get_db),
):
    if not slot_ids:
        return {}
    allowed_rows = db.query(SlotAllowedItem).filter(SlotAllowedItem.slot_id.in_(slot_ids)).all()
    all_item_ids = list({row.allowed_item_id for row in allowed_rows})
    items_by_id = (
        {item.id: item for item in db.query(Item).filter(Item.id.in_(all_item_ids)).all()} if all_item_ids else {}
    )
    result = {sid: [] for sid in slot_ids}
    for row in allowed_rows:
        item = items_by_id.get(row.allowed_item_id)
        if item:
            result[row.slot_id].append(
                {
                    "id": item.id,
                    "name": _item_name(item, lang),
                    "short_name": _item_short_name(item, lang),
                    "weight": item.weight,
                    "ergonomics_modifier": item.ergonomics_modifier,
                    "recoil_modifier": item.recoil_modifier,
                    "accuracy_modifier": item.accuracy_modifier,
                    "center_of_impact": item.center_of_impact,
                    "deviation_curve": item.deviation_curve,
                    "deviation_max": item.deviation_max,
                    "sighting_range": item.sighting_range,
                    "heat_factor": item.heat_factor,
                    "cooling_factor": item.cooling_factor,
                    "durability_burn_factor": item.durability_burn_factor,
                    "velocity_modifier": item.velocity_modifier,
                    "loudness": item.loudness,
                    "icon_link": item.icon_link,
                    "base_image_link": item.base_image_link,
                    "conflicting_item_ids": item.conflicting_item_ids,
                    "conflicting_slot_ids": item.conflicting_slot_ids,
                    "magazine_capacity": item.magazine_capacity,
                    "caliber": item.caliber,
                    "is_weapon": item.is_weapon,
                    "trader_price": item.trader_price,
                    "trader_price_rub": item.trader_price_rub,
                    "trader_currency": item.trader_currency,
                    "trader_vendor": item.trader_vendor,
                    "trader_min_level": item.trader_min_level,
                    "task_unlock_id": item.task_unlock_id,
                    "task_unlock_name": item.task_unlock_name,
                    "task_unlock_name_zh": item.task_unlock_name_zh,
                }
            )
    return result


@app.post("/items/slots/batch")
def get_item_slots_batch(
    item_ids: List[str] = Body(..., embed=True),
    db: Session = Depends(get_db),
):
    if not item_ids:
        return {}
    slots = db.query(Slot).filter(Slot.parent_item_id.in_(item_ids)).all()
    slot_ids = [s.id for s in slots]
    counts = {}
    if slot_ids:
        counts = dict(
            db.query(SlotAllowedItem.slot_id, func.count(SlotAllowedItem.allowed_item_id))
            .filter(SlotAllowedItem.slot_id.in_(slot_ids))
            .group_by(SlotAllowedItem.slot_id)
            .all()
        )
    result = {iid: [] for iid in item_ids}
    for s in slots:
        result[s.parent_item_id].append(
            {
                "id": s.id,
                "parent_item_id": s.parent_item_id,
                "slot_name": s.slot_name,
                "slot_game_name": s.slot_game_name,
                "has_allowed_items": counts.get(s.id, 0) > 0,
            }
        )
    return result


# ---------------------------------------------------
# Build Compatibility Validation
# ---------------------------------------------------


@app.post("/build/validate")
def validate_attachment(
    base_item_id: str = Body(...),
    installed_ids: List[str] = Body(...),
    slot_id: str = Body(...),
    candidate_id: str = Body(...),
    lang: str = Body(default="en"),
    db: Session = Depends(get_db),
):

    _cap_list("installed_ids", installed_ids, MAX_INSTALLED_IDS)

    base_item = db.query(Item).filter(Item.id == base_item_id).first()
    if not base_item:
        raise HTTPException(status_code=404, detail="Base item not found")

    candidate = db.query(Item).filter(Item.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate item not found")

    # -------------------------------------------------
    # SLOT LEGALITY CHECK
    # -------------------------------------------------

    allowed = (
        db.query(SlotAllowedItem)
        .filter(SlotAllowedItem.slot_id == slot_id, SlotAllowedItem.allowed_item_id == candidate_id)
        .first()
    )

    if not allowed:
        return {"valid": False, "reason": "Item not allowed in this slot", "type": "slot_not_allowed"}

    # -------------------------------------------------
    # BATCH-LOAD all installed items and their slots (2 queries total)
    # -------------------------------------------------

    installed_set = set(installed_ids)
    installed_set.add(base_item_id)

    installed_items = db.query(Item).filter(Item.id.in_(installed_set)).all()
    installed_map = {item.id: item for item in installed_items}

    all_installed_slots = db.query(Slot).filter(Slot.parent_item_id.in_(installed_set)).all()
    slots_by_item: dict[str, list] = {item_id: [] for item_id in installed_set}
    for s in all_installed_slots:
        slots_by_item[s.parent_item_id].append(s)

    result = _check_conflicts(candidate, candidate_id, installed_set, installed_map, slots_by_item, slot_id, lang)
    if not result["valid"]:
        return result

    return {"valid": True}


# ---------------------------------------------------
# Calculation Engine
# ---------------------------------------------------


@app.post("/build/calculate")
def calculate_build(
    base_item_id: str = Body(...),
    attachment_ids: List[str] | None = Body(default=None),
    assume_full_mag: bool = Body(default=True),
    selected_ammo_id: str | None = Body(default=None),
    selected_ubgl_ammo_id: str | None = Body(default=None),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    db: Session = Depends(get_db),
):

    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )

    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )

    base_item = db.query(Item).filter(Item.id == base_item_id).first()
    if not base_item:
        raise HTTPException(status_code=404, detail="Base item not found")

    current_ids = attachment_ids or []
    items_map = {}
    if current_ids:
        items_map = {item.id: item for item in db.query(Item).filter(Item.id.in_(current_ids)).all()}

    stats = _compute_stats(base_item, current_ids, items_map, strength_level, equip_ergo_modifier)

    # ------------------------------
    # Ammo Weight + Heat/Durability-Burn Logic (not in batch endpoint - only used for the main stats panel)
    # ------------------------------
    # Gated on assume_full_mag (not on whether a magazine is actually installed): the toggle
    # represents "assume this weapon is loaded and ready to fire this round," which is independent
    # of whether the user has dropped a magazine model into the builder.
    ammo = (
        db.query(Item).filter(Item.id == selected_ammo_id).first() if (selected_ammo_id and assume_full_mag) else None
    )
    ubgl_grenade = (
        db.query(Item).filter(Item.id == selected_ubgl_ammo_id).first()
        if (assume_full_mag and selected_ubgl_ammo_id)
        else None
    )
    apply_full_mag_ammo(stats, items_map, ammo, ubgl_grenade, strength_level, equip_ergo_modifier)

    return stats


# ---------------------------------------------------
# Batch Process (validation + calculation for all candidates in one request)
# ---------------------------------------------------


@app.post("/build/batch-process")
def batch_process(
    base_item_id: str = Body(...),
    installed_ids: List[str] = Body(...),
    slot_id: str = Body(...),
    candidate_ids: List[str] = Body(...),
    lang: str = Body(default="en"),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    db: Session = Depends(get_db),
):
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )

    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )

    _cap_list("installed_ids", installed_ids, MAX_INSTALLED_IDS)
    _cap_list("candidate_ids", candidate_ids, MAX_CANDIDATE_IDS)

    base_item = db.query(Item).filter(Item.id == base_item_id).first()
    if not base_item:
        raise HTTPException(status_code=404, detail="Base item not found")

    # 1. Batch-load all items needed (installed + candidates) - 1 query
    all_needed_ids = set(installed_ids) | set(candidate_ids)
    items_map = {item.id: item for item in db.query(Item).filter(Item.id.in_(all_needed_ids)).all()}

    # 2. Validation setup: installed items + their slots - 1 query each
    installed_set = set(installed_ids) | {base_item_id}
    installed_items_map = {iid: items_map[iid] for iid in installed_ids if iid in items_map}
    installed_items_map[base_item_id] = base_item

    all_installed_slots = db.query(Slot).filter(Slot.parent_item_id.in_(installed_set)).all()
    slots_by_item: dict[str, list] = {iid: [] for iid in installed_set}
    for s in all_installed_slots:
        slots_by_item[s.parent_item_id].append(s)

    # 3. Which candidates are allowed in this slot - 1 query
    allowed_records = (
        db.query(SlotAllowedItem)
        .filter(SlotAllowedItem.slot_id == slot_id, SlotAllowedItem.allowed_item_id.in_(candidate_ids))
        .all()
    )
    allowed_set = {r.allowed_item_id for r in allowed_records}

    # 4. Baseline stats (installed_ids, no candidate) - no DB
    base_stats = _compute_stats(base_item, installed_ids, items_map, strength_level, equip_ergo_modifier)

    # 5. Per-candidate validation + calculation - no DB
    results = []
    for candidate_id in candidate_ids:
        candidate = items_map.get(candidate_id)
        if not candidate:
            continue

        if candidate_id not in allowed_set:
            validation = {
                "valid": False,
                "reason_key": None,
                "reason_name": None,
                "conflicting_item_id": None,
                "conflicting_slot_id": None,
            }
        else:
            validation = _check_conflicts(
                candidate, candidate_id, installed_set, installed_items_map, slots_by_item, slot_id, lang
            )

        sim_stats = _compute_stats(
            base_item, list(installed_ids) + [candidate_id], items_map, strength_level, equip_ergo_modifier
        )
        results.append(
            {
                "item_id": candidate_id,
                "trader_price": candidate.trader_price,
                "trader_price_rub": candidate.trader_price_rub,
                "trader_currency": candidate.trader_currency,
                "trader_vendor": candidate.trader_vendor,
                "trader_min_level": candidate.trader_min_level,
                **validation,
                **sim_stats,
            }
        )

    return {"base": base_stats, "candidates": results}


@app.post("/build/combo-batch-process")
def combo_batch_process(
    base_item_id: str = Body(...),
    installed_ids: List[str] = Body(...),
    combos: List[dict] = Body(...),
    lang: str = Body(default="en"),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    db: Session = Depends(get_db),
):
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )
    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )

    _cap_list("installed_ids", installed_ids, MAX_INSTALLED_IDS)
    _cap_list("combos", combos, MAX_COMBO_BATCH)

    base_item = db.query(Item).filter(Item.id == base_item_id).first()
    if not base_item:
        raise HTTPException(status_code=404, detail="Base item not found")

    all_needed_ids = set(installed_ids)
    for combo in combos:
        add_ids = combo.get("add_ids", [])
        if not isinstance(add_ids, list) or len(add_ids) > MAX_INSTALLED_IDS:
            raise HTTPException(status_code=422, detail="Invalid add_ids in combo")
        all_needed_ids.update(add_ids)

    items_map = {item.id: item for item in db.query(Item).filter(Item.id.in_(all_needed_ids)).all()}
    items_map[base_item_id] = base_item

    base_stats = _compute_stats(base_item, installed_ids, items_map, strength_level, equip_ergo_modifier)

    results = []
    for combo in combos:
        add_ids = combo.get("add_ids", [])
        sim_stats = _compute_stats(
            base_item, list(installed_ids) + add_ids, items_map, strength_level, equip_ergo_modifier
        )
        results.append({"cid": combo.get("cid"), **sim_stats})

    return {"base": base_stats, "combos": results}


# ---------------------------------------------------
# Combo Full (single-request combo recommender)
# ---------------------------------------------------

_COMBO_FULL_CACHE: dict = {}
_COMBO_FULL_CACHE_LOCK = threading.Lock()
_COMBO_FULL_CACHE_MAX = 500
_COMBO_FRONTIER_CAP = 10_000
_COMBO_NESTED_EXPANSION_LIMIT = 50_000


@app.post("/build/combo-full")
def combo_full(
    base_item_id: str = Body(...),
    installed_ids: List[str] = Body(...),
    root_slot_id: str = Body(...),
    lang: str = Body(default="en"),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    exclude_child_slot_names: List[str] = Body(default=[]),
    exclude_item_ids: List[str] = Body(default=[]),
    db: Session = Depends(get_db),
    response_format: Annotated[ComboResponseFormat, Body()] = "legacy",
):
    _combo_started = time.perf_counter()
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )
    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )

    _cap_list("installed_ids", installed_ids, MAX_INSTALLED_IDS)
    _cap_list("exclude_child_slot_names", exclude_child_slot_names, 200)
    _cap_list("exclude_item_ids", exclude_item_ids, 2000)

    _cache_key = (
        _solver_cache_generation(),
        base_item_id,
        tuple(sorted(installed_ids)),
        root_slot_id,
        lang,
        strength_level,
        round(equip_ergo_modifier, 6),
        frozenset(exclude_child_slot_names),
        frozenset(exclude_item_ids),
    )
    with _COMBO_FULL_CACHE_LOCK:
        cached = _COMBO_FULL_CACHE.get(_cache_key)
    if cached is not None:
        cached_result = {
            **cached,
            "metrics": {
                **cached.get("metrics", {}),
                "cache_hit": True,
                "processing_ms": round((time.perf_counter() - _combo_started) * 1000, 3),
            },
        }

        def _cached_stream():
            yield combo_result_event(cached_result, response_format)

        return StreamingResponse(
            _cached_stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # 1. Base item
    base_item = db.query(Item).filter(Item.id == base_item_id).first()
    if not base_item:
        raise HTTPException(status_code=404, detail="Base item not found")

    # 2. Pre-load installed items and their slots (for conflict checks)
    installed_set_base = set(installed_ids) | {base_item_id}
    installed_items_list = db.query(Item).filter(Item.id.in_(installed_set_base)).all() if installed_ids else []
    items_map = {item.id: item for item in installed_items_list}
    items_map[base_item_id] = base_item

    installed_slots = db.query(Slot).filter(Slot.parent_item_id.in_(installed_set_base)).all()
    slots_by_item: dict = {iid: [] for iid in installed_set_base}
    for s in installed_slots:
        slots_by_item[s.parent_item_id].append(s)

    # 3. Load parent candidates for root slot + their items in one join
    root_allowed_rows = (
        db.query(Item)
        .join(SlotAllowedItem, SlotAllowedItem.allowed_item_id == Item.id)
        .filter(SlotAllowedItem.slot_id == root_slot_id)
        .all()
    )
    for item in root_allowed_rows:
        items_map[item.id] = item

    # 4. Check parents for external conflicts against the base installed set only.
    # All parents are kept - externally conflicting ones are included but marked.
    base_only_items_map = {iid: items_map[iid] for iid in installed_set_base if iid in items_map}
    all_parents = list(root_allowed_rows)
    parent_external_conflict: dict = {}
    for candidate in all_parents:
        r = _check_conflicts(
            candidate,
            candidate.id,
            installed_set_base,
            base_only_items_map,
            slots_by_item,
            root_slot_id,
            lang,
        )
        if not r["valid"]:
            parent_external_conflict[candidate.id] = r

    base_stats = _compute_stats(base_item, installed_ids, items_map, strength_level, equip_ergo_modifier)

    if not all_parents:
        result = {
            "base": base_stats,
            "combos": [],
            "timed_out": False,
            "truncated": False,
            "truncation_reasons": [],
            "metrics": {
                "root_candidate_count": 0,
                "child_candidate_edge_count": 0,
                "nested_candidate_edge_count": 0,
                "reachable_item_count": 0,
                "frontier_peak": 0,
                "frontier_states_generated": 0,
                "frontier_cap_hits": 0,
                "nested_expansion_skips": 0,
                "pruning_ms": 0.0,
                "pruned_candidate_edge_count": 0,
                "pruning_passes": 0,
                "combo_count_before_dedup": 0,
                "combo_count": 0,
                "cache_hit": False,
                "processing_ms": round((time.perf_counter() - _combo_started) * 1000, 3),
            },
        }
        return format_combo_result(result, response_format)

    all_parent_ids = [p.id for p in all_parents]

    # 5. Load child slots for all parents
    all_child_slots = db.query(Slot).filter(Slot.parent_item_id.in_(all_parent_ids)).all()

    # Determine which child slots have allowed items (one count query)
    all_child_slot_ids = [s.id for s in all_child_slots]
    slot_has_items: set = set()
    if all_child_slot_ids:
        counts = (
            db.query(SlotAllowedItem.slot_id).filter(SlotAllowedItem.slot_id.in_(all_child_slot_ids)).distinct().all()
        )
        slot_has_items = {row[0] for row in counts}

    _EXCLUDED_SLOT_NAMES = frozenset(["Scope", "Tactical", "Front Sight", "Rear Sight"])
    exclude_names = set(exclude_child_slot_names) | _EXCLUDED_SLOT_NAMES
    child_slots_by_parent: dict = {}
    for s in all_child_slots:
        if s.id in slot_has_items and s.slot_name not in exclude_names:
            child_slots_by_parent.setdefault(s.parent_item_id, []).append(s)

    # 6. Load all child candidate items for all active child slots
    active_child_slot_ids = [s.id for slots in child_slots_by_parent.values() for s in slots]
    child_items_by_slot: dict = {}
    if active_child_slot_ids:
        child_allowed_rows = (
            db.query(SlotAllowedItem.slot_id, Item)
            .join(Item, SlotAllowedItem.allowed_item_id == Item.id)
            .filter(SlotAllowedItem.slot_id.in_(active_child_slot_ids))
            .all()
        )
        for slot_id_col, item in child_allowed_rows:
            child_items_by_slot.setdefault(slot_id_col, []).append(item)
            items_map[item.id] = item

    # Item ID exclusion: drop specific items from all child slots.
    # Also drops the slot entirely if it ends up empty after exclusion.
    if exclude_item_ids:
        _exclude_ids = set(exclude_item_ids)
        child_items_by_slot = {
            sid: [i for i in items if i.id not in _exclude_ids] for sid, items in child_items_by_slot.items()
        }
    child_slots_by_parent = {
        pid: [s for s in slots if child_items_by_slot.get(s.id)] for pid, slots in child_slots_by_parent.items()
    }

    # 7. Load slots for all parent + child items (needed for slot-conflict checks during expansion)
    all_combo_item_ids = set(all_parent_ids) | {item.id for items in child_items_by_slot.values() for item in items}
    if all_combo_item_ids:
        combo_item_slots = db.query(Slot).filter(Slot.parent_item_id.in_(all_combo_item_ids)).all()
        for s in combo_item_slots:
            slots_by_item.setdefault(s.parent_item_id, []).append(s)

    # BFS: recursively load child slots/items for ALL child items, not just
    # mount items. Stops when nothing new is found or the depth limit is hit.
    nested_slots_by_item: dict = {}  # item_id -> [Slot]
    nested_items_by_slot: dict = {}  # slot_id -> [Item]

    _excl_ids = set(exclude_item_ids) if exclude_item_ids else set()
    _already_expanded: set = set(all_parent_ids)
    _to_expand: set = {item.id for items in child_items_by_slot.values() for item in items}
    _already_expanded |= _to_expand

    _MAX_NEST_DEPTH = 4
    for _depth in range(_MAX_NEST_DEPTH):
        if not _to_expand:
            break

        _nest_slots = db.query(Slot).filter(Slot.parent_item_id.in_(_to_expand)).all()
        _nest_slot_ids = [s.id for s in _nest_slots]
        if not _nest_slot_ids:
            break

        _nest_has_items = {
            row[0]
            for row in db.query(SlotAllowedItem.slot_id)
            .filter(SlotAllowedItem.slot_id.in_(_nest_slot_ids))
            .distinct()
            .all()
        }
        _active_nest_slots = [s for s in _nest_slots if s.id in _nest_has_items and s.slot_name not in exclude_names]
        for s in _active_nest_slots:
            nested_slots_by_item.setdefault(s.parent_item_id, []).append(s)

        _active_nest_slot_ids = [s.id for s in _active_nest_slots]
        if not _active_nest_slot_ids:
            break

        _nest_rows = (
            db.query(SlotAllowedItem.slot_id, Item)
            .join(Item, SlotAllowedItem.allowed_item_id == Item.id)
            .filter(SlotAllowedItem.slot_id.in_(_active_nest_slot_ids))
            .all()
        )
        _next_expand: set = set()
        for _slot_id_col, _nest_item in _nest_rows:
            if _nest_item.id in _excl_ids:
                continue
            nested_items_by_slot.setdefault(_slot_id_col, []).append(_nest_item)
            items_map[_nest_item.id] = _nest_item
            if _nest_item.id not in _already_expanded:
                _next_expand.add(_nest_item.id)
                _already_expanded.add(_nest_item.id)

        # Drop slots that ended up empty after exclusion
        nested_slots_by_item = {
            mid: [s for s in slots if nested_items_by_slot.get(s.id)] for mid, slots in nested_slots_by_item.items()
        }

        # Load slots for newly found items (needed for conflict checking)
        if _next_expand:
            _new_item_slots = db.query(Slot).filter(Slot.parent_item_id.in_(_next_expand)).all()
            for s in _new_item_slots:
                slots_by_item.setdefault(s.parent_item_id, []).append(s)

        _to_expand = _next_expand

    # Release the DB connection now - all data is loaded into memory.
    # The expansion below is CPU-only and can run for several seconds on large trees;
    # holding the connection that whole time would block every other DB request.
    db.close()

    # Only deep trees benefit from eliminating an entire branch before state
    # expansion. Shallow combos keep their existing fast path. This index is
    # request-local; the existing generation-keyed result cache owns its lifetime.
    _index_started = time.perf_counter()
    combo_index = None
    if nested_items_by_slot:
        combo_index = CompatibilityIndex(
            [s for slots in slots_by_item.values() for s in slots],
            {
                sid: [item.id for item in items]
                for sid, items in {**child_items_by_slot, **nested_items_by_slot}.items()
            },
            items_map,
        )
    _pruning_metrics = {
        "pruning_ms": (time.perf_counter() - _index_started) * 1000,
        "pruned_candidate_edge_count": 0,
        "pruning_passes": 0,
    }

    # Deep trees repeatedly aggregate the same loaded scalar fields. Snapshot
    # once to avoid ORM descriptor dispatch in every build; the shared stats
    # function remains the sole implementation of the formulas.
    stats_items_map: dict = items_map
    if combo_index is not None:
        columns = tuple(column.key for column in Item.__table__.columns)
        stats_items_map = {
            iid: SimpleNamespace(**{key: getattr(item, key) for key in columns}) for iid, item in items_map.items()
        }
    stats_base_item = stats_items_map[base_item_id]

    # 8. Helper to serialize an item for the response
    serialized_items: dict[str, dict] = {}

    def _ser(item):
        # Records are read-only throughout result assembly and deduplication.
        # Reuse one per item instead of allocating one per occurrence in builds.
        if item.id in serialized_items:
            return serialized_items[item.id]
        record = {
            "id": item.id,
            "name": _item_name(item, lang),
            "short_name": _item_short_name(item, lang),
            "weight": item.weight,
            "ergonomics_modifier": item.ergonomics_modifier,
            "recoil_modifier": item.recoil_modifier,
            "accuracy_modifier": item.accuracy_modifier,
            "center_of_impact": item.center_of_impact,
            "deviation_curve": item.deviation_curve,
            "deviation_max": item.deviation_max,
            "sighting_range": item.sighting_range,
            "heat_factor": item.heat_factor,
            "cooling_factor": item.cooling_factor,
            "durability_burn_factor": item.durability_burn_factor,
            "velocity_modifier": item.velocity_modifier,
            "loudness": item.loudness,
            "icon_link": item.icon_link,
            "base_image_link": item.base_image_link,
            "conflicting_item_ids": item.conflicting_item_ids,
            "conflicting_slot_ids": item.conflicting_slot_ids,
            "magazine_capacity": item.magazine_capacity,
            "caliber": item.caliber,
            "is_weapon": item.is_weapon,
            "trader_price": item.trader_price,
            "trader_price_rub": item.trader_price_rub,
            "trader_currency": item.trader_currency,
            "trader_vendor": item.trader_vendor,
            "trader_min_level": item.trader_min_level,
            "task_unlock_id": item.task_unlock_id,
            "task_unlock_name": item.task_unlock_name,
            "task_unlock_name_zh": item.task_unlock_name_zh,
        }
        serialized_items[item.id] = record
        return record

    # 9. Conflict helpers and caches
    _valid_cache: dict = {}
    _ext_conflict_cache: dict = {}
    _owner_blocked = None

    def _get_external_conflict(item, slot_id):
        """Check item against the base installed set only (not combo items). Cached."""
        key = (item.id, slot_id)
        if key not in _ext_conflict_cache:
            r = _check_conflicts(item, item.id, installed_set_base, base_only_items_map, slots_by_item, slot_id, lang)
            _ext_conflict_cache[key] = None if r["valid"] else r
        return _ext_conflict_cache[key]

    def _ser_conflict(r):
        if r is None:
            return None
        return {
            "reason_key": r["reason_key"],
            "reason_name": r["reason_name"],
            "conflicting_item_id": r["conflicting_item_id"],
            "conflicting_slot_id": r["conflicting_slot_id"],
        }

    def _validated_children(slot_id, inst_list, raw_candidates):
        """Returns [(item, external_conflict_or_None), ...] excluding internal conflicts."""
        key = (slot_id, tuple(sorted(inst_list)))
        if key in _valid_cache:
            return _valid_cache[key]
        inst_set = set(inst_list)
        inst_items_map = {iid: items_map[iid] for iid in inst_list if iid in items_map}
        result = []
        for ci in raw_candidates:
            r_full = _check_conflicts(ci, ci.id, inst_set, inst_items_map, slots_by_item, slot_id, lang)
            if r_full["valid"]:
                result.append((ci, None))
            else:
                # If the conflict is only with the base installed set (not with combo items),
                # include it as an externally conflicted option so it can be shown in red.
                r_ext = _get_external_conflict(ci, slot_id)
                if r_ext is not None:
                    result.append((ci, r_ext))
                # else: internal conflict (with parent or sibling child) - skip entirely
        _valid_cache[key] = result
        return result

    def _pruned_options(parent, root_slots):
        nonlocal _owner_blocked
        if combo_index is None:
            return child_items_by_slot, nested_items_by_slot
        started = time.perf_counter()
        if _owner_blocked is None:
            _owner_blocked = combo_index.owner_blocked_edges()
        blocked = combo_index.blocked_edges({parent.id})
        for sid, ids in _owner_blocked.items():
            blocked.setdefault(sid, set()).update(ids)
        if not any(blocked.values()):
            _pruning_metrics["pruning_ms"] += (time.perf_counter() - started) * 1000
            return child_items_by_slot, nested_items_by_slot
        reachable = combo_index.reachable(root_slots)
        # External conflicts are deliberately still shown in red. Even when
        # an internal conflict also exists, preserve _validated_children's
        # existing external-conflict precedence.
        blocked = {
            sid: {iid for iid in ids if _get_external_conflict(items_map[iid], sid) is None}
            for sid, ids in blocked.items()
            if sid in root_slots or combo_index.slot_owner.get(sid) in reachable
        }
        if not any(blocked.values()):
            _pruning_metrics["pruning_ms"] += (time.perf_counter() - started) * 1000
            return child_items_by_slot, nested_items_by_slot
        pruned = combo_index.prune(root_slots, reachable, blocked_edges=blocked)
        original_edges = sum(
            len(ids)
            for sid, ids in combo_index.slot_items.items()
            if sid in root_slots or combo_index.slot_owner[sid] in reachable
        )
        _pruning_metrics["pruned_candidate_edge_count"] += original_edges - sum(map(len, pruned.slot_items.values()))
        _pruning_metrics["pruning_passes"] += pruned.passes

        def restrict(options):
            return {
                sid: [item for item in items if item.id in pruned.slot_items.get(sid, ())]
                for sid, items in options.items()
            }

        children, nested = restrict(child_items_by_slot), restrict(nested_items_by_slot)
        _pruning_metrics["pruning_ms"] += (time.perf_counter() - started) * 1000
        return children, nested

    def _expand_item(base_state, item, nested_options):
        """Expand a state through all of item's nested child slots, returning all variants."""
        child_slots = nested_slots_by_item.get(item.id, [])
        if not child_slots:
            return [base_state]
        states = [base_state]
        for child_slot in child_slots:
            raw_items = nested_options.get(child_slot.id, [])
            if not raw_items:
                continue
            next_states = []
            for st in states:
                valid = _validated_children(child_slot.id, st["installed_ids"], raw_items)
                next_states.append(st)  # skip is always valid
                for ci, ci_conflict in valid:
                    new_st = {
                        "child_items": st["child_items"] + [ci],
                        "child_slot_ids": st["child_slot_ids"] + [child_slot.id],
                        "child_slot_parent_item_ids": st["child_slot_parent_item_ids"] + [item.id],
                        "installed_ids": st["installed_ids"] + [ci.id],
                        "conflict": st["conflict"] or ci_conflict,
                    }
                    next_states.extend(_expand_item(new_st, ci, nested_options))
            states = next_states
        return states

    # 10. Frontier expansion + stats (pure Python, no further DB queries)
    _combo_metrics = {
        "root_candidate_count": len(all_parents),
        "child_candidate_edge_count": sum(len(items) for items in child_items_by_slot.values()),
        "nested_candidate_edge_count": sum(len(items) for items in nested_items_by_slot.values()),
        "reachable_item_count": len(
            set(all_parent_ids)
            | {item.id for items in child_items_by_slot.values() for item in items}
            | {item.id for items in nested_items_by_slot.values() for item in items}
        ),
        "frontier_peak": 0,
        "frontier_states_generated": 0,
        "frontier_cap_hits": 0,
        "nested_expansion_skips": 0,
    }

    def _stream():
        all_combos = []
        any_truncated = False
        truncation_reasons = set()

        for parent in all_parents:
            child_slots = child_slots_by_parent.get(parent.id, [])
            parent_child_slot_ids = [cs.id for cs in child_slots]
            child_options, nested_options = _pruned_options(parent, parent_child_slot_ids)
            _valid_cache.clear()  # candidate views are scoped to this root parent
            parent_name = parent.name or parent.id
            parent_conflict = parent_external_conflict.get(parent.id)

            if not child_slots:
                combo_ids = installed_ids + [parent.id]
                stats = _compute_stats(stats_base_item, combo_ids, stats_items_map, strength_level, equip_ergo_modifier)
                all_combos.append(
                    {
                        "parent_item": _ser(parent),
                        "child_items": [],
                        "child_slot_ids": [],
                        "child_slot_parent_item_ids": [],
                        "all_child_slot_ids": [],
                        "all_nested_slot_ids": [],
                        "conflict": _ser_conflict(parent_conflict),
                        **stats,
                    }
                )
                continue

            # frontier: list of dicts { child_items, child_slot_ids, child_slot_parent_item_ids, installed_ids, conflict }
            frontier = [
                {
                    "child_items": [],
                    "child_slot_ids": [],
                    "child_slot_parent_item_ids": [],
                    "installed_ids": installed_ids + [parent.id],
                    "conflict": parent_conflict,
                }
            ]

            for cs in child_slots:
                raw_candidates = child_options.get(cs.id, [])
                if not raw_candidates:
                    continue

                next_frontier = []
                seen: dict = {}
                for state in frontier:
                    inst_list = state["installed_ids"]
                    key = tuple(sorted(inst_list))
                    if key not in seen:
                        seen[key] = _validated_children(cs.id, inst_list, raw_candidates)
                    valid_children_with_conflicts = seen[key]

                    next_frontier.append(state)  # "skip this child slot" is always valid
                    for ci, ext_conflict in valid_children_with_conflicts:
                        new_state = {
                            "child_items": state["child_items"] + [ci],
                            "child_slot_ids": state["child_slot_ids"] + [cs.id],
                            "child_slot_parent_item_ids": state["child_slot_parent_item_ids"] + [parent.id],
                            "installed_ids": state["installed_ids"] + [ci.id],
                            "conflict": state["conflict"] or ext_conflict,
                        }
                        if ci.id in nested_slots_by_item:
                            _est = len(frontier)
                            for _ns in nested_slots_by_item[ci.id]:
                                _est *= 1 + len(nested_options.get(_ns.id, []))
                            if _est > _COMBO_NESTED_EXPANSION_LIMIT:
                                next_frontier.append(new_state)
                                any_truncated = True
                                truncation_reasons.add("nested_expansion_limit")
                                _combo_metrics["nested_expansion_skips"] += 1
                            else:
                                next_frontier.extend(_expand_item(new_state, ci, nested_options))
                        else:
                            next_frontier.append(new_state)

                _combo_metrics["frontier_states_generated"] += len(next_frontier)
                _combo_metrics["frontier_peak"] = max(_combo_metrics["frontier_peak"], len(next_frontier))
                frontier = next_frontier
                capped = False
                if len(frontier) > _COMBO_FRONTIER_CAP:
                    frontier = frontier[:_COMBO_FRONTIER_CAP]
                    capped = True
                    any_truncated = True
                    truncation_reasons.add("frontier_cap")
                    _combo_metrics["frontier_cap_hits"] += 1
                yield f"data: {json.dumps({'type': 'progress', 'parent': parent_name, 'slot': cs.slot_name, 'frontier': len(frontier), 'cap': _COMBO_FRONTIER_CAP, 'capped': capped})}\n\n"

            for state in frontier:
                combo_ids = installed_ids + [parent.id] + [ci.id for ci in state["child_items"]]
                stats = _compute_stats(stats_base_item, combo_ids, stats_items_map, strength_level, equip_ergo_modifier)
                _nested_sid_set = set(parent_child_slot_ids)
                for _ci in state["child_items"]:
                    for _s in nested_slots_by_item.get(_ci.id, []):
                        _nested_sid_set.add(_s.id)
                all_combos.append(
                    {
                        "parent_item": _ser(parent),
                        "child_items": [_ser(ci) for ci in state["child_items"]],
                        "child_slot_ids": state["child_slot_ids"],
                        "child_slot_parent_item_ids": state["child_slot_parent_item_ids"],
                        "all_child_slot_ids": parent_child_slot_ids,
                        "all_nested_slot_ids": list(_nested_sid_set),
                        "conflict": _ser_conflict(state["conflict"]),
                        **stats,
                    }
                )

        clean = _dedup_by_stats([c for c in all_combos if not c.get("conflict")])
        conflicted = _dedup_by_stats([c for c in all_combos if c.get("conflict")])
        result = {
            "base": base_stats,
            "combos": clean + conflicted,
            "timed_out": False,
            "truncated": any_truncated,
            "truncation_reasons": sorted(truncation_reasons),
            "metrics": {
                **_combo_metrics,
                **_pruning_metrics,
                "pruning_ms": round(_pruning_metrics["pruning_ms"], 3),
                "combo_count_before_dedup": len(all_combos),
                "combo_count": len(clean) + len(conflicted),
                "cache_hit": False,
                "processing_ms": round((time.perf_counter() - _combo_started) * 1000, 3),
            },
        }

        with _COMBO_FULL_CACHE_LOCK:
            if len(_COMBO_FULL_CACHE) >= _COMBO_FULL_CACHE_MAX:
                keys = list(_COMBO_FULL_CACHE.keys())
                for k in keys[: len(keys) // 2]:
                    del _COMBO_FULL_CACHE[k]
            _COMBO_FULL_CACHE[_cache_key] = result

        yield combo_result_event(result, response_format)

    return StreamingResponse(
        _stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"}
    )


# ---------------------------------------------------
# Weapon Optimizer (MILP solver) - MVP: weapon + mods only.
# Presets-as-base, FiR fallback pricing, multi-slot placement variables,
# TrueErgo sweep, Tchebycheff scalarization, and category filters are not
# implemented yet - see optimizer/solver.py's module docstring.
# ---------------------------------------------------

_OPTIMIZE_CACHE: dict = {}
_OPTIMIZE_CACHE_LOCK = threading.Lock()
_OPTIMIZE_CACHE_MAX = 500
MAX_INCLUDE_EXCLUDE_IDS = 100
_SOLVER_CACHE_EPOCH_LOCK = threading.Lock()
_SOLVER_CACHE_EPOCH_TRACKER = SolverCacheEpochTracker()


def _clear_solver_caches():
    """Invalidate every result derived from the synchronized item graph."""
    with _COMBO_FULL_CACHE_LOCK:
        _COMBO_FULL_CACHE.clear()
    with _OPTIMIZE_CACHE_LOCK:
        _OPTIMIZE_CACHE.clear()


def _solver_cache_generation() -> str:
    """Clear this worker's caches after another process publishes a sync."""
    with _SOLVER_CACHE_EPOCH_LOCK:
        generation, changed = _SOLVER_CACHE_EPOCH_TRACKER.refresh()
        if changed:
            _clear_solver_caches()
        return generation


# Solve concurrency guard: an optimizer call can legitimately use up to the shared
# solver's normal 30s budget plus process startup and cleanup. Without
# this, a spammed re-optimize button (or a script hitting these endpoints directly,
# bypassing the frontend's re-click guard) can pile up many overlapping solves on one
# worker's threadpool and starve every other request that worker is handling. Cap it
# to one in-flight solve per IP, plus a server-wide cap across all workers, and fail
# fast with 429 instead of silently queuing behind the threadpool.
#
# The per-IP part has to be a file, not an in-memory set: prod runs one Gunicorn
# worker *process* per CPU core (reset.py), each with its own copy of this module's
# state, so a plain dict/set would only catch a repeat request that happened to land
# on the same worker as the first one. A lock file under RUNTIME_DIR is visible to
# every worker, same as _SYNC_IN_PROGRESS_FILE above.
#
# The global cap is shared across workers too. Every solve is a spawned child process
# holding a full core and its own copy of scipy, so a per-worker cap let 2 workers run
# 4 solves on the 2 core / 2 GB prod box and starve every other request.
_SOLVE_LOCK_DIR = os.path.join(RUNTIME_DIR, "solve_locks")
os.makedirs(_SOLVE_LOCK_DIR, exist_ok=True)
_SOLVE_LOCK_STALE_SECONDS = 60
_MAX_CONCURRENT_SOLVES = OPTIMIZER_MAX_SOLVES
_SOLVE_CONCURRENCY_SEM = server_semaphore(_MAX_CONCURRENT_SOLVES, _SOLVE_LOCK_DIR, "slot")


def _ip_solve_lock_path(ip: str) -> str:
    # Hashed rather than the raw IP: keeps filenames filesystem-safe (IPv6 has
    # colons) and avoids writing raw client IPs to disk.
    return os.path.join(_SOLVE_LOCK_DIR, hashlib.sha256(ip.encode()).hexdigest() + ".lock")


def _acquire_ip_solve_lock(ip: str) -> bool:
    """Atomic create-if-absent (O_EXCL) across processes, so two workers racing
    on the same IP can't both win. A lock left behind by a worker that crashed
    mid-solve (instead of releasing normally) self-heals once it goes stale."""
    path = _ip_solve_lock_path(ip)
    for _ in range(2):  # 2nd pass only runs after clearing a stale lock
        try:
            os.close(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            return True
        except FileExistsError:
            try:
                stale = time.time() - os.path.getmtime(path) > _SOLVE_LOCK_STALE_SECONDS
            except OSError:
                continue  # lock vanished between the failed create and this check - retry
            if not stale:
                return False
            try:
                os.remove(path)
            except OSError:
                pass
    return False


def _release_ip_solve_lock(ip: str) -> None:
    try:
        os.remove(_ip_solve_lock_path(ip))
    except OSError:
        pass


# Per-IP request-rate throttle for the solve endpoints, separate from _solve_slot
# above. An identical-params request that hits _OPTIMIZE_CACHE never reaches
# _solve_slot at all (there's no solve to serialize) and returns in ~0ms - cheap
# next to a real solve, but not free: every request still opens a DB session and
# runs a real query (the weapon lookup) before the cache check ever runs. Without
# this, an autoclicker spamming the same build would sail past the concurrency
# guard entirely and still generate real per-request DB/HTTP load at whatever
# rate it fires. Same cooldown-dict pattern as _publish_last/_comment_last below,
# just keyed by IP instead of client_id_hash since these endpoints don't require
# an X-Client-ID. Checked as the first thing in each endpoint, before any DB work.
_solve_request_last: dict[str, float] = {}
_SOLVE_REQUEST_COOLDOWN = 1.0


def _check_solve_rate_limit(ip: str) -> None:
    now = time.monotonic()
    stale = [k for k, t in _solve_request_last.items() if now - t > _SOLVE_REQUEST_COOLDOWN * 20]
    for k in stale:
        del _solve_request_last[k]
    last = _solve_request_last.get(ip, 0.0)
    if now - last < _SOLVE_REQUEST_COOLDOWN:
        raise HTTPException(
            status_code=429,
            detail={
                "reason_key": "optimizer.reason.tooManyRequests",
                "message": "Too many requests - please slow down.",
            },
        )
    _solve_request_last[ip] = now


@contextlib.contextmanager
def _solve_slot(ip: str):
    """detail carries a reason_key (mirroring the optimize result's own
    reason_key/reason_params convention) so the frontend can render a
    translated message instead of this English fallback text."""
    if not _acquire_ip_solve_lock(ip):
        raise HTTPException(
            status_code=429,
            detail={
                "reason_key": "optimizer.reason.alreadySolving",
                "message": "You already have an optimization running - wait for it to finish.",
            },
        )
    try:
        if not _SOLVE_CONCURRENCY_SEM.acquire(blocking=False):
            raise HTTPException(
                status_code=429,
                detail={
                    "reason_key": "optimizer.reason.serverBusy",
                    "message": "Server is busy solving other requests - try again shortly.",
                },
            )
        try:
            yield
        finally:
            _SOLVE_CONCURRENCY_SEM.release()
    finally:
        _release_ip_solve_lock(ip)


@app.post("/build/explore")
def build_explore(request: Request, payload: ExploreRequest, db: Session = Depends(get_db)):
    ip = _get_client_ip(request)
    _check_solve_rate_limit(ip)
    if payload.trader_levels and any(level < 0 or level > 4 for level in payload.trader_levels.values()):
        raise HTTPException(status_code=422, detail="trader_levels values must be between 0 and 4")
    weapon = db.query(Item).filter(Item.id == payload.weapon_id, Item.is_weapon == True).first()  # noqa: E712
    if weapon is None:
        raise HTTPException(status_code=404, detail="Weapon not found")

    # Entered here (not inside _stream) so a busy/already-solving 429 is raised
    # synchronously with a real status code, before the streaming response - whose
    # status is committed to 200 the moment it starts - has begun sending anything.
    slot = _solve_slot(ip)
    slot.__enter__()
    released = False

    def release_slot():
        nonlocal released
        if not released:
            released = True
            slot.__exit__(None, None, None)

    def _stream():
        try:
            with contextlib.closing(
                stream_explore(payload.weapon_id, payload.optimize_params(), payload.tradeoff, payload.steps)
            ) as events:
                for event in events:
                    yield f"data: {json.dumps(event)}\n\n"
        except SolveCancelled:
            return
        finally:
            release_slot()

    return SolveStreamingResponse(
        _stream(),
        cleanup=release_slot,
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.post("/build/optimize")
def build_optimize(
    request: Request,
    weapon_id: str = Body(...),
    max_price: float | None = Body(default=None),
    min_ergonomics: float | None = Body(default=None),
    max_ergonomics: float | None = Body(default=None),
    max_recoil_v: float | None = Body(default=None),
    max_weight: float | None = Body(default=None),
    min_mag_capacity: int | None = Body(default=None),
    min_sighting_range: float | None = Body(default=None),
    include_items: List[str] = Body(default=[]),
    exclude_items: List[str] = Body(default=[]),
    include_categories: List[List[str]] = Body(default=[]),
    exclude_categories: List[str] = Body(default=[]),
    prevent_overswing: bool = Body(default=False),
    require_suppressor: bool = Body(default=False),
    max_moa: float | None = Body(default=None),
    ergo_weight: float = Body(default=1.0),
    recoil_weight: float = Body(default=1.0),
    price_weight: float = Body(default=0.0),
    trader_levels: dict | None = Body(default=None),
    flea_available: bool = Body(default=True),
    allow_unpriced: bool = Body(default=False),
    player_level: int | None = Body(default=None),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    use_true_ergo: bool = Body(default=False),
    true_ergo_k: float | None = Body(default=None),
    use_tchebycheff: bool = Body(default=True),
    assume_full_mag: bool = Body(default=True),
    selected_ammo_id: str | None = Body(default=None),
    selected_ubgl_ammo_id: str | None = Body(default=None),
    game_mode: str = Body(default="pvp"),
    db: Session = Depends(get_db),
):
    _check_solve_rate_limit(_get_client_ip(request))
    if game_mode not in VALID_GAME_MODES:
        raise HTTPException(status_code=422, detail=f"game_mode must be one of {sorted(VALID_GAME_MODES)}")
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )
    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )
    for weight_name, weight_val in (
        ("ergo_weight", ergo_weight),
        ("recoil_weight", recoil_weight),
        ("price_weight", price_weight),
    ):
        if not (0 <= weight_val <= 1):
            raise HTTPException(status_code=422, detail=f"{weight_name} must be between 0 and 1")
    if trader_levels is not None:
        for level in trader_levels.values():
            if not (0 <= level <= 4):
                raise HTTPException(status_code=422, detail="trader_levels values must be between 0 and 4")

    _cap_list("include_items", include_items, MAX_INCLUDE_EXCLUDE_IDS)
    _cap_list("exclude_items", exclude_items, MAX_INCLUDE_EXCLUDE_IDS)
    _cap_list("include_categories", include_categories, MAX_INCLUDE_EXCLUDE_IDS)
    _cap_list("exclude_categories", exclude_categories, MAX_INCLUDE_EXCLUDE_IDS)

    weapon = db.query(Item).filter(Item.id == weapon_id, Item.is_weapon == True).first()  # noqa: E712
    if not weapon:
        raise HTTPException(status_code=404, detail="Weapon not found")

    _cache_key = (
        _solver_cache_generation(),
        weapon_id,
        max_price,
        min_ergonomics,
        max_ergonomics,
        max_recoil_v,
        max_weight,
        min_mag_capacity,
        min_sighting_range,
        tuple(sorted(include_items)),
        tuple(sorted(exclude_items)),
        tuple(sorted(tuple(sorted(g)) for g in include_categories)),
        tuple(sorted(exclude_categories)),
        prevent_overswing,
        require_suppressor,
        max_moa,
        ergo_weight,
        recoil_weight,
        price_weight,
        tuple(sorted((trader_levels or {}).items())),
        flea_available,
        allow_unpriced,
        player_level,
        strength_level,
        equip_ergo_modifier,
        use_true_ergo,
        true_ergo_k,
        use_tchebycheff,
        assume_full_mag,
        selected_ammo_id,
        selected_ubgl_ammo_id,
        game_mode,
    )
    _solve_start = time.perf_counter()

    with _OPTIMIZE_CACHE_LOCK:
        cached = _OPTIMIZE_CACHE.get(_cache_key)
    if cached is not None:
        cache_processing_ms = round((time.perf_counter() - _solve_start) * 1000, 3)
        return {
            **cached,
            "metrics": {**cached.get("metrics", {}), "cache_hit": True, "processing_ms": cache_processing_ms},
            "solve_ms": round(cache_processing_ms),
        }

    params = OptimizeParams(
        max_price=max_price,
        min_ergonomics=min_ergonomics,
        max_ergonomics=max_ergonomics,
        max_recoil_v=max_recoil_v,
        max_weight=max_weight,
        min_mag_capacity=min_mag_capacity,
        min_sighting_range=min_sighting_range,
        include_items=include_items or None,
        exclude_items=exclude_items or None,
        include_categories=include_categories or None,
        exclude_categories=exclude_categories or None,
        prevent_overswing=prevent_overswing,
        require_suppressor=require_suppressor,
        max_moa=max_moa,
        ergo_weight=ergo_weight,
        recoil_weight=recoil_weight,
        price_weight=price_weight,
        trader_levels=trader_levels,
        flea_available=flea_available,
        allow_unpriced=allow_unpriced,
        player_level=player_level,
        game_mode=game_mode,
        strength_level=strength_level,
        equip_ergo_modifier=equip_ergo_modifier,
        use_true_ergo=use_true_ergo,
        true_ergo_k=true_ergo_k,
        use_tchebycheff=use_tchebycheff,
        assume_full_mag=assume_full_mag,
        selected_ammo_id=selected_ammo_id,
        selected_ubgl_ammo_id=selected_ubgl_ammo_id,
    )
    with _solve_slot(_get_client_ip(request)):
        result = run_job("optimize", weapon_id, params)
    result = {**result, "metrics": {**result.get("metrics", {}), "cache_hit": False}}

    if result.get("status") != "timeout":
        with _OPTIMIZE_CACHE_LOCK:
            if len(_OPTIMIZE_CACHE) >= _OPTIMIZE_CACHE_MAX:
                keys = list(_OPTIMIZE_CACHE.keys())
                for k in keys[: len(keys) // 2]:
                    del _OPTIMIZE_CACHE[k]
            _OPTIMIZE_CACHE[_cache_key] = result

    return {**result, "solve_ms": round((time.perf_counter() - _solve_start) * 1000)}


@app.post("/build/stat-ranges")
def build_stat_ranges(
    request: Request,
    weapon_id: str = Body(...),
    trader_levels: dict | None = Body(default=None),
    flea_available: bool = Body(default=True),
    allow_unpriced: bool = Body(default=False),
    player_level: int | None = Body(default=None),
    game_mode: str = Body(default="pvp"),
    db: Session = Depends(get_db),
):
    """Theoretical [min, max] each hard-constraint stat can reach for this
    weapon, so the optimizer UI can cap each constraint slider to what's
    actually achievable instead of an arbitrary fixed range."""
    if trader_levels is not None:
        for level in trader_levels.values():
            if not (0 <= level <= 4):
                raise HTTPException(status_code=422, detail="trader_levels values must be between 0 and 4")
    if game_mode not in VALID_GAME_MODES:
        raise HTTPException(status_code=422, detail=f"game_mode must be one of {sorted(VALID_GAME_MODES)}")

    weapon = db.query(Item).filter(Item.id == weapon_id, Item.is_weapon == True).first()  # noqa: E712
    if not weapon:
        raise HTTPException(status_code=404, detail="Weapon not found")

    params = OptimizeParams(
        trader_levels=trader_levels,
        flea_available=flea_available,
        allow_unpriced=allow_unpriced,
        player_level=player_level,
        game_mode=game_mode,
    )
    with _solve_slot(_get_client_ip(request)):
        result = run_job("stat_ranges", weapon_id, params)
    if result["status"] == "error":
        raise HTTPException(status_code=404, detail=result["reason"])
    return result


@app.post("/build/moa-floor")
def build_moa_floor(
    request: Request,
    weapon_id: str = Body(...),
    trader_levels: dict | None = Body(default=None),
    flea_available: bool = Body(default=True),
    allow_unpriced: bool = Body(default=False),
    player_level: int | None = Body(default=None),
    game_mode: str = Body(default="pvp"),
    db: Session = Depends(get_db),
):
    """Exact minimum achievable accuracy_moa for this weapon, via a binary
    search of real solves - slower than GET /build/stat-ranges's LP-relaxation
    estimate, only run when the optimizer's "Exact slider floor" toggle is on."""
    _check_solve_rate_limit(_get_client_ip(request))
    if trader_levels is not None:
        for level in trader_levels.values():
            if not (0 <= level <= 4):
                raise HTTPException(status_code=422, detail="trader_levels values must be between 0 and 4")
    if game_mode not in VALID_GAME_MODES:
        raise HTTPException(status_code=422, detail=f"game_mode must be one of {sorted(VALID_GAME_MODES)}")

    weapon = db.query(Item).filter(Item.id == weapon_id, Item.is_weapon == True).first()  # noqa: E712
    if not weapon:
        raise HTTPException(status_code=404, detail="Weapon not found")

    params = OptimizeParams(
        trader_levels=trader_levels,
        flea_available=flea_available,
        allow_unpriced=allow_unpriced,
        player_level=player_level,
        game_mode=game_mode,
    )
    with _solve_slot(_get_client_ip(request)):
        result = run_job("moa_floor", weapon_id, params)
    if result["status"] == "error":
        raise HTTPException(status_code=404, detail=result["reason"])
    return result


@app.get("/build/mods")
def build_mods(weapon_id: str, lang: str = "en", db: Session = Depends(get_db)):
    """Reachable mods for one weapon, for the optimizer's Mod Filter search
    (force-include/exclude a specific item)."""
    weapon = db.query(Item).filter(Item.id == weapon_id, Item.is_weapon == True).first()  # noqa: E712
    if not weapon:
        raise HTTPException(status_code=404, detail="Weapon not found")

    cmap = build_compatibility_map(db, weapon_id)
    if not cmap.reachable_ids:
        return {"mods": []}

    items = db.query(Item).filter(Item.id.in_(cmap.reachable_ids)).all()
    mods = [
        {
            "id": item.id,
            "name": _item_name(item, lang),
            "short_name": _item_short_name(item, lang),
            "icon": item.icon_link,
            "category": _item_category(item, lang),
            "category_priority": _category_priority(item),
        }
        for item in items
    ]
    mods.sort(key=lambda m: m["name"] or "")

    return {"mods": mods}


@app.get("/build/default-preset")
def build_default_preset(weapon_id: str, db: Session = Depends(get_db)):
    """The weapon's factory default preset as a pseudo-item the price panel can price
    exactly like any other item (its cheapest eligible trader offer + id for the flea
    lookup), so the panel can weigh 'buy the bare receiver + parts' against 'buy the
    assembled factory preset' the same way the optimizer's _choose_base does. Returns
    {"preset": null} for weapons that have no default preset (melee, throwables)."""
    row = db.query(WeaponDefaultPreset).filter(WeaponDefaultPreset.weapon_id == weapon_id).first()
    if not row:
        return {"preset": None}
    # Cheapest trader offer, mirroring how sync computes Item.trader_price_rub (same
    # excluded vendors) so the preset prices consistently with every other item row.
    excluded = {"ragman", "ref", "fence", "flea-market"}
    offers = (
        db.query(ItemOffer).filter(ItemOffer.item_id == row.preset_id, ItemOffer.is_flea == False).all()  # noqa: E712
    )
    eligible = [o for o in offers if o.vendor_normalized not in excluded and o.price_rub is not None]
    cheapest = min(eligible, key=lambda o: o.price_rub) if eligible else None
    return {
        "preset": {
            "id": row.preset_id,
            "trader_price_rub": cheapest.price_rub if cheapest else None,
            "trader_vendor": cheapest.vendor_normalized if cheapest else None,
            "trader_min_level": cheapest.trader_level if cheapest else None,
        }
    }


@app.get("/build/gunsmith-tasks")
def build_gunsmith_tasks(lang: str = "en", db: Session = Depends(get_db)):
    return {"tasks": get_gunsmith_tasks(db, lang)}


@app.post("/build/gunsmith-solve")
def build_gunsmith_solve(
    request: Request,
    task_name: str = Body(...),
    trader_levels: dict | None = Body(default=None),
    flea_available: bool = Body(default=True),
    player_level: int | None = Body(default=None),
    strength_level: int = Body(default=10),
    equip_ergo_modifier: float = Body(default=0.0),
    game_mode: str = Body(default="pvp"),
    db: Session = Depends(get_db),
):
    _check_solve_rate_limit(_get_client_ip(request))
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )
    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )
    if trader_levels is not None:
        for level in trader_levels.values():
            if not (0 <= level <= 4):
                raise HTTPException(status_code=422, detail="trader_levels values must be between 0 and 4")
    if game_mode not in VALID_GAME_MODES:
        raise HTTPException(status_code=422, detail=f"game_mode must be one of {sorted(VALID_GAME_MODES)}")

    with _solve_slot(_get_client_ip(request)):
        result = run_gunsmith(
            task_name,
            trader_levels=trader_levels,
            flea_available=flea_available,
            player_level=player_level,
            strength_level=strength_level,
            equip_ergo_modifier=equip_ergo_modifier,
            game_mode=game_mode,
        )
    if result["status"] == "error":
        raise HTTPException(status_code=404, detail=result["reason"])
    return result


# ---------------------------------------------------
# Gun Init (single-request gun selection bootstrap)
# ---------------------------------------------------


def _resolve_factory_tree(
    gun_id: str,
    factory_ids: list,
    known_ids: set,
    slot_ids_by_item: dict,
    factory_allowed_by_slot: dict,
) -> dict:
    """Place a weapon's flat factory attachment list into slots, as
    {slot_id: {"item_id": ..., "children": {...}}}."""
    # Determine which factory items can fit inside another factory item's slots.
    # These are "child candidates" and must be processed after their potential parents
    # so the parent can claim its gun-level slot first.
    factory_item_ids = set(factory_ids)
    factory_child_ids: set[str] = set()
    for parent_id, slot_ids in slot_ids_by_item.items():
        if parent_id in factory_item_ids:
            for slot_id in slot_ids:
                factory_child_ids.update(fid for fid in factory_allowed_by_slot.get(slot_id, set()) if fid != parent_id)

    def _sort_ids(ids: list) -> list:
        """Parents (not a child of any factory item) first, child-candidates last."""
        return [fid for fid in ids if fid not in factory_child_ids] + [fid for fid in ids if fid in factory_child_ids]

    # Each slot is only filled once (first match wins) to prevent a later item
    # from overwriting an earlier one that already claimed that slot.
    def _resolve_children(node_item_id: str, remaining_ids: list) -> dict:
        children = {}
        node_slot_ids = slot_ids_by_item.get(node_item_id, [])
        for attachment_id in _sort_ids(remaining_ids):
            if attachment_id not in known_ids:
                continue
            for slot_id in node_slot_ids:
                if slot_id not in children and attachment_id in factory_allowed_by_slot.get(slot_id, set()):
                    other_ids = [fid for fid in remaining_ids if fid != attachment_id]
                    children[slot_id] = {
                        "item_id": attachment_id,
                        "children": _resolve_children(attachment_id, other_ids),
                    }
                    break
        return children

    return _resolve_children(gun_id, factory_ids)


def _factory_pairs(db: Session, gun: Item) -> list:
    """The weapon's factory preset as [[slot_id, item_id], ...], parents first."""
    factory_ids = [f.strip() for f in (gun.factory_attachment_ids or "").split(",") if f.strip()]
    if not factory_ids:
        return []
    known_ids = {row.id for row in db.query(Item.id).filter(Item.id.in_(factory_ids)).all()}
    slot_ids_by_item: dict[str, list] = {iid: [] for iid in {gun.id} | set(factory_ids)}
    for slot in db.query(Slot).filter(Slot.parent_item_id.in_(list(slot_ids_by_item))).all():
        slot_ids_by_item[slot.parent_item_id].append(slot.id)
    all_slot_ids = [sid for sids in slot_ids_by_item.values() for sid in sids]
    factory_allowed_by_slot: dict[str, set] = {}
    for rec in (
        db.query(SlotAllowedItem)
        .filter(SlotAllowedItem.slot_id.in_(all_slot_ids), SlotAllowedItem.allowed_item_id.in_(factory_ids))
        .all()
    ):
        factory_allowed_by_slot.setdefault(rec.slot_id, set()).add(rec.allowed_item_id)

    pairs: list = []

    def _walk(tree: dict):
        for slot_id, node in tree.items():
            pairs.append([slot_id, node["item_id"]])
            _walk(node["children"])

    _walk(_resolve_factory_tree(gun.id, factory_ids, known_ids, slot_ids_by_item, factory_allowed_by_slot))
    return pairs


@app.get("/guns/{gun_id}/image")
async def get_gun_image(gun_id: str, bare: bool = False, db: Session = Depends(get_db)):
    """The weapon's factory preset (or bare receiver) drawn by Kitbash!, for weapons
    tarkov.dev has no image for yet. Redirects to tarkov.dev's unknown-item image
    when Kitbash! lacks a part."""
    gun = db.get(Item, gun_id)
    if not gun or not gun.is_weapon:
        raise HTTPException(status_code=404, detail="Gun not found")
    # Only draw guns tarkov.dev has no image for, the ones /guns points here. Any
    # other gun goes to its tarkov.dev image, so nobody can make us draw them all.
    link = gun.bare_image_512_link if bare else gun.image_512_link
    if link != UNKNOWN_IMAGE_512:
        return RedirectResponse(
            link or UNKNOWN_IMAGE_512, status_code=302, headers={"Cache-Control": "public, max-age=3600"}
        )
    if build_images.available():
        try:
            items = _build_spt_items(gun_id, [] if bare else _factory_pairs(db, gun))
            data, _ = await asyncio.to_thread(build_images.render_webp, build_image_key(gun_id, items), items)
            return Response(content=data, media_type="image/webp", headers={"Cache-Control": "public, max-age=3600"})
        except (build_images.Unrenderable, ValueError) as exc:
            _logger.info("gun-image Kitbash! cannot draw %s: %s", gun_id, exc)
    return RedirectResponse(UNKNOWN_IMAGE_512, status_code=302, headers={"Cache-Control": "public, max-age=3600"})


@app.get("/guns/{gun_id}/init")
def get_gun_init(
    gun_id: str,
    lang: str = "en",
    strength_level: int = 10,
    equip_ergo_modifier: float = 0.0,
    selected_ammo_id: str | None = None,
    selected_ubgl_ammo_id: str | None = None,
    assume_full_mag: bool = True,
    db: Session = Depends(get_db),
):
    if not (STRENGTH_LEVEL_MIN <= strength_level <= STRENGTH_LEVEL_MAX):
        raise HTTPException(
            status_code=422, detail=f"strength_level must be between {STRENGTH_LEVEL_MIN} and {STRENGTH_LEVEL_MAX}"
        )

    if not (EQUIP_ERGO_MIN <= equip_ergo_modifier <= EQUIP_ERGO_MAX):
        raise HTTPException(
            status_code=422, detail=f"equip_ergo_modifier must be between {EQUIP_ERGO_MIN} and {EQUIP_ERGO_MAX}"
        )

    gun = db.query(Item).filter(Item.id == gun_id).first()
    if not gun:
        raise HTTPException(status_code=404, detail="Gun not found")

    factory_ids = [f.strip() for f in (gun.factory_attachment_ids or "").split(",") if f.strip()]

    # Batch-load all factory attachment items (1 query)
    factory_items_map = {}
    if factory_ids:
        factory_items_map = {item.id: item for item in db.query(Item).filter(Item.id.in_(factory_ids)).all()}

    # Batch-load all slots for gun + all factory items (1 query)
    all_item_ids = {gun_id} | set(factory_ids)
    all_slots = db.query(Slot).filter(Slot.parent_item_id.in_(all_item_ids)).all()
    all_slot_ids = [s.id for s in all_slots]

    # Count allowed items per slot for has_allowed_items (1 query)
    slot_counts = {}
    if all_slot_ids:
        slot_counts = dict(
            db.query(SlotAllowedItem.slot_id, func.count(SlotAllowedItem.allowed_item_id))
            .filter(SlotAllowedItem.slot_id.in_(all_slot_ids))
            .group_by(SlotAllowedItem.slot_id)
            .all()
        )

    # Build slots_by_item for frontend slotCache population
    slots_by_item: dict[str, list] = {iid: [] for iid in all_item_ids}
    for s in all_slots:
        slots_by_item[s.parent_item_id].append(
            {
                "id": s.id,
                "parent_item_id": s.parent_item_id,
                "slot_name": s.slot_name,
                "slot_game_name": s.slot_game_name,
                "has_allowed_items": slot_counts.get(s.id, 0) > 0,
            }
        )

    # Find which factory items are allowed in which slots (1 query)
    factory_allowed_by_slot: dict[str, set] = {}
    if all_slot_ids and factory_ids:
        for rec in (
            db.query(SlotAllowedItem)
            .filter(
                SlotAllowedItem.slot_id.in_(all_slot_ids),
                SlotAllowedItem.allowed_item_id.in_(factory_ids),
            )
            .all()
        ):
            factory_allowed_by_slot.setdefault(rec.slot_id, set()).add(rec.allowed_item_id)

    # Serialize a factory attachment item (same shape as /slots/{id}/allowed-items)
    def _fmt_item(item):
        return {
            "id": item.id,
            "name": _item_name(item, lang),
            "short_name": _item_short_name(item, lang),
            "weight": item.weight,
            "ergonomics_modifier": item.ergonomics_modifier,
            "recoil_modifier": item.recoil_modifier,
            "accuracy_modifier": item.accuracy_modifier,
            "center_of_impact": item.center_of_impact,
            "deviation_curve": item.deviation_curve,
            "deviation_max": item.deviation_max,
            "sighting_range": item.sighting_range,
            "heat_factor": item.heat_factor,
            "cooling_factor": item.cooling_factor,
            "durability_burn_factor": item.durability_burn_factor,
            "velocity_modifier": item.velocity_modifier,
            "loudness": item.loudness,
            "icon_link": item.icon_link,
            "base_image_link": item.base_image_link,
            "conflicting_item_ids": item.conflicting_item_ids,
            "conflicting_slot_ids": item.conflicting_slot_ids,
            "magazine_capacity": item.magazine_capacity,
            "caliber": item.caliber,
            "is_weapon": item.is_weapon,
            "trader_price": item.trader_price,
            "trader_price_rub": item.trader_price_rub,
            "trader_currency": item.trader_currency,
            "trader_vendor": item.trader_vendor,
            "trader_min_level": item.trader_min_level,
        }

    slot_ids_by_item = {iid: [slot["id"] for slot in slots] for iid, slots in slots_by_item.items()}
    id_tree = _resolve_factory_tree(
        gun_id, factory_ids, set(factory_items_map), slot_ids_by_item, factory_allowed_by_slot
    )

    def _fmt_tree(tree: dict) -> dict:
        return {
            slot_id: {"item": _fmt_item(factory_items_map[node["item_id"]]), "children": _fmt_tree(node["children"])}
            for slot_id, node in tree.items()
        }

    factory_tree = _fmt_tree(id_tree)

    # Load ammo for caliber (1 query)
    ammo_list = []
    if gun.caliber:
        ammo_list = [
            {
                "id": a.id,
                "name": _item_name(a, lang),
                "short_name": _item_short_name(a, lang),
                "weight": a.weight,
                "icon_link": a.icon_link,
                "trader_price": a.trader_price,
                "trader_price_rub": a.trader_price_rub,
                "trader_currency": a.trader_currency,
                "trader_vendor": a.trader_vendor,
                "trader_min_level": a.trader_min_level,
            }
            for a in db.query(Item)
            .filter(
                Item.is_ammo == True,
                Item.caliber == gun.caliber,
            )
            .order_by(Item.weight.asc())
            .all()
        ]

    # Compute build stats with factory attachments
    stats = _compute_stats(gun, factory_ids, factory_items_map, strength_level, equip_ergo_modifier)

    # Apply ammo weight + heat/durability-burn if a valid ammo ID was provided.
    # Shares apply_full_mag_ammo() with /build/calculate and the optimizer's post-solve
    # final_stats - must stay in sync or the very first stats shown on gun load (from this
    # endpoint) disagree with every subsequent recalculation.
    # Falls back to the first ammo in the list (same ordering the frontend's <select>
    # defaults to) when the caller has no saved per-caliber preference yet, so a
    # first-time visitor sees a real muzzle velocity instead of "No Ammo".
    effective_ammo_id = selected_ammo_id or (ammo_list[0]["id"] if ammo_list else None)

    ammo = (
        db.query(Item).filter(Item.id == effective_ammo_id).first() if (assume_full_mag and effective_ammo_id) else None
    )
    ubgl_grenade = (
        db.query(Item).filter(Item.id == selected_ubgl_ammo_id).first()
        if (assume_full_mag and selected_ubgl_ammo_id)
        else None
    )
    apply_full_mag_ammo(stats, factory_items_map, ammo, ubgl_grenade, strength_level, equip_ergo_modifier)

    # Fetch UBGL grenade ammo list - find any factory UBGL by caliber (UBGLs are non-ammo items with a caliber)
    ubgl_ammo_list = []
    ubgl_caliber = next(
        (
            att.caliber
            for att in factory_items_map.values()
            if att.caliber and not att.is_ammo and not att.magazine_capacity
        ),
        None,
    )
    if ubgl_caliber:
        ubgl_ammo_list = [
            {
                "id": a.id,
                "name": _item_name(a, lang),
                "short_name": _item_short_name(a, lang),
                "weight": a.weight,
                "icon_link": a.icon_link,
                "trader_price": a.trader_price,
                "trader_price_rub": a.trader_price_rub,
                "trader_currency": a.trader_currency,
                "trader_vendor": a.trader_vendor,
                "trader_min_level": a.trader_min_level,
            }
            for a in db.query(Item)
            .filter(
                Item.is_ammo == True,
                Item.caliber == ubgl_caliber,
            )
            .order_by(Item.weight.asc())
            .all()
        ]

    return {
        "slots_by_item": slots_by_item,
        "factory_tree": factory_tree,
        "factory_attachment_ids": factory_ids,
        "ammo": ammo_list,
        "ubgl_ammo": ubgl_ammo_list,
        "stats": stats,
    }


# ---------------------------------------------------
# Attachment Ratings
# ---------------------------------------------------


@app.get("/ratings/attachments/bulk")
def get_bulk_ratings(ids: str, x_client_id: str = Header(None), db: Session = Depends(get_ratings_db)):
    if len(ids) > 4000:
        raise HTTPException(status_code=413, detail="ids parameter too long")
    raw_ids = [i.strip() for i in ids.split(",") if i.strip()]
    if not raw_ids:
        raise HTTPException(status_code=400, detail="ids parameter is required")
    if len(raw_ids) > 200:
        raise HTTPException(status_code=400, detail="Too many ids (max 200)")
    for item_id in raw_ids:
        _validate_item_id(item_id)
    unique_ids = list(dict.fromkeys(raw_ids))  # deduplicate, preserve order

    # use client token hash for vote lookup; fall back to no user_vote if absent
    client_hash = _get_optional_client_id_hash(x_client_id)

    rating_rows = db.query(AttachmentRating).filter(AttachmentRating.item_id.in_(unique_ids)).all()
    ratings_map = {r.item_id: r for r in rating_rows}

    votes_map = {}
    if client_hash:
        vote_rows = (
            db.query(AttachmentVote)
            .filter(
                AttachmentVote.item_id.in_(unique_ids),
                AttachmentVote.ip_hash == client_hash,
            )
            .all()
        )
        votes_map = {v.item_id: v.vote for v in vote_rows}

    result = {}
    for item_id in unique_ids:
        r = ratings_map.get(item_id)
        result[item_id] = {
            "likes": r.like_count if r else 0,
            "dislikes": r.dislike_count if r else 0,
            "user_vote": votes_map.get(item_id),
        }

    return {"ratings": result}


@app.post("/ratings/attachments/{item_id}/vote")
def post_vote(
    item_id: str,
    vote: str = Body(..., embed=True),
    x_client_id: str = Header(None),
    db: Session = Depends(get_ratings_db),
):
    _validate_item_id(item_id)
    if vote not in ("like", "dislike"):
        raise HTTPException(status_code=422, detail='vote must be "like" or "dislike"')

    ip_hash = _get_client_id_hash(x_client_id)

    existing = (
        db.query(AttachmentVote)
        .filter(
            AttachmentVote.item_id == item_id,
            AttachmentVote.ip_hash == ip_hash,
        )
        .first()
    )

    if existing is None:
        db.add(AttachmentVote(item_id=item_id, ip_hash=ip_hash, vote=vote))
        _upsert_rating(db, item_id, like_delta=1 if vote == "like" else 0, dislike_delta=1 if vote == "dislike" else 0)
        result_vote = vote
    elif existing.vote == vote:
        db.delete(existing)
        _upsert_rating(
            db, item_id, like_delta=-1 if vote == "like" else 0, dislike_delta=-1 if vote == "dislike" else 0
        )
        result_vote = None
    else:
        existing.vote = vote
        existing.created_at = datetime.now(timezone.utc)
        like_d = 1 if vote == "like" else -1
        dislike_d = 1 if vote == "dislike" else -1
        _upsert_rating(db, item_id, like_delta=like_d, dislike_delta=dislike_d)
        result_vote = vote

    db.commit()

    rating = db.query(AttachmentRating).filter(AttachmentRating.item_id == item_id).first()
    return {
        "likes": rating.like_count if rating else 0,
        "dislikes": rating.dislike_count if rating else 0,
        "user_vote": result_vote,
    }


@app.delete("/ratings/attachments/{item_id}/vote")
def delete_vote(item_id: str, x_client_id: str = Header(None), db: Session = Depends(get_ratings_db)):
    _validate_item_id(item_id)
    ip_hash = _get_client_id_hash(x_client_id)

    existing = (
        db.query(AttachmentVote)
        .filter(
            AttachmentVote.item_id == item_id,
            AttachmentVote.ip_hash == ip_hash,
        )
        .first()
    )

    if existing:
        old_vote = existing.vote
        db.delete(existing)
        _upsert_rating(
            db, item_id, like_delta=-1 if old_vote == "like" else 0, dislike_delta=-1 if old_vote == "dislike" else 0
        )
        db.commit()

    rating = db.query(AttachmentRating).filter(AttachmentRating.item_id == item_id).first()
    return {
        "likes": rating.like_count if rating else 0,
        "dislikes": rating.dislike_count if rating else 0,
        "user_vote": None,
    }


@app.delete("/admin/ratings/attachments/{item_id}")
def admin_clear_rating(
    item_id: str, request: Request, x_admin_key: str = Header(None), db: Session = Depends(get_ratings_db)
):
    _require_admin(request, x_admin_key)
    _validate_item_id(item_id)

    db.query(AttachmentVote).filter(AttachmentVote.item_id == item_id).delete()
    db.query(AttachmentRating).filter(AttachmentRating.item_id == item_id).delete()
    db.commit()

    return {"cleared": True, "item_id": item_id}


def _upsert_rating(db: Session, item_id: str, like_delta: int, dislike_delta: int) -> None:
    """Insert or update the rating summary row atomically."""
    existing = db.query(AttachmentRating).filter(AttachmentRating.item_id == item_id).first()
    if existing is None:
        db.add(
            AttachmentRating(
                item_id=item_id,
                like_count=max(0, like_delta),
                dislike_count=max(0, dislike_delta),
                last_updated=datetime.now(timezone.utc),
            )
        )
    else:
        existing.like_count = max(0, existing.like_count + like_delta)
        existing.dislike_count = max(0, existing.dislike_count + dislike_delta)
        existing.last_updated = datetime.now(timezone.utc)


# ---------------------------------------------------
# Build Ratings
# ---------------------------------------------------


def _validate_build_id_positive(build_id: int) -> None:
    if build_id <= 0:
        raise HTTPException(status_code=400, detail="Invalid build_id")


def _upsert_build_rating(db: Session, build_id: int, like_delta: int, dislike_delta: int) -> None:
    existing = db.query(BuildRating).filter(BuildRating.build_id == build_id).first()
    if existing is None:
        db.add(
            BuildRating(
                build_id=build_id,
                like_count=max(0, like_delta),
                dislike_count=max(0, dislike_delta),
                last_updated=datetime.now(timezone.utc),
            )
        )
    else:
        existing.like_count = max(0, existing.like_count + like_delta)
        existing.dislike_count = max(0, existing.dislike_count + dislike_delta)
        existing.last_updated = datetime.now(timezone.utc)


@app.get("/ratings/builds/bulk")
def get_bulk_build_ratings(ids: str, x_client_id: str = Header(None), db: Session = Depends(get_builds_db)):
    if len(ids) > 4000:
        raise HTTPException(status_code=413, detail="ids parameter too long")
    raw_ids = [i.strip() for i in ids.split(",") if i.strip()]
    if not raw_ids:
        raise HTTPException(status_code=400, detail="ids parameter is required")
    if len(raw_ids) > 200:
        raise HTTPException(status_code=400, detail="Too many ids (max 200)")

    try:
        int_ids = [int(i) for i in raw_ids]
    except ValueError:
        raise HTTPException(status_code=400, detail="ids must be integers")
    unique_ids = list(dict.fromkeys(int_ids))

    client_hash = _get_optional_client_id_hash(x_client_id)

    rating_rows = db.query(BuildRating).filter(BuildRating.build_id.in_(unique_ids)).all()
    ratings_map = {r.build_id: r for r in rating_rows}

    votes_map = {}
    if client_hash:
        vote_rows = (
            db.query(BuildVote)
            .filter(
                BuildVote.build_id.in_(unique_ids),
                BuildVote.ip_hash == client_hash,
            )
            .all()
        )
        votes_map = {v.build_id: v.vote for v in vote_rows}

    result = {}
    for build_id in unique_ids:
        r = ratings_map.get(build_id)
        result[str(build_id)] = {
            "likes": r.like_count if r else 0,
            "dislikes": r.dislike_count if r else 0,
            "user_vote": votes_map.get(build_id),
        }

    return {"ratings": result}


@app.post("/ratings/builds/{build_id}/vote")
def post_build_vote(
    build_id: int,
    vote: str = Body(..., embed=True),
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _validate_build_id_positive(build_id)
    if vote != "like":
        raise HTTPException(status_code=422, detail='vote must be "like"')

    if not db.query(PublicBuild.id).filter(PublicBuild.id == build_id).first():
        raise HTTPException(status_code=404, detail="Build not found.")

    ip_hash = _get_client_id_hash(x_client_id)

    existing = (
        db.query(BuildVote)
        .filter(
            BuildVote.build_id == build_id,
            BuildVote.ip_hash == ip_hash,
        )
        .first()
    )

    if existing is None:
        db.add(BuildVote(build_id=build_id, ip_hash=ip_hash, vote=vote))
        _upsert_build_rating(
            db, build_id, like_delta=1 if vote == "like" else 0, dislike_delta=1 if vote == "dislike" else 0
        )
        result_vote = vote
    elif existing.vote == vote:
        db.delete(existing)
        _upsert_build_rating(
            db, build_id, like_delta=-1 if vote == "like" else 0, dislike_delta=-1 if vote == "dislike" else 0
        )
        result_vote = None
    else:
        existing.vote = vote
        existing.created_at = datetime.now(timezone.utc)
        like_d = 1 if vote == "like" else -1
        dislike_d = 1 if vote == "dislike" else -1
        _upsert_build_rating(db, build_id, like_delta=like_d, dislike_delta=dislike_d)
        result_vote = vote

    db.commit()

    rating = db.query(BuildRating).filter(BuildRating.build_id == build_id).first()
    return {
        "likes": rating.like_count if rating else 0,
        "dislikes": rating.dislike_count if rating else 0,
        "user_vote": result_vote,
    }


@app.delete("/ratings/builds/{build_id}/vote")
def delete_build_vote(build_id: int, x_client_id: str = Header(None), db: Session = Depends(get_builds_db)):
    _validate_build_id_positive(build_id)
    ip_hash = _get_client_id_hash(x_client_id)

    existing = (
        db.query(BuildVote)
        .filter(
            BuildVote.build_id == build_id,
            BuildVote.ip_hash == ip_hash,
        )
        .first()
    )

    if existing:
        old_vote = existing.vote
        db.delete(existing)
        _upsert_build_rating(
            db, build_id, like_delta=-1 if old_vote == "like" else 0, dislike_delta=-1 if old_vote == "dislike" else 0
        )
        db.commit()

    rating = db.query(BuildRating).filter(BuildRating.build_id == build_id).first()
    return {
        "likes": rating.like_count if rating else 0,
        "dislikes": rating.dislike_count if rating else 0,
        "user_vote": None,
    }


# ---------------------------------------------------
# Build Images
# Kitbash! draws each build in process from baked sprites
# (see build_images.py) and keeps its own render cache.
# ---------------------------------------------------

_IMGGEN_HEALTH_CACHE: dict = {}  # {"status": str, "ts": float, "error": str|None}
_IMGGEN_HEALTH_TTL = 300  # 5 min - one real probe per UptimeRobot polling cycle


@app.get("/build-image/status")
async def build_image_status():
    # The About dialog shows the Kitbash! commit even while the kill switch is on.
    return {
        "disabled": _imggen_disabled or not build_images.available(),
        # Reads Kitbash!'s 6 MB manifest the first time in each worker.
        "kitbash": await asyncio.to_thread(build_images.version),
    }


@app.api_route("/health/imggen", methods=["GET", "HEAD"])
async def health_imggen():
    """Renders the newest community build with Kitbash! and returns 200/{"status":"ok"} or 503.
    Result is cached for _IMGGEN_HEALTH_TTL seconds so UptimeRobot polling
    doesn't trigger a render on every check."""
    now = time.monotonic()
    cached = _IMGGEN_HEALTH_CACHE.get("result")
    if cached and (now - cached["ts"]) < _IMGGEN_HEALTH_TTL:
        if cached["status"] == "ok":
            return {"status": "ok"}
        raise HTTPException(status_code=503, detail=cached.get("error", "down"))

    with BuildsSessionLocal() as bdb:
        build = bdb.query(PublicBuild).filter(PublicBuild.pairs_json != "[]").order_by(PublicBuild.id.desc()).first()
    if not build:
        raise HTTPException(status_code=503, detail="No builds available for probe")

    pairs = json.loads(build.pairs_json)
    try:
        if not build_images.available():
            raise RuntimeError("Kitbash! is not installed")
        items = _build_spt_items(build.gun_id, pairs)
        await asyncio.to_thread(build_images.render_webp, build_image_key(build.gun_id, items), items)
        _IMGGEN_HEALTH_CACHE["result"] = {"status": "ok", "ts": now, "error": None}
        return {"status": "ok"}
    except Exception as exc:
        err = str(exc)
        _IMGGEN_HEALTH_CACHE["result"] = {"status": "down", "ts": now, "error": err}
        raise HTTPException(status_code=503, detail=err)


# The old image-gen queue used to be the only throttle on /build-image. A render
# is a few ms of CPU behind build_images' per-worker lock, so we cap both how
# fast one IP may ask (a token bucket that allows the bursts of quick attachment
# swaps) and how many renders may queue on that lock, and answer 429 past
# either. The frontend treats any failed render as "show the static image".
# Per worker process, unlike _SOLVE_CONCURRENCY_SEM: a render is a few ms of in-process CPU.
_IMAGE_BURST = 20
_IMAGE_REFILL_PER_SEC = 4.0
_image_buckets: dict[str, tuple[float, float]] = {}  # ip -> (tokens, last refill)
_image_buckets_lock = threading.Lock()
_MAX_QUEUED_RENDERS = 8
_RENDER_QUEUE_SEM = threading.BoundedSemaphore(_MAX_QUEUED_RENDERS)


def _take_image_token(ip: str) -> bool:
    now = time.monotonic()
    with _image_buckets_lock:
        # Any bucket idle long enough to refill completely is back to the default, so drop it.
        full_after = _IMAGE_BURST / _IMAGE_REFILL_PER_SEC
        for k in [k for k, (_, t) in _image_buckets.items() if now - t > full_after]:
            del _image_buckets[k]
        tokens, last = _image_buckets.get(ip, (float(_IMAGE_BURST), now))
        tokens = min(_IMAGE_BURST, tokens + (now - last) * _IMAGE_REFILL_PER_SEC)
        if tokens < 1:
            _image_buckets[ip] = (tokens, now)
            return False
        _image_buckets[ip] = (tokens - 1, now)
        return True


def _render_limited(*args) -> tuple[bytes, list[str]]:
    if not _RENDER_QUEUE_SEM.acquire(blocking=False):
        raise HTTPException(status_code=429, detail="Image renderer is busy - try again shortly.")
    try:
        return build_images.render_webp(*args)
    finally:
        _RENDER_QUEUE_SEM.release()


@app.post("/build-image")
async def build_image(
    request: Request,
    id: str = Body(...),
    items: List[dict] = Body(...),
    source: Literal["preview", "hover", "optimizer", "export"] = Body("preview"),
    db: Session = Depends(get_db),
    # "Assume Full Magazine": Kitbash! draws the build's magazines full of this ammo
    # and its UBGL loaded, as the game does.
    assume_full_mag: Annotated[bool, Body()] = False,
    selected_ammo_id: Annotated[str | None, Body()] = None,
    selected_ubgl_ammo_id: Annotated[str | None, Body()] = None,
):
    if _imggen_disabled or not build_images.available():
        raise HTTPException(status_code=503, detail="Build preview generation is temporarily disabled")
    if not _take_image_token(_get_client_ip(request)):
        raise HTTPException(status_code=429, detail="Too many image requests - please slow down.")

    _cap_list("items", items, MAX_IMAGE_ITEMS)

    weapon = db.get(Item, id)
    if not weapon:
        raise HTTPException(status_code=404, detail=f"Unknown weapon id: {id}")
    if not weapon.is_weapon:
        raise HTTPException(status_code=422, detail="Build image root must be a weapon")
    # Kitbash! chambers a round even without a magazine, so the ammo always counts.
    ammo, ubgl_ammo = (selected_ammo_id or None, selected_ubgl_ammo_id or None) if assume_full_mag else (None, None)
    try:
        cache_key = build_image_key(id, items)
        render_key = loaded_image_key(cache_key, ammo, ubgl_ammo)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    try:
        data, skipped = await asyncio.to_thread(_render_limited, render_key, items, ammo, ubgl_ammo)
    except build_images.UnsupportedWeapon as exc:
        _logger.info("build-image Kitbash! cannot draw weapon %s source=%s: %s", id, source, exc)
        raise HTTPException(
            status_code=422,
            detail={"code": "unsupported_weapon", "message": f"Kitbash! cannot draw this weapon: {exc}"},
        )
    except build_images.Unrenderable as exc:
        _logger.info("build-image Kitbash! cannot draw build=%s source=%s: %s", cache_key[:16], source, exc)
        raise HTTPException(status_code=422, detail=f"Kitbash! cannot draw this build: {exc}")
    if skipped:
        _logger.info("build-image Kitbash! left out %s in build=%s source=%s", skipped, cache_key[:16], source)
    # Parts Kitbash! cannot draw yet are left out of the image rather than failing it.
    return {"image_url": build_images.data_url(data), "skipped": skipped}


# ---------------------------------------------------
# Background build-image migration worker
# Draws card images for all community builds with Kitbash!
# and stores them permanently in the Gitee asset repo.
# ---------------------------------------------------


def _bp_hex24(s: str) -> str:
    """Port of the frontend _bpHex24 hash.
    Produces a 24-char hex instance ID - must match the JS implementation exactly."""
    MASK = 0xFFFFFFFF
    h1, h2, h3 = 0x6B4A1C7F, 0x3E9D5A2B, 0xD1E4C7A9
    for ch in s:
        c = ord(ch)
        h1 = ((h1 ^ c) * 0x9E3779B9) & MASK
        h2 = ((h2 ^ c) * 0x85EBCA6B) & MASK
        h3 = ((h3 ^ c) * 0xC2B2AE35) & MASK
        h1 ^= (h2 >> 13) ^ (h3 >> 7)
        h2 ^= (h1 >> 17) ^ (h3 >> 5)
        h3 ^= (h1 >> 11) ^ (h2 >> 19)
    h1 = (h1 ^ h2 ^ h3) & MASK
    h2 = (h2 ^ ((h1 * 0x27D4EB2D) & MASK)) & MASK
    h3 = (h3 ^ ((h2 * 0x165667B1) & MASK)) & MASK
    return "".join(f"{v:08x}" for v in (h1, h2, h3))


def _build_spt_items(gun_id: str, pairs: list) -> list:
    """Convert pairs [[slot_id, item_id], ...] to the SPT-format items array
    Kitbash! renders, matching the frontend _bpBuildSptItems() exactly."""
    gun_instance_id = _bp_hex24(gun_id + ":root")
    items = [
        {
            "_id": gun_instance_id,
            "_tpl": gun_id,
            "slotId": "hideout",
            "parentId": "hideout",
        }
    ]

    if not pairs:
        return items

    slot_ids = [p[0] for p in pairs]
    with SessionLocal() as db:
        slots = db.query(Slot).filter(Slot.id.in_(slot_ids)).all()
    slot_map = {s.id: s for s in slots}

    # tracks item template id -> instance id so children can find their parent
    instance_map: dict[str, str] = {gun_id: gun_instance_id}

    for slot_id, item_id in pairs:
        slot = slot_map.get(slot_id)
        if not slot:
            raise ValueError(f"Unknown build image slot: {slot_id}")
        game_slot_name = slot.slot_game_name or slot.slot_name
        parent_instance = instance_map.get(slot.parent_item_id)
        if not parent_instance:
            raise ValueError(f"Unresolved build image parent for slot: {slot_id}")
        instance_id = _bp_hex24(parent_instance + ":" + game_slot_name)
        items.append(
            {
                "_id": instance_id,
                "_tpl": item_id,
                "slotId": game_slot_name,
                "parentId": parent_instance,
            }
        )
        instance_map[item_id] = instance_id

    return items


_GITEE_API = "https://gitee.com/api/v5"
_GITEE_OWNER = "morph1ne"
_GITEE_REPO = "eftforge-assets"
_GITEE_FOLDER = "streaming-assets/build-images"
_GITEE_BRANCH = "master"
_GITEE_RAW_PREFIX = f"https://gitee.com/{_GITEE_OWNER}/{_GITEE_REPO}" f"/raw/{_GITEE_BRANCH}/{_GITEE_FOLDER}/"

_GITEE_AVATAR_FOLDER = "streaming-assets/avatars"
_GITEE_AVATAR_PREFIX = f"https://gitee.com/{_GITEE_OWNER}/{_GITEE_REPO}" f"/raw/{_GITEE_BRANCH}/{_GITEE_AVATAR_FOLDER}/"


def _gitee_upload_sync(filename: str, image_bytes: bytes, token: str) -> str:
    """Upload or overwrite a build image in the Gitee asset repo.
    Returns the permanent raw URL for the file."""
    import requests as _req

    path = f"{_GITEE_FOLDER}/{filename}"
    api_url = f"{_GITEE_API}/repos/{_GITEE_OWNER}/{_GITEE_REPO}/contents/{path}"
    content = base64.b64encode(image_bytes).decode()

    # fetch existing file SHA so we can update rather than error on duplicate
    sha = None
    r = _req.get(api_url, params={"access_token": token}, timeout=20)
    if r.status_code == 200:
        data = r.json()
        sha = data.get("sha") if isinstance(data, dict) else None

    payload = {
        "access_token": token,
        "message": f"ci: auto-generate build image {filename}",
        "content": content,
        "branch": _GITEE_BRANCH,
    }
    if sha:
        payload["sha"] = sha
        r = _req.put(api_url, json=payload, timeout=30)
    else:
        r = _req.post(api_url, json=payload, timeout=30)

    r.raise_for_status()
    return f"{_GITEE_RAW_PREFIX}{filename}"


def _gitee_delete_image(card_image_url: str | None, build_id: int) -> None:
    """Best-effort deletion of a build image from the Gitee asset repo.
    Silently logs and returns on any failure - never raises."""
    if not card_image_url or not card_image_url.startswith(_GITEE_RAW_PREFIX):
        return  # nothing to delete (no image, dry-run prefix, error sentinel, etc.)

    from config import GITEE_TOKEN, GITEE_DRY_RUN

    if not GITEE_TOKEN or GITEE_DRY_RUN:
        return

    import requests as _req

    filename = card_image_url.removeprefix(_GITEE_RAW_PREFIX).split("?", 1)[0]
    path = f"{_GITEE_FOLDER}/{filename}"
    api_url = f"{_GITEE_API}/repos/{_GITEE_OWNER}/{_GITEE_REPO}/contents/{path}"

    try:
        r = _req.get(api_url, params={"access_token": GITEE_TOKEN}, timeout=20)
        if r.status_code == 404:
            return  # already gone
        r.raise_for_status()
        sha = r.json().get("sha")
        if not sha:
            _logger.error("gitee-delete: no SHA returned for build %s image %s", build_id, filename)
            return

        r = _req.delete(
            api_url,
            json={
                "access_token": GITEE_TOKEN,
                "message": f"ci: remove build image for deleted build {build_id}",
                "sha": sha,
                "branch": _GITEE_BRANCH,
            },
            timeout=30,
        )
        r.raise_for_status()
        _logger.warning("gitee-delete: removed image %s for build %s", filename, build_id)
    except Exception as exc:
        _logger.error("gitee-delete: failed to delete image for build %s: %s", build_id, exc)


def _gitee_wipe_build_images_folder() -> int:
    """Delete every file in the build-images folder via the Contents API.
    Returns the number of images deleted, or -1 on error."""
    from config import GITEE_TOKEN, GITEE_DRY_RUN

    if not GITEE_TOKEN or GITEE_DRY_RUN:
        return 0

    import requests as _req

    tok = {"access_token": GITEE_TOKEN}

    try:
        # list all files in the build-images folder (Gitee Contents API)
        r = _req.get(
            f"{_GITEE_API}/repos/{_GITEE_OWNER}/{_GITEE_REPO}/contents/{_GITEE_FOLDER}",
            params={**tok, "ref": _GITEE_BRANCH},
            timeout=30,
        )
        if r.status_code == 404:
            return 0
        r.raise_for_status()

        entries = r.json()
        if not isinstance(entries, list):
            return 0

        file_entries = [e for e in entries if e.get("type") == "file"]
        deleted = 0
        for entry in file_entries:
            dr = _req.delete(
                f"{_GITEE_API}/repos/{_GITEE_OWNER}/{_GITEE_REPO}/contents/{entry['path']}",
                params=tok,
                json={
                    "message": "ci: wipe all build images",
                    "sha": entry["sha"],
                    "branch": _GITEE_BRANCH,
                },
                timeout=30,
            )
            if dr.ok:
                deleted += 1
            else:
                _logger.warning("gitee: failed to delete %s: %s", entry["path"], dr.text)

        _logger.warning("gitee: wiped build-images folder (%d files)", deleted)
        return deleted

    except Exception as exc:
        _logger.error("gitee: wipe build-images folder failed: %s", exc)
        return -1


_MAX_AVATAR_BYTES = 2 * 1024 * 1024  # 2 MB raw limit before processing
_AVATAR_RENDER_SIZE = 128  # output square dimension in pixels


def _process_and_upload_avatar(image_bytes: bytes, ip_hash: str) -> str:
    """Decode, resize to 128x128 JPEG, upload to Gitee. Returns the raw URL."""
    from PIL import Image
    import io
    from config import GITEE_TOKEN

    try:
        img = Image.open(io.BytesIO(image_bytes))
    except Exception:
        raise ValueError("Invalid image data - could not decode.")

    if img.format not in ("JPEG", "PNG", "WEBP", "GIF"):
        raise ValueError("Unsupported image format. Use JPEG, PNG, or WebP.")

    img = img.convert("RGB")
    img.thumbnail((_AVATAR_RENDER_SIZE, _AVATAR_RENDER_SIZE), Image.LANCZOS)

    # crop to square from center
    w, h = img.size
    side = min(w, h)
    left = (w - side) // 2
    top = (h - side) // 2
    img = img.crop((left, top, left + side, top + side))

    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=85, optimize=True)
    jpeg_bytes = buf.getvalue()

    filename = f"avatar_{ip_hash[:20]}.jpg"
    path = f"{_GITEE_AVATAR_FOLDER}/{filename}"
    api_url = f"{_GITEE_API}/repos/{_GITEE_OWNER}/{_GITEE_REPO}/contents/{path}"
    content = base64.b64encode(jpeg_bytes).decode()

    import requests as _req

    sha = None
    r = _req.get(api_url, params={"access_token": GITEE_TOKEN}, timeout=20)
    if r.status_code == 200:
        data = r.json()
        sha = data.get("sha") if isinstance(data, dict) else None

    payload = {
        "access_token": GITEE_TOKEN,
        "message": f"ci: avatar upload for {ip_hash[:8]}",
        "content": content,
        "branch": _GITEE_BRANCH,
    }
    if sha:
        payload["sha"] = sha
        r = _req.put(api_url, json=payload, timeout=30)
    else:
        r = _req.post(api_url, json=payload, timeout=30)

    r.raise_for_status()
    return f"{_GITEE_AVATAR_PREFIX}{filename}"


def _sanitize_username(raw: str) -> str:
    return " ".join(_strip_html_tags(raw).split())[:30]


def _validate_avatar_url(url: str | None) -> str | None:
    if not url:
        return None
    if not url.startswith(_GITEE_AVATAR_PREFIX):
        raise ValueError("avatar_url must point to the EFTForge asset repository.")
    return url


# Marks a build whose card waits for Kitbash! to draw every part. Unlike the
# "error:" marker it clears itself on the next worker start, since a restart is
# when a newer Kitbash! with more sprites gets loaded.
_CARD_WAITING_PARTS = "wait:kitbash-parts"


def _public_card_url(url: str | None) -> str | None:
    # Hide the migration worker's markers ("error:", "wait:", "dryrun:") from
    # clients, which would otherwise try to load them as image URLs.
    return url if url and url.startswith(("https://", "http://")) else None


def _mark_card_waiting(build_id: int) -> None:
    with BuildsSessionLocal() as db:
        b = db.get(PublicBuild, build_id)
        if b and not (b.card_image_url or "").startswith(_GITEE_RAW_PREFIX):
            b.card_image_url = _CARD_WAITING_PARTS
            db.commit()


def _generate_and_save_build_image(build_id: int, gun_id: str, pairs: list) -> str:
    """Synchronous helper: draws a card image for a single community build with
    Kitbash!, uploads it to Gitee, and saves the URL to the DB.
    Returns "saved", "incomplete" when Kitbash! cannot draw the weapon or every
    part yet (the build is then marked with _CARD_WAITING_PARTS), or "failed" on
    any other failure.
    Safe to call from a thread (BackgroundTasks or run_in_executor)."""
    from config import GITEE_TOKEN, GITEE_DRY_RUN

    if not GITEE_TOKEN and not GITEE_DRY_RUN:
        return "failed"
    # Checked up front so a Kitbash! that failed to load isn't mistaken for a
    # build it cannot draw.
    if not build_images.loaded():
        _logger.error("build-image: Kitbash! is not installed or failed to load, cannot draw build %s", build_id)
        return "failed"
    try:
        items = _build_spt_items(gun_id, pairs)
        image_bytes, skipped = build_images.render_webp(build_image_key(gun_id, items), items)
    except ValueError as exc:
        _logger.error("build-image: invalid build tree for build %s: %s", build_id, exc)
        return "failed"
    except build_images.Unrenderable as exc:
        # A newer Kitbash! may draw it, so wait rather than fail for good.
        _logger.warning("build-image Kitbash! cannot draw build %s yet: %s", build_id, exc)
        _mark_card_waiting(build_id)
        return "incomplete"
    if skipped:
        # A stored card outlives the missing sprite, so wait until Kitbash! has every part.
        _logger.warning("build-image Kitbash! cannot draw %s in build %s yet", skipped, build_id)
        _mark_card_waiting(build_id)
        return "incomplete"
    return "saved" if _save_build_card(build_id, image_bytes, "webp") else "failed"


def _save_build_card(build_id: int, image_bytes: bytes, ext: str) -> bool:
    """Uploads a card image to Gitee and saves its URL on the build."""
    from config import GITEE_TOKEN, GITEE_DRY_RUN

    content_type = f"image/{'jpeg' if ext == 'jpg' else ext}"
    filename = f"build_{build_id}.{ext}"

    if GITEE_DRY_RUN:
        dry_url = f"dryrun:{_GITEE_RAW_PREFIX}{filename}"
        _logger.warning(
            "build-image [DRY RUN]: build %s - %d bytes (%s) - would upload to %s",
            build_id,
            len(image_bytes),
            content_type,
            dry_url.removeprefix("dryrun:"),
        )
        with BuildsSessionLocal() as db:
            b = db.get(PublicBuild, build_id)
            if b:
                b.card_image_url = dry_url
                db.commit()
        return True

    try:
        raw_url = _gitee_upload_sync(filename, image_bytes, GITEE_TOKEN)
    except Exception as exc:
        _logger.error("build-image Gitee upload failed for build %s: %s", build_id, exc)
        return False

    with BuildsSessionLocal() as db:
        b = db.get(PublicBuild, build_id)
        if b:
            # version-stamp the URL so a regenerated image is a distinct cache entry
            # instead of colliding with whatever browsers cached under the old timestamp
            b.card_image_url = f"{raw_url}?v={int(time.time())}"
            db.commit()

    _logger.warning("build-image saved for build %s -> %s", build_id, raw_url)
    return True


async def _bg_migrate_build_images(force: bool = False):
    """Continuously draws and uploads card images for every community build
    that doesn't yet have one stored in our own asset repo."""
    from config import GITEE_TOKEN, GITEE_DRY_RUN, DISABLE_BG_MIGRATE

    if DISABLE_BG_MIGRATE and not force:
        _logger.warning("bg-migrate: disabled via DISABLE_BG_MIGRATE - skipping")
        return

    if not GITEE_TOKEN and not GITEE_DRY_RUN:
        _logger.warning("bg-migrate: GITEE_TOKEN not set - build image migration disabled")
        return

    if GITEE_DRY_RUN:
        _logger.warning("bg-migrate: dry-run mode enabled - no files will be uploaded to Gitee")

    # let the server fully settle before starting
    await asyncio.sleep(15)

    # Without a working Kitbash! every attempt fails, and we'd mark every
    # pending build errored one by one, so don't start at all.
    if not await asyncio.to_thread(build_images.loaded):
        _logger.error("bg-migrate: Kitbash! is not installed or failed to load - build image migration disabled")
        return

    # This worker may have loaded a newer Kitbash!, so give builds that were
    # waiting on parts another try.
    with BuildsSessionLocal() as db:
        requeued = (
            db.query(PublicBuild)
            .filter(PublicBuild.card_image_url == _CARD_WAITING_PARTS)
            .update({"card_image_url": None}, synchronize_session=False)
        )
        db.commit()
    if requeued:
        _logger.warning("bg-migrate: requeued %s build(s) that were waiting on Kitbash! parts", requeued)

    _logger.warning("bg-migrate: build image migration worker started")
    loop = asyncio.get_event_loop()
    build_id = None

    while True:
        try:
            # find the next build that hasn't been auto-migrated yet;
            # featured builds are prioritised so they look good first;
            # rows marked with the error sentinel are skipped until manually cleared
            with BuildsSessionLocal() as db:
                build = (
                    db.query(PublicBuild)
                    .filter(
                        (PublicBuild.card_image_url == None)  # noqa: E711
                        | (
                            ~PublicBuild.card_image_url.like(_GITEE_RAW_PREFIX + "%")
                            & ~PublicBuild.card_image_url.like("error:%")
                            & ~PublicBuild.card_image_url.like("wait:%")
                            & ~PublicBuild.card_image_url.like("dryrun:%")
                        )
                    )
                    .order_by(PublicBuild.is_featured.desc(), PublicBuild.id.asc())
                    .first()
                )
                if build is None:
                    _logger.warning("bg-migrate: all builds have auto-generated images, worker exiting")
                    break

                build_id = build.id
                gun_id = build.gun_id
                gun_name = build.gun_name
                pairs = json.loads(build.pairs_json)

            captured_id, captured_gun_id, captured_pairs = (build_id, gun_id, pairs)
            result = "failed"
            for attempt in range(1, 4):
                _logger.warning(
                    "bg-migrate: generating image for build %s (%s) - attempt %s/3",
                    build_id,
                    gun_name,
                    attempt,
                )
                result = await loop.run_in_executor(
                    None,
                    lambda: _generate_and_save_build_image(captured_id, captured_gun_id, captured_pairs),
                )
                # Missing parts stay missing until a newer Kitbash! loads, so retrying is pointless.
                if result != "failed":
                    break
                if attempt < 3:
                    _logger.warning("bg-migrate: attempt %s failed for build %s, retrying in 10s", attempt, build_id)
                    await asyncio.sleep(10)

            if result == "incomplete":
                # _generate_and_save_build_image already marked it waiting.
                _logger.warning("bg-migrate: build %s waits for Kitbash! to draw every part", build_id)
                await asyncio.sleep(3)
                continue
            if result == "failed":
                _logger.error("bg-migrate: all 3 attempts failed for build %s, marking as errored", build_id)
                with BuildsSessionLocal() as db:
                    b = db.get(PublicBuild, build_id)
                    if b and not (b.card_image_url or "").startswith(_GITEE_RAW_PREFIX):
                        b.card_image_url = "error:gen-failed"
                        db.commit()
                await asyncio.sleep(10)
                continue

            # brief pause after each success so real requests can jump in
            await asyncio.sleep(3)

        except Exception as exc:
            _logger.error("bg-migrate: error on build %s: %s", build_id or "?", exc, exc_info=True)
            await asyncio.sleep(30)  # back off before retrying


_bg_migrate_task: asyncio.Task | None = None
_bg_sync_task: asyncio.Task | None = None


async def _run_sync_once() -> bool:
    """Run sync_tarkov_dev.py in a thread pool so the event loop stays unblocked."""
    global _sync_running, _last_sync_at
    if _sync_running:
        _logger.info("Hyperactive sync skipped - previous run still in progress.")
        return False
    _sync_running = True
    try:
        open(_SYNC_IN_PROGRESS_FILE, "w").close()  # broadcast to all workers
        sync_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sync_tarkov_dev.py")
        loop = asyncio.get_event_loop()
        ret = await loop.run_in_executor(
            None,
            lambda: subprocess.run([sys.executable, sync_script], timeout=600).returncode,
        )
        if ret == 0:
            _last_sync_at = time.time()
            _clear_solver_caches()
            _logger.info("Hyperactive sync completed.")
            return True
        _logger.error("Hyperactive sync exited with code %s.", ret)
        return False
    except Exception as exc:
        _logger.error("Hyperactive sync failed: %s", exc)
        return False
    finally:
        _sync_running = False
        if os.path.exists(_SYNC_IN_PROGRESS_FILE):
            os.remove(_SYNC_IN_PROGRESS_FILE)


async def _bg_hyperactive_sync():
    """Background loop: while hyperactive mode is on, re-sync every 30 minutes.
    Triggers an immediate sync as soon as the mode is enabled."""
    while True:
        if not _hyperactive_mode:
            # Idle - wait indefinitely until the admin enables the mode.
            await _sync_trigger.wait()
            _sync_trigger.clear()
            continue
        # Hyperactive mode is active: sync now, then wait the interval.
        await _run_sync_once()
        try:
            await asyncio.wait_for(
                _sync_trigger.wait(),
                timeout=float(_SYNC_INTERVAL_HYPERACTIVE_SECS),
            )
            _sync_trigger.clear()
        except asyncio.TimeoutError:
            pass
        # Loop back - if mode was disabled while waiting, the next iteration idles.


@app.on_event("startup")
async def _on_startup():
    global _bg_migrate_task, _bg_sync_task
    # Remove a stale in-progress lock left by a previous crash.
    if os.path.exists(_SYNC_IN_PROGRESS_FILE):
        os.remove(_SYNC_IN_PROGRESS_FILE)
    _bg_migrate_task = asyncio.create_task(_bg_migrate_build_images())
    _bg_sync_task = asyncio.create_task(_bg_hyperactive_sync())


@app.post("/admin/builds/retrigger-migrate")
async def admin_retrigger_migrate(
    request: Request,
    x_admin_key: str = Header(None),
):
    global _bg_migrate_task
    _require_admin(request, x_admin_key)
    if _bg_migrate_task and not _bg_migrate_task.done():
        return {"status": "already_running"}
    _bg_migrate_task = asyncio.create_task(_bg_migrate_build_images(force=True))
    return {"status": "started"}


# ---------------------------------------------------
# Admin - Hyperactive Sync Mode
# ---------------------------------------------------


@app.get("/admin/hyperactive-mode")
def admin_get_hyperactive_mode(
    request: Request,
    x_admin_key: str = Header(None),
):
    _require_admin(request, x_admin_key)
    return {
        "hyperactive_mode": _hyperactive_mode,
        "sync_running": _sync_running,
        "last_sync_at": _last_sync_at,
        "sync_interval_seconds": _SYNC_INTERVAL_HYPERACTIVE_SECS,
    }


@app.post("/admin/hyperactive-mode")
async def admin_set_hyperactive_mode(
    request: Request,
    enabled: bool = Body(...),
    x_admin_key: str = Header(None),
):
    global _hyperactive_mode
    _require_admin(request, x_admin_key)
    _hyperactive_mode = enabled
    if enabled:
        open(_HYPERACTIVE_LOCK_FILE, "w").close()
        _sync_trigger.set()  # wake the background loop for an immediate sync
    else:
        if os.path.exists(_HYPERACTIVE_LOCK_FILE):
            os.remove(_HYPERACTIVE_LOCK_FILE)
        _sync_trigger.set()  # wake the background loop so it sees mode=False
    return {"hyperactive_mode": enabled}


@app.get("/admin/imggen-disabled")
def admin_get_imggen_disabled(
    request: Request,
    x_admin_key: str = Header(None),
):
    _require_admin(request, x_admin_key)
    return {"imggen_disabled": _imggen_disabled}


@app.post("/admin/imggen-disabled")
def admin_set_imggen_disabled(
    request: Request,
    disabled: bool = Body(...),
    x_admin_key: str = Header(None),
):
    global _imggen_disabled
    _require_admin(request, x_admin_key)
    _imggen_disabled = disabled
    if disabled:
        open(_IMGGEN_DISABLED_LOCK_FILE, "w").close()
    else:
        if os.path.exists(_IMGGEN_DISABLED_LOCK_FILE):
            os.remove(_IMGGEN_DISABLED_LOCK_FILE)
    return {"imggen_disabled": disabled}


# ---------------------------------------------------
# User Profile
# ---------------------------------------------------


@app.post("/profile/avatar")
def upload_avatar(
    request: Request,
    x_client_id: str = Header(None),
    image_b64: str = Body(...),
    mime_type: str = Body("image/jpeg"),
    db: Session = Depends(get_builds_db),
):
    from config import GITEE_TOKEN, GITEE_DRY_RUN

    client_hash = _get_client_id_hash(x_client_id)
    _check_client_ban(client_hash, db)

    now_mono = time.monotonic()
    stale = [k for k, v in _avatar_last.items() if now_mono - v > _AVATAR_COOLDOWN * 2]
    for k in stale:
        del _avatar_last[k]
    if now_mono - _avatar_last.get(client_hash, 0.0) < _AVATAR_COOLDOWN:
        wait = int(_AVATAR_COOLDOWN - (now_mono - _avatar_last[client_hash])) + 1
        raise HTTPException(status_code=429, detail=f"Please wait {wait}s before uploading another avatar.")

    if not GITEE_TOKEN and not GITEE_DRY_RUN:
        raise HTTPException(status_code=503, detail="Avatar upload is not configured on this server.")

    try:
        raw_bytes = base64.b64decode(image_b64)
    except Exception:
        raise HTTPException(status_code=422, detail="Invalid base64 image data.")

    if len(raw_bytes) > _MAX_AVATAR_BYTES:
        raise HTTPException(status_code=413, detail="Avatar image must be under 2 MB.")

    if GITEE_DRY_RUN:
        _avatar_last[client_hash] = now_mono
        dry_url = f"{_GITEE_AVATAR_PREFIX}avatar_{client_hash[:20]}.jpg"
        return {"avatar_url": dry_url}

    try:
        avatar_url = _process_and_upload_avatar(raw_bytes, client_hash)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        _logger.error("avatar-upload: failed for client %s: %s", client_hash[:8], exc)
        raise HTTPException(status_code=502, detail="Avatar upload to asset storage failed.")

    _avatar_last[client_hash] = now_mono
    return {"avatar_url": avatar_url}


@app.post("/profile/update")
def update_profile(
    x_client_id: str = Header(None),
    username: str | None = Body(default=None, max_length=30),
    avatar_url: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    client_hash = _get_client_id_hash(x_client_id)

    now_mono = time.monotonic()
    stale = [k for k, v in _username_last.items() if now_mono - v > _USERNAME_COOLDOWN * 2]
    for k in stale:
        del _username_last[k]
    if now_mono - _username_last.get(client_hash, 0.0) < _USERNAME_COOLDOWN:
        wait = int(_USERNAME_COOLDOWN - (now_mono - _username_last[client_hash])) + 1
        raise HTTPException(status_code=429, detail=f"Please wait {wait}s before updating your profile again.")

    clean_name = _sanitize_username(username) if username else None
    try:
        clean_avatar = _validate_avatar_url(avatar_url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    builds = db.query(PublicBuild).filter(PublicBuild.ip_hash == client_hash, PublicBuild.is_admin_build == False).all()
    for b in builds:
        b.user_display_name = clean_name or None
        b.user_avatar_url = clean_avatar or None

    comments = db.query(BuildComment).filter(BuildComment.ip_hash == client_hash).all()
    for c in comments:
        c.user_display_name = clean_name or None
        c.user_avatar_url = clean_avatar or None

    db.commit()
    _username_last[client_hash] = now_mono
    return {"updated_builds": len(builds), "updated_comments": len(comments)}


@app.post("/profile/transfer/preview")
def transfer_preview(
    x_client_id: str = Header(None),
    old_uuid: str = Body(..., embed=True),
    db: Session = Depends(get_builds_db),
):
    current_hash = _get_client_id_hash(x_client_id)
    old_uuid_clean = old_uuid.strip().lower()

    if not _CLIENT_ID_RE.match(old_uuid_clean):
        raise HTTPException(status_code=400, detail="Invalid UUID format.")
    if old_uuid_clean == x_client_id.strip().lower():
        raise HTTPException(status_code=400, detail="That is your current UUID.")

    old_hash = hmac.new(IP_HASH_SECRET.encode(), old_uuid_clean.encode(), hashlib.sha256).hexdigest()

    old_builds = (
        db.query(PublicBuild).filter(PublicBuild.ip_hash == old_hash, PublicBuild.is_admin_build == False).count()
    )
    old_comments = db.query(BuildComment).filter(BuildComment.ip_hash == old_hash).count()
    cur_builds = (
        db.query(PublicBuild).filter(PublicBuild.ip_hash == current_hash, PublicBuild.is_admin_build == False).count()
    )
    cur_comments = db.query(BuildComment).filter(BuildComment.ip_hash == current_hash).count()

    return {
        "old_builds": old_builds,
        "old_comments": old_comments,
        "cur_builds": cur_builds,
        "cur_comments": cur_comments,
    }


@app.post("/profile/transfer")
def transfer_account(
    x_client_id: str = Header(None),
    old_uuid: str = Body(..., embed=True),
    username: str | None = Body(default=None, max_length=30),
    avatar_url: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    current_hash = _get_client_id_hash(x_client_id)

    now_mono = time.monotonic()
    stale = [k for k, v in _transfer_last.items() if now_mono - v > _TRANSFER_COOLDOWN * 2]
    for k in stale:
        del _transfer_last[k]
    if now_mono - _transfer_last.get(current_hash, 0.0) < _TRANSFER_COOLDOWN:
        remaining = int(_TRANSFER_COOLDOWN - (now_mono - _transfer_last[current_hash]))
        raise HTTPException(status_code=429, detail=f"Rate limit: wait {remaining}s before transferring again.")

    old_uuid_clean = old_uuid.strip().lower()
    if not _CLIENT_ID_RE.match(old_uuid_clean):
        raise HTTPException(status_code=400, detail="Invalid UUID format.")
    if old_uuid_clean == x_client_id.strip().lower():
        raise HTTPException(status_code=400, detail="That is your current UUID.")

    old_hash = hmac.new(IP_HASH_SECRET.encode(), old_uuid_clean.encode(), hashlib.sha256).hexdigest()

    transferred_builds = (
        db.query(PublicBuild)
        .filter(PublicBuild.ip_hash == old_hash, PublicBuild.is_admin_build == False)
        .update({"ip_hash": current_hash}, synchronize_session=False)
    )

    transferred_comments = (
        db.query(BuildComment)
        .filter(BuildComment.ip_hash == old_hash)
        .update({"ip_hash": current_hash}, synchronize_session=False)
    )

    # Apply the current account's profile to all records now under current_hash
    clean_name = _sanitize_username(username) if username else None
    try:
        clean_avatar = _validate_avatar_url(avatar_url)
    except ValueError:
        clean_avatar = None

    db.query(PublicBuild).filter(PublicBuild.ip_hash == current_hash, PublicBuild.is_admin_build == False).update(
        {"user_display_name": clean_name, "user_avatar_url": clean_avatar}, synchronize_session=False
    )

    db.query(BuildComment).filter(BuildComment.ip_hash == current_hash).update(
        {"user_display_name": clean_name, "user_avatar_url": clean_avatar}, synchronize_session=False
    )

    db.commit()
    _transfer_last[current_hash] = now_mono

    return {"transferred_builds": transferred_builds, "transferred_comments": transferred_comments}


# ---------------------------------------------------
# Public Builds
# ---------------------------------------------------


@app.post("/builds/publish")
def publish_build(
    request: Request,
    background_tasks: BackgroundTasks,
    x_client_id: str = Header(None),
    gun_id: str = Body(...),
    build_name: str = Body(..., max_length=60),
    pairs: List[list] = Body(...),
    stats: dict | None = Body(default=None),
    ammo_id: str | None = Body(default=None),
    author_username: str | None = Body(default=None, max_length=30),
    author_avatar_url: str | None = Body(default=None),
    tags: List[str] | None = Body(default=None),
    db: Session = Depends(get_builds_db),
    db_main: Session = Depends(get_db),
):
    client_hash = _get_client_id_hash(x_client_id)

    # rate limit: one publish per 60 seconds per client
    now_mono = time.monotonic()
    # evict stale entries (older than 2x cooldown) to prevent unbounded growth
    stale = [k for k, t in _publish_last.items() if now_mono - t > _PUBLISH_COOLDOWN * 2]
    for k in stale:
        del _publish_last[k]
    last = _publish_last.get(client_hash, 0.0)
    if now_mono - last < _PUBLISH_COOLDOWN:
        remaining = int(_PUBLISH_COOLDOWN - (now_mono - last))
        raise HTTPException(status_code=429, detail=f"Rate limit: wait {remaining}s before publishing again.")

    _check_client_ban(client_hash, db)

    # validate gun exists
    gun = db_main.query(Item).filter(Item.id == gun_id, Item.is_weapon == True).first()
    if not gun:
        raise HTTPException(status_code=422, detail="Unknown gun_id.")

    # sanitize build name
    name = _sanitize_build_name(build_name)[:60]
    if not name:
        raise HTTPException(status_code=422, detail="build_name cannot be empty.")

    # sanitize user profile fields
    u_name = _sanitize_username(author_username) if author_username else None
    try:
        u_avatar = _validate_avatar_url(author_avatar_url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    # validate pairs format: each must be [str, str]
    if not isinstance(pairs, list):
        raise HTTPException(status_code=422, detail="pairs must be an array.")
    if len(pairs) > 200:
        raise HTTPException(status_code=422, detail="Too many pairs (max 200).")
    for p in pairs:
        if not (isinstance(p, list) and len(p) == 2 and isinstance(p[0], str) and isinstance(p[1], str)):
            raise HTTPException(status_code=422, detail="Each pair must be [slot_id, item_id].")

    _validate_pairs(pairs, db_main)

    # reject if gun already has 500 community builds
    _COMMUNITY_BUILDS_LIMIT = 500
    existing_count = db.query(PublicBuild).filter(PublicBuild.gun_id == gun_id).count()
    if existing_count >= _COMMUNITY_BUILDS_LIMIT:
        raise HTTPException(status_code=409, detail="community_builds_limit_reached")

    # compute total price: gun + all attachments
    all_ids = [gun_id] + [p[1] for p in pairs]
    price_rows = db_main.query(Item.id, Item.trader_price_rub).filter(Item.id.in_(all_ids)).all()
    total_price = sum(r[1] or 0 for r in price_rows) or None

    _ALLOWED_TAGS = {"meta", "budget", "cqb", "sniper", "recoil", "ergo", "pve", "beginner", "hybrid"}
    clean_tags = [t for t in (tags or []) if t in _ALLOWED_TAGS][:5]

    # stats is stored verbatim and echoed back to every client - cap its size
    stats_serialized = json.dumps(stats) if stats else None
    if stats_serialized and len(stats_serialized) > MAX_STATS_JSON_CHARS:
        raise HTTPException(status_code=422, detail="stats payload too large.")

    build = PublicBuild(
        gun_id=gun_id,
        gun_name=gun.name,
        build_name=name,
        pairs_json=json.dumps(pairs),
        ip_hash=client_hash,
        ip_snapshot=_get_client_ip(request),
        author_id=None,
        is_admin_build=False,
        stats_json=stats_serialized,
        user_display_name=u_name or None,
        user_avatar_url=u_avatar or None,
        total_price_rub=total_price,
        ammo_id=ammo_id or None,
        tags_json=json.dumps(clean_tags) if clean_tags else None,
    )
    db.add(build)
    db.commit()
    db.refresh(build)

    _publish_last[client_hash] = now_mono

    # kick off image generation in the background - response returns immediately
    background_tasks.add_task(
        _generate_and_save_build_image,
        build.id,
        gun_id,
        pairs,
    )

    return {"id": build.id, "published_at": build.published_at.isoformat()}


@app.get("/builds/mine")
def get_my_builds(
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    if not x_client_id:
        return []
    client_hash = _get_client_id_hash(x_client_id)

    rows = (
        db.query(PublicBuild)
        .filter(PublicBuild.ip_hash == client_hash)
        .order_by(PublicBuild.published_at.desc())
        .limit(100)
        .all()
    )
    if not rows:
        return []

    build_ids = [b.id for b in rows]

    count_rows = (
        db.query(BuildComment.build_id, func.count(BuildComment.id))
        .filter(BuildComment.build_id.in_(build_ids), BuildComment.is_deleted == False)
        .group_by(BuildComment.build_id)
        .all()
    )
    comment_counts = {bid: cnt for bid, cnt in count_rows}

    rating_rows = db.query(BuildRating).filter(BuildRating.build_id.in_(build_ids)).all()
    like_counts = {r.build_id: r.like_count for r in rating_rows}

    return [
        {
            "id": b.id,
            "gun_id": b.gun_id,
            "gun_name": b.gun_name,
            "build_name": b.build_name,
            "user_display_name": b.user_display_name,
            "user_avatar_url": b.user_avatar_url,
            "is_admin_build": False,
            "is_featured": b.is_featured,
            "published_at": b.published_at.isoformat(),
            "is_mine": True,
            "pairs": _safe_json_loads(b.pairs_json),
            "stats": _safe_json_loads(b.stats_json),
            "load_count": b.load_count or 0,
            "like_count": like_counts.get(b.id, 0),
            "comment_count": comment_counts.get(b.id, 0),
            "card_image_url": _public_card_url(b.card_image_url),
            "ammo_id": b.ammo_id,
            "tags": _safe_json_loads(b.tags_json) or [],
        }
        for b in rows
    ]


@app.get("/builds/public")
def get_public_builds(
    gun_id: str,
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    if _community_builds_disabled:
        raise HTTPException(status_code=503, detail="community_builds_disabled")

    client_hash = _get_optional_client_id_hash(x_client_id)

    rows = (
        db.query(PublicBuild, PublicBuildAuthor)
        .outerjoin(PublicBuildAuthor, PublicBuild.author_id == PublicBuildAuthor.id)
        .filter(PublicBuild.gun_id == gun_id)
        .order_by(PublicBuild.is_featured.desc(), PublicBuild.published_at.desc())
        .limit(500)
        .all()
    )

    build_ids = [b.id for b, _ in rows]
    comment_counts: dict[int, int] = {}
    if build_ids:
        count_rows = (
            db.query(BuildComment.build_id, func.count(BuildComment.id))
            .filter(BuildComment.build_id.in_(build_ids), BuildComment.is_deleted == False)
            .group_by(BuildComment.build_id)
            .all()
        )
        comment_counts = {bid: cnt for bid, cnt in count_rows}

    return [
        {
            "id": build.id,
            "gun_id": build.gun_id,
            "build_name": build.build_name,
            "author_display_name": author.display_name if author else None,
            "author_display_name_zh": author.display_name_zh if author else None,
            "author_avatar_url": author.avatar_url if author else None,
            "user_display_name": build.user_display_name,
            "user_avatar_url": build.user_avatar_url,
            "is_admin_build": build.is_admin_build,
            "is_featured": build.is_featured,
            "published_at": build.published_at.isoformat(),
            "is_mine": (client_hash is not None and build.ip_hash == client_hash),
            "pairs": _safe_json_loads(build.pairs_json),
            "stats": _safe_json_loads(build.stats_json),
            "total_price_rub": build.total_price_rub,
            "load_count": build.load_count or 0,
            "card_image_url": _public_card_url(build.card_image_url),
            "ammo_id": build.ammo_id,
            "tags": _safe_json_loads(build.tags_json) or [],
            "comment_count": comment_counts.get(build.id, 0),
        }
        for build, author in rows
    ]


# load-count cooldown: (client_ip, build_id) -> monotonic time of last counted load
_load_count_last: dict[tuple[str, int], float] = {}
_LOAD_COUNT_COOLDOWN = 60.0


@app.post("/builds/{build_id}/load")
def record_build_load(
    build_id: int,
    request: Request,
    db: Session = Depends(get_builds_db),
):
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")

    # Count at most one load per IP per build per cooldown window to deter
    # load-count inflation. Repeat loads still succeed, they just don't count.
    key = (_get_client_ip(request), build_id)
    now_mono = time.monotonic()
    stale = [k for k, ts in _load_count_last.items() if now_mono - ts > _LOAD_COUNT_COOLDOWN * 2]
    for k in stale:
        del _load_count_last[k]
    if now_mono - _load_count_last.get(key, 0.0) >= _LOAD_COUNT_COOLDOWN:
        build.load_count = (build.load_count or 0) + 1
        db.commit()
        _load_count_last[key] = now_mono
    return {"load_count": build.load_count}


@app.delete("/builds/{build_id}")
def unlist_build(
    build_id: int,
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    client_hash = _get_client_id_hash(x_client_id)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    if build.ip_hash != client_hash:
        raise HTTPException(status_code=403, detail="Not your build.")
    card_image_url = build.card_image_url
    db.delete(build)
    db.commit()
    _gitee_delete_image(card_image_url, build_id)
    return {"unlisted": True, "build_id": build_id}


@app.get("/builds/notifications")
def get_notifications(
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    client_hash = _get_client_id_hash(x_client_id)

    notes = (
        db.query(PendingNotification)
        .filter(
            PendingNotification.ip_hash == client_hash,
            PendingNotification.delivered == False,
        )
        .all()
    )

    result = []
    for note in notes:
        result.append(
            {
                "type": note.type,
                "data": json.loads(note.data_json),
            }
        )
        note.delivered = True

    db.commit()
    return result


@app.get("/builds/ban-status")
def get_ban_status(x_client_id: str = Header(None), db: Session = Depends(get_builds_db)):
    client_hash = _get_optional_client_id_hash(x_client_id)
    if not client_hash:
        return {"is_banned": False, "banned_until": None}
    ban = db.query(IPBan).filter(IPBan.ip_hash == client_hash).first()
    if not ban:
        return {"is_banned": False, "banned_until": None}
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    if ban.banned_until is not None and ban.banned_until <= now:
        return {"is_banned": False, "banned_until": None}
    return {
        "is_banned": True,
        "banned_until": ban.banned_until.isoformat() + "Z" if ban.banned_until else None,
        "reason": ban.reason,
    }


# ---------------------------------------------------
# Admin - Builds
# ---------------------------------------------------


@app.post("/admin/builds/publish")
def admin_publish_build(
    request: Request,
    x_admin_key: str = Header(None),
    gun_id: str = Body(...),
    build_name: str = Body(..., max_length=60),
    pairs: List[list] = Body(...),
    author_id: str | None = Body(default=None),
    stats: dict | None = Body(default=None),
    card_image_url: str | None = Body(default=None),
    ammo_id: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
    db_main: Session = Depends(get_db),
):
    _require_admin(request, x_admin_key)

    gun = db_main.query(Item).filter(Item.id == gun_id, Item.is_weapon == True).first()
    if not gun:
        raise HTTPException(status_code=422, detail="Unknown gun_id.")

    name = _sanitize_build_name(build_name)[:60]
    if not name:
        raise HTTPException(status_code=422, detail="build_name cannot be empty.")

    if author_id is not None:
        if not db.query(PublicBuildAuthor).filter(PublicBuildAuthor.id == author_id).first():
            raise HTTPException(status_code=422, detail="author_id not found.")

    if not isinstance(pairs, list):
        raise HTTPException(status_code=422, detail="pairs must be an array.")
    for p in pairs:
        if not (isinstance(p, list) and len(p) == 2 and isinstance(p[0], str) and isinstance(p[1], str)):
            raise HTTPException(status_code=422, detail="Each pair must be [slot_id, item_id].")

    _validate_pairs(pairs, db_main)

    all_ids = [gun_id] + [p[1] for p in pairs]
    price_rows = db_main.query(Item.id, Item.trader_price_rub).filter(Item.id.in_(all_ids)).all()
    total_price = sum(r[1] or 0 for r in price_rows) or None

    build = PublicBuild(
        gun_id=gun_id,
        gun_name=gun.name,
        build_name=name,
        pairs_json=json.dumps(pairs),
        ip_hash="admin",
        ip_snapshot=None,
        author_id=author_id,
        is_admin_build=True,
        is_featured=True,
        stats_json=json.dumps(stats) if stats else None,
        total_price_rub=total_price,
        card_image_url=card_image_url,
        ammo_id=ammo_id or None,
    )
    db.add(build)
    db.commit()
    db.refresh(build)
    return {"id": build.id, "published_at": build.published_at.isoformat()}


@app.post("/admin/builds/{build_id}/feature")
def admin_feature_build(
    build_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    card_image_url: str | None = Body(default=None),
    author_id: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    if author_id is not None:
        if not db.query(PublicBuildAuthor).filter(PublicBuildAuthor.id == author_id).first():
            raise HTTPException(status_code=422, detail="author_id not found.")
    build.is_featured = True
    if card_image_url is not None:
        build.card_image_url = card_image_url
    if author_id is not None:
        build.author_id = author_id
    db.commit()
    return {"id": build.id, "is_featured": True, "card_image_url": build.card_image_url, "author_id": build.author_id}


@app.post("/admin/builds/{build_id}/unfeature")
def admin_unfeature_build(
    build_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    build.is_featured = False
    if build.is_admin_build:
        build.card_image_url = None
        build.author_id = None
    db.commit()
    return {"id": build.id, "is_featured": False}


@app.get("/admin/builds/featured")
def admin_list_featured_builds(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    rows = (
        db.query(PublicBuild, PublicBuildAuthor, BuildRating)
        .outerjoin(PublicBuildAuthor, PublicBuild.author_id == PublicBuildAuthor.id)
        .outerjoin(BuildRating, BuildRating.build_id == PublicBuild.id)
        .filter(PublicBuild.is_featured == True)
        .order_by(PublicBuild.is_rotating.desc(), PublicBuild.published_at.desc())
        .all()
    )
    return [
        {
            "id": b.id,
            "gun_id": b.gun_id,
            "gun_name": b.gun_name,
            "build_name": b.build_name,
            "author_id": b.author_id,
            "author_name": a.display_name if a else None,
            "published_at": b.published_at.isoformat(),
            "is_admin_build": b.is_admin_build,
            "is_rotating": b.is_rotating,
            "like_count": r.like_count if r else 0,
        }
        for b, a, r in rows
    ]


@app.post("/admin/builds/rotate-featured")
def admin_rotate_featured_builds(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)

    # unfeature all builds currently in the rotation batch
    outgoing = db.query(PublicBuild).filter(PublicBuild.is_rotating == True).all()
    for b in outgoing:
        b.is_featured = False
        b.is_rotating = False

    two_weeks_ago = datetime.now(timezone.utc) - timedelta(weeks=2)

    # top 10 most-liked community builds by votes cast in the last 2 weeks
    already_featured_ids = {row[0] for row in db.query(PublicBuild.id).filter(PublicBuild.is_featured == True).all()}
    candidates = (
        db.query(PublicBuild, func.count(BuildVote.id).label("recent_likes"))
        .join(BuildVote, BuildVote.build_id == PublicBuild.id)
        .filter(
            BuildVote.created_at >= two_weeks_ago,
            BuildVote.vote == "like",
        )
        .group_by(PublicBuild.id)
        .order_by(func.count(BuildVote.id).desc())
        .limit(10 + len(already_featured_ids))  # over-fetch to skip already-featured
        .all()
    )

    incoming = []
    for build, like_count in candidates:
        if build.id in already_featured_ids:
            continue
        build.is_featured = True
        build.is_rotating = True
        incoming.append({"id": build.id, "build_name": build.build_name, "like_count": like_count})
        if len(incoming) == 10:
            break

    db.commit()
    return {
        "unfeatured": [{"id": b.id, "build_name": b.build_name} for b in outgoing],
        "featured": incoming,
    }


@app.post("/admin/builds/{build_id}/card-image")
def admin_set_card_image(
    build_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    card_image_url: str | None = Body(default=None, embed=True),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    build.card_image_url = card_image_url
    db.commit()
    return {"id": build.id, "card_image_url": build.card_image_url}


@app.post("/admin/builds/{build_id}/author")
def admin_set_build_author(
    build_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    author_id: str | None = Body(default=..., embed=True),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    if author_id is not None:
        if not db.query(PublicBuildAuthor).filter(PublicBuildAuthor.id == author_id).first():
            raise HTTPException(status_code=422, detail="author_id not found.")
    build.author_id = author_id
    db.commit()
    return {"id": build.id, "author_id": build.author_id}


@app.delete("/admin/builds/{build_id}")
def admin_delete_build(
    build_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")

    owner_hash = build.ip_hash
    build_name = build.build_name
    card_image_url = build.card_image_url
    db.delete(build)

    # notify the owner (skip for admin-published builds)
    if owner_hash != "admin":
        db.add(
            PendingNotification(
                ip_hash=owner_hash,
                type="unlist",
                data_json=json.dumps({"build_name": build_name}),
            )
        )

    db.commit()
    _gitee_delete_image(card_image_url, build_id)
    return {"deleted": True, "build_id": build_id, "ip_hash": owner_hash}


@app.get("/admin/migration/status")
def admin_migration_status(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    from config import GITEE_TOKEN, GITEE_DRY_RUN, DISABLE_BG_MIGRATE

    total = db.query(PublicBuild).count()
    migrated = db.query(PublicBuild).filter(PublicBuild.card_image_url.like(_GITEE_RAW_PREFIX + "%")).count()
    errored = db.query(PublicBuild).filter(PublicBuild.card_image_url.like("error:%")).count()
    dry_run_count = db.query(PublicBuild).filter(PublicBuild.card_image_url.like("dryrun:%")).count()
    waiting_parts = db.query(PublicBuild).filter(PublicBuild.card_image_url == _CARD_WAITING_PARTS).count()
    pending = total - migrated - errored - dry_run_count - waiting_parts

    return {
        "total": total,
        "migrated": migrated,
        "pending": pending,
        "errored": errored,
        # Retried on the next restart, once Kitbash! may draw every part.
        "waiting_parts": waiting_parts,
        "dry_run_processed": dry_run_count,
        "worker_disabled": DISABLE_BG_MIGRATE,
        "dry_run": GITEE_DRY_RUN,
        "token_set": bool(GITEE_TOKEN),
        "complete": pending == 0 and errored == 0 and waiting_parts == 0,
    }


@app.post("/admin/migration/reset")
def admin_migration_reset(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    """Clears ALL auto-generated card image URLs so the migration worker
    re-processes every build from scratch on the next server restart."""
    _require_admin(request, x_admin_key)
    count = (
        db.query(PublicBuild)
        .filter(
            PublicBuild.card_image_url.like(_GITEE_RAW_PREFIX + "%")
            | PublicBuild.card_image_url.like("error:%")
            | PublicBuild.card_image_url.like("wait:%")
            | PublicBuild.card_image_url.like("dryrun:%")
        )
        .update({"card_image_url": None}, synchronize_session=False)
    )
    db.commit()
    return {"reset": count}


@app.post("/admin/migration/clear-errors")
def admin_migration_clear_errors(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    count = (
        db.query(PublicBuild)
        .filter(PublicBuild.card_image_url.like("error:%") | PublicBuild.card_image_url.like("dryrun:%"))
        .update({"card_image_url": None}, synchronize_session=False)
    )
    db.commit()
    return {"cleared": count}


@app.post("/admin/migration/regenerate-image/{build_id}")
def admin_migration_regenerate_image(
    build_id: int,
    request: Request,
    background_tasks: BackgroundTasks,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    """Force-regenerate the card image for a single build.
    Bypasses DISABLE_BG_MIGRATE - always runs regardless of env config."""
    _require_admin(request, x_admin_key)
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    pairs = json.loads(build.pairs_json)
    build.card_image_url = None
    db.commit()
    background_tasks.add_task(
        _generate_and_save_build_image,
        build.id,
        build.gun_id,
        pairs,
    )
    return {"queued": True, "id": build_id}


# A file, like the solve locks, so two Gunicorn workers can't run the same batch.
# A run that died mid-batch leaves it behind, so it goes stale after an hour.
_CARD_REGEN_LOCK_FILE = os.path.join(RUNTIME_DIR, "card_regen.lock")
_CARD_REGEN_LOCK_STALE_SECONDS = 3600


def _acquire_card_regen_lock() -> bool:
    for _ in range(2):  # 2nd pass only runs after clearing a stale lock
        try:
            os.close(os.open(_CARD_REGEN_LOCK_FILE, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            return True
        except FileExistsError:
            try:
                stale = time.time() - os.path.getmtime(_CARD_REGEN_LOCK_FILE) > _CARD_REGEN_LOCK_STALE_SECONDS
            except OSError:
                continue
            if not stale:
                return False
            try:
                os.remove(_CARD_REGEN_LOCK_FILE)
            except OSError:
                pass
    return False


def _regenerate_cards(build_ids: list[int]) -> None:
    """Redraws each build's card in turn, holding the batch lock until done."""
    counts = {"saved": 0, "incomplete": 0, "failed": 0}
    try:
        for build_id in build_ids:
            with BuildsSessionLocal() as db:
                build = db.get(PublicBuild, build_id)
                # Skip builds deleted, or given a card some other way, since the batch was queued.
                if not build or (build.card_image_url or "").startswith(_GITEE_RAW_PREFIX):
                    continue
                gun_id, pairs = build.gun_id, _safe_json_loads(build.pairs_json) or []
            try:
                result = _generate_and_save_build_image(build_id, gun_id, pairs)
            except Exception as exc:
                _logger.error("card-regen: build %s raised: %s", build_id, exc, exc_info=True)
                result = "failed"
            counts[result] += 1
            # A failure keeps whatever marker the build had, so the next batch retries it.
    finally:
        try:
            os.remove(_CARD_REGEN_LOCK_FILE)
        except OSError:
            pass
    _logger.warning(
        "card-regen: done - %s saved, %s still waiting on Kitbash!, %s failed",
        counts["saved"],
        counts["incomplete"],
        counts["failed"],
    )


@app.post("/admin/migration/regenerate-unsupported")
def admin_migration_regenerate_unsupported(
    request: Request,
    background_tasks: BackgroundTasks,
    include_errors: bool = False,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    """Redraw every community build card Kitbash! couldn't draw before (a weapon
    or parts it had no sprites for), after pulling a newer Kitbash! and
    restarting the server, since each worker loads Kitbash! once.
    include_errors also retries builds marked "error:" (upload failures and
    the like). Bypasses DISABLE_BG_MIGRATE. Progress: waiting_parts in
    /admin/migration/status counts down as cards are saved."""
    _require_admin(request, x_admin_key)
    from config import GITEE_TOKEN, GITEE_DRY_RUN

    if not GITEE_TOKEN and not GITEE_DRY_RUN:
        raise HTTPException(status_code=503, detail="GITEE_TOKEN is not set.")
    if not build_images.loaded():
        raise HTTPException(status_code=503, detail="Kitbash! is not installed or failed to load.")

    marked = PublicBuild.card_image_url == _CARD_WAITING_PARTS
    if include_errors:
        marked = marked | PublicBuild.card_image_url.like("error:%")
    build_ids = [
        row.id
        for row in db.query(PublicBuild.id).filter(marked).order_by(PublicBuild.is_featured.desc(), PublicBuild.id)
    ]
    if not build_ids:
        return {"queued": 0, "kitbash": build_images.version()}
    if not _acquire_card_regen_lock():
        raise HTTPException(status_code=409, detail="A card regeneration batch is already running.")
    background_tasks.add_task(_regenerate_cards, build_ids)
    return {"queued": len(build_ids), "kitbash": build_images.version()}


@app.post("/admin/builds/wipe-all")
def admin_wipe_all_builds(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    """Delete every community build from the DB and wipe the Gitee build-images folder."""
    _require_admin(request, x_admin_key)

    count = db.query(PublicBuild).count()

    db.query(PendingNotification).delete(synchronize_session=False)
    db.query(BuildVote).delete(synchronize_session=False)
    db.query(BuildRating).delete(synchronize_session=False)
    db.query(BuildComment).delete(synchronize_session=False)
    db.query(PublicBuild).delete(synchronize_session=False)
    db.commit()

    deleted_images = _gitee_wipe_build_images_folder()

    return {"deleted_builds": count, "deleted_images": deleted_images}


# ---------------------------------------------------
# Build Comments
# ---------------------------------------------------


@app.get("/builds/{build_id}/comments")
def get_build_comments(
    build_id: int,
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")
    client_hash = _get_optional_client_id_hash(x_client_id)
    rows = (
        db.query(BuildComment)
        .filter(BuildComment.build_id == build_id, BuildComment.is_deleted == False)
        .order_by(BuildComment.created_at.asc())
        .limit(100)
        .all()
    )
    return [
        {
            "id": r.id,
            "content": r.content,
            "created_at": r.created_at.isoformat(),
            "is_mine": (client_hash is not None and r.ip_hash == client_hash),
            "user_display_name": r.user_display_name,
            "user_avatar_url": r.user_avatar_url,
        }
        for r in rows
    ]


@app.post("/builds/{build_id}/comments")
def post_build_comment(
    build_id: int,
    request: Request,
    x_client_id: str = Header(None),
    content: str = Body(..., max_length=280),
    user_display_name: str | None = Body(default=None, max_length=30),
    user_avatar_url: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    build = db.query(PublicBuild).filter(PublicBuild.id == build_id).first()
    if not build:
        raise HTTPException(status_code=404, detail="Build not found.")

    client_hash = _get_client_id_hash(x_client_id)
    _check_client_ban(client_hash, db)

    # Rate limit: 1 comment per 2 minutes
    now = time.monotonic()
    last = _comment_last.get(client_hash)
    if last is not None and now - last < _COMMENT_COOLDOWN:
        wait = int(_COMMENT_COOLDOWN - (now - last)) + 1
        raise HTTPException(status_code=429, detail=f"Please wait {wait}s before posting another comment.")

    cleaned = _strip_html_tags(content).strip()
    if not cleaned:
        raise HTTPException(status_code=422, detail="Comment cannot be empty.")
    if len(cleaned) > 280:
        raise HTTPException(status_code=422, detail="Comment exceeds 280 characters.")

    c_name = _sanitize_username(user_display_name) if user_display_name else None
    try:
        c_avatar = _validate_avatar_url(user_avatar_url)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    comment = BuildComment(
        build_id=build_id,
        ip_hash=client_hash,
        content=cleaned,
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        user_display_name=c_name or None,
        user_avatar_url=c_avatar or None,
    )
    db.add(comment)
    db.flush()

    if build.ip_hash and client_hash != build.ip_hash:
        db.add(
            PendingNotification(
                ip_hash=build.ip_hash,
                type="new_comment",
                data_json=json.dumps({"build_id": build_id, "build_name": build.build_name}),
                created_at=datetime.now(timezone.utc).replace(tzinfo=None),
                delivered=False,
            )
        )

    db.commit()
    db.refresh(comment)

    _comment_last[client_hash] = now
    return {
        "id": comment.id,
        "content": comment.content,
        "created_at": comment.created_at.isoformat(),
        "is_mine": True,
        "user_display_name": comment.user_display_name,
        "user_avatar_url": comment.user_avatar_url,
    }


@app.delete("/builds/{build_id}/comments/{comment_id}")
def delete_own_comment(
    build_id: int,
    comment_id: int,
    x_client_id: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    client_hash = _get_client_id_hash(x_client_id)
    comment = (
        db.query(BuildComment)
        .filter(
            BuildComment.id == comment_id,
            BuildComment.build_id == build_id,
        )
        .first()
    )
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found.")
    if comment.is_deleted:
        raise HTTPException(status_code=404, detail="Comment not found.")
    if comment.ip_hash != client_hash:
        raise HTTPException(status_code=403, detail="You can only delete your own comments.")
    comment.is_deleted = True
    db.commit()
    return {"deleted": True, "id": comment_id}


@app.delete("/admin/builds/comments/{comment_id}")
def admin_delete_comment(
    comment_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    comment = db.query(BuildComment).filter(BuildComment.id == comment_id).first()
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found.")
    comment.is_deleted = True
    db.commit()
    return {"deleted": True, "id": comment_id}


@app.get("/admin/builds/comments")
def admin_list_builds_with_comments(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    rows = (
        db.query(BuildComment, PublicBuild)
        .join(PublicBuild, BuildComment.build_id == PublicBuild.id)
        .filter(BuildComment.is_deleted == False)
        .order_by(BuildComment.created_at.desc())
        .all()
    )
    builds: dict[int, dict] = {}
    for comment, build in rows:
        if build.id not in builds:
            builds[build.id] = {
                "build_id": build.id,
                "build_name": build.build_name,
                "gun_name": build.gun_name,
                "published_at": build.published_at.isoformat(),
                "comments": [],
            }
        builds[build.id]["comments"].append(
            {
                "id": comment.id,
                "content": comment.content,
                "created_at": comment.created_at.isoformat(),
            }
        )
    result = list(builds.values())
    for entry in result:
        entry["comment_count"] = len(entry["comments"])
    return result


@app.get("/admin/builds")
def admin_list_builds(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    rows = db.query(PublicBuild).order_by(PublicBuild.published_at.desc()).all()
    return [
        {
            "id": b.id,
            "gun_id": b.gun_id,
            "gun_name": b.gun_name,
            "build_name": b.build_name,
            "author_id": b.author_id,
            "ip_hash": b.ip_hash,
            "ip_snapshot": b.ip_snapshot,
            "is_admin_build": b.is_admin_build,
            "published_at": b.published_at.isoformat(),
        }
        for b in rows
    ]


# ---------------------------------------------------
# Leaderboard
# ---------------------------------------------------


def _dense_rank(scores):
    """Return dense ranks for a descending-sorted list of scores.
    Tied scores share the same rank with no gaps: [50,50,50,30] -> [1,1,1,2]."""
    ranks = []
    rank = 0
    for i, score in enumerate(scores):
        if i == 0 or score != scores[i - 1]:
            rank += 1
        ranks.append(rank)
    return ranks


def _build_row_to_dict(rank, build, author, like_count):
    return {
        "rank": rank,
        "build_id": build.id,
        "build_name": build.build_name,
        "gun_id": build.gun_id,
        "gun_name": build.gun_name,
        "author_display_name": author.display_name if author else None,
        "author_display_name_zh": author.display_name_zh if author else None,
        "author_avatar_url": author.avatar_url if author else None,
        "user_display_name": build.user_display_name,
        "user_avatar_url": build.user_avatar_url,
        "like_count": like_count,
        "is_admin_build": build.is_admin_build,
        "is_featured": build.is_featured,
        "pairs": _safe_json_loads(build.pairs_json),
        "stats": _safe_json_loads(build.stats_json),
        "total_price_rub": build.total_price_rub,
        "card_image_url": _public_card_url(build.card_image_url),
        "ammo_id": build.ammo_id,
    }


@app.get("/leaderboard/builds")
def get_leaderboard_builds(
    period: str = "2w",
    db: Session = Depends(get_builds_db),
):
    if period not in ("2w", "all"):
        raise HTTPException(status_code=400, detail='period must be "2w" or "all"')

    if period == "2w":
        two_weeks_ago = datetime.now(timezone.utc) - timedelta(weeks=2)
        rows = (
            db.query(PublicBuild, PublicBuildAuthor, func.count(BuildVote.id).label("trending_likes"))
            .join(BuildVote, BuildVote.build_id == PublicBuild.id)
            .outerjoin(PublicBuildAuthor, PublicBuild.author_id == PublicBuildAuthor.id)
            .filter(BuildVote.created_at >= two_weeks_ago, BuildVote.vote == "like")
            .group_by(PublicBuild.id)
            .order_by(func.count(BuildVote.id).desc())
            .limit(10)
            .all()
        )
        counts = [count for _, _, count in rows]
        ranks = _dense_rank(counts)
        return [_build_row_to_dict(ranks[i], build, author, count) for i, (build, author, count) in enumerate(rows)]
    else:
        rows = (
            db.query(PublicBuild, PublicBuildAuthor, BuildRating)
            .outerjoin(BuildRating, BuildRating.build_id == PublicBuild.id)
            .outerjoin(PublicBuildAuthor, PublicBuild.author_id == PublicBuildAuthor.id)
            .filter(BuildRating.like_count > 0)
            .order_by(BuildRating.like_count.desc())
            .limit(50)
            .all()
        )
        counts = [rating.like_count if rating else 0 for _, _, rating in rows]
        ranks = _dense_rank(counts)
        return [_build_row_to_dict(ranks[i], build, author, counts[i]) for i, (build, author, _) in enumerate(rows)]


@app.get("/leaderboard/attachments")
def get_leaderboard_attachments(
    period: str = "2w",
    sort: str = "likes",
    db: Session = Depends(get_ratings_db),
    db_main: Session = Depends(get_db),
):
    if period not in ("2w", "all"):
        raise HTTPException(status_code=400, detail='period must be "2w" or "all"')
    if sort not in ("likes", "dislikes"):
        raise HTTPException(status_code=400, detail='sort must be "likes" or "dislikes"')

    likes_label = func.sum(case((AttachmentVote.vote == "like", 1), else_=0))
    dislikes_label = func.sum(case((AttachmentVote.vote == "dislike", 1), else_=0))

    if period == "2w":
        two_weeks_ago = datetime.now(timezone.utc) - timedelta(weeks=2)
        order_expr = likes_label if sort == "likes" else dislikes_label
        rows = (
            db.query(
                AttachmentVote.item_id,
                likes_label.label("likes"),
                dislikes_label.label("dislikes"),
            )
            .filter(AttachmentVote.created_at >= two_weeks_ago)
            .group_by(AttachmentVote.item_id)
            .having(order_expr > 0)
            .order_by(order_expr.desc())
            .limit(20)
            .all()
        )
    else:
        order_col = AttachmentRating.like_count if sort == "likes" else AttachmentRating.dislike_count
        rows = (
            db.query(
                AttachmentRating.item_id,
                AttachmentRating.like_count.label("likes"),
                AttachmentRating.dislike_count.label("dislikes"),
            )
            .filter(order_col > 0)
            .order_by(order_col.desc())
            .limit(100)
            .all()
        )

    item_ids = [row.item_id for row in rows]
    items_map = {item.id: item for item in db_main.query(Item).filter(Item.id.in_(item_ids)).all()} if item_ids else {}

    # resolve most common slot_name for each item as its category
    category_map: dict[str, str] = {}
    if item_ids:
        slot_rows = (
            db_main.query(SlotAllowedItem.allowed_item_id, Slot.slot_name, func.count(SlotAllowedItem.id).label("cnt"))
            .join(Slot, Slot.id == SlotAllowedItem.slot_id)
            .filter(SlotAllowedItem.allowed_item_id.in_(item_ids))
            .group_by(SlotAllowedItem.allowed_item_id, Slot.slot_name)
            .all()
        )
        # keep highest count slot_name per item
        for item_id, slot_name, cnt in slot_rows:
            if item_id not in category_map or cnt > category_map.get("__cnt__" + item_id, 0):
                category_map[item_id] = slot_name
                category_map["__cnt__" + item_id] = cnt

    scores = [row.likes if sort == "likes" else row.dislikes for row in rows]
    ranks = _dense_rank(scores)

    return [
        {
            "rank": ranks[i],
            "item_id": row.item_id,
            "item_name": items_map[row.item_id].name if row.item_id in items_map else row.item_id,
            "item_name_zh": items_map[row.item_id].name_zh if row.item_id in items_map else None,
            "icon_link": items_map[row.item_id].icon_link if row.item_id in items_map else None,
            "like_count": row.likes,
            "dislike_count": row.dislikes,
            "item_category": category_map.get(row.item_id, None),
        }
        for i, row in enumerate(rows)
    ]


def _changelog_items(db: Session, item_ids) -> dict:
    # Look up the changelog's items that the tracker still shows: weapons, ammo and
    # anything that fits a slot. Items since removed from the game drop out here.
    item_ids = list(item_ids)
    if not item_ids:
        return {}
    items_map = {item.id: item for item in db.query(Item).filter(Item.id.in_(item_ids)).all()}
    attachment_ids = {
        row[0]
        for row in db.query(SlotAllowedItem.allowed_item_id)
        .filter(SlotAllowedItem.allowed_item_id.in_(item_ids))
        .distinct()
        .all()
    }
    return {
        item_id: item
        for item_id, item in items_map.items()
        if item.is_weapon or item.is_ammo or item_id in attachment_ids
    }


@app.get("/stat-changelog/dates")
def get_stat_changelog_dates(
    db: Session = Depends(get_db),
    changelog_db: Session = Depends(get_changelog_db),
):
    # Every UTC day that logged a change, newest first, with how many tracked items
    # changed that day. The tracker's history picker lists these.
    pairs = changelog_db.query(func.date(StatChangeLog.detected_at), StatChangeLog.item_id).distinct().all()
    tracked = _changelog_items(db, {item_id for _, item_id in pairs})
    counts = {}
    for day, item_id in pairs:
        if day and item_id in tracked:
            counts[day] = counts.get(day, 0) + 1
    return [{"date": day, "item_count": counts[day]} for day in sorted(counts, reverse=True)]


@app.get("/stat-changelog")
def get_stat_changelog(
    date: str | None = None,
    db: Session = Depends(get_db),
    changelog_db: Session = Depends(get_changelog_db),
):
    # With no date we serve the rolling recent window the tracker opens on (and older
    # clients still expect); with a YYYY-MM-DD date we serve that one UTC day from the
    # full history, which is never pruned.
    query = changelog_db.query(StatChangeLog)
    if date is None:
        query = query.filter(StatChangeLog.detected_at >= datetime.now(timezone.utc) - timedelta(days=8))
    else:
        try:
            day_start = datetime.strptime(date, "%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=422, detail="date must be YYYY-MM-DD")
        query = query.filter(
            StatChangeLog.detected_at >= day_start,
            StatChangeLog.detected_at < day_start + timedelta(days=1),
        )
    rows = query.order_by(StatChangeLog.detected_at.desc()).all()

    items_map = _changelog_items(db, {r.item_id for r in rows})
    return [
        {
            "item_id": row.item_id,
            "item_name": item.name,
            "item_name_zh": item.name_zh,
            "icon_link": item.icon_link,
            "is_weapon": item.is_weapon,
            "is_ammo": item.is_ammo,
            "stat_name": row.stat_name,
            "old_value": row.old_value,
            "new_value": row.new_value,
            "detected_at": row.detected_at.isoformat() if row.detected_at else None,
        }
        for row in rows
        if (item := items_map.get(row.item_id)) is not None
    ]


# ---------------------------------------------------
# Admin - Bans
# ---------------------------------------------------


@app.post("/admin/bans")
def admin_create_ban(
    request: Request,
    x_admin_key: str = Header(None),
    client_id_hash: str = Body(...),
    duration_hours: int | None = Body(default=None),
    reason: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)

    banned_until = None
    if duration_hours is not None:
        banned_until = datetime.now(timezone.utc) + timedelta(hours=duration_hours)

    existing = db.query(IPBan).filter(IPBan.ip_hash == client_id_hash).first()
    if existing:
        existing.banned_at = datetime.now(timezone.utc)
        existing.banned_until = banned_until
        existing.reason = reason
    else:
        db.add(IPBan(ip_hash=client_id_hash, banned_until=banned_until, reason=reason))

    # notify the banned client
    db.add(
        PendingNotification(
            ip_hash=client_id_hash,
            type="ban",
            data_json=json.dumps(
                {
                    "banned_until": banned_until.replace(tzinfo=None).isoformat() + "Z" if banned_until else None,
                    "reason": reason,
                }
            ),
        )
    )

    db.commit()
    return {"banned": True, "client_id_hash": client_id_hash}


@app.delete("/admin/bans/{client_id_hash}")
def admin_delete_ban(
    client_id_hash: str,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    deleted = db.query(IPBan).filter(IPBan.ip_hash == client_id_hash).delete()
    if deleted:
        db.add(
            PendingNotification(
                ip_hash=client_id_hash,
                type="unban",
                data_json=json.dumps({}),
            )
        )
    db.commit()
    return {"unbanned": True, "client_id_hash": client_id_hash}


@app.get("/admin/bans")
def admin_list_bans(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    bans = db.query(IPBan).all()
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    return [
        {
            "ip_hash": b.ip_hash,
            "banned_at": b.banned_at.isoformat(),
            "banned_until": b.banned_until.isoformat() + "Z" if b.banned_until else None,
            "is_active": b.banned_until is None or b.banned_until > now,
            "reason": b.reason,
        }
        for b in bans
    ]


# ---------------------------------------------------
# Admin - Authors
# ---------------------------------------------------


@app.post("/admin/authors")
def admin_upsert_author(
    request: Request,
    x_admin_key: str = Header(None),
    id: str = Body(...),
    display_name: str = Body(...),
    avatar_url: str | None = Body(default=None),
    display_name_zh: str | None = Body(default=None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    existing = db.query(PublicBuildAuthor).filter(PublicBuildAuthor.id == id).first()
    if existing:
        existing.display_name = display_name
        existing.avatar_url = avatar_url
        existing.display_name_zh = display_name_zh
    else:
        db.add(
            PublicBuildAuthor(
                id=id,
                display_name=display_name,
                avatar_url=avatar_url,
                display_name_zh=display_name_zh,
            )
        )
    db.commit()
    return {"ok": True, "id": id}


@app.delete("/admin/authors/{author_id}")
def admin_delete_author(
    author_id: str,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    author = db.query(PublicBuildAuthor).filter(PublicBuildAuthor.id == author_id).first()
    if not author:
        raise HTTPException(status_code=404, detail="Author not found.")
    db.query(PublicBuild).filter(PublicBuild.author_id == author_id).update({"author_id": None})
    db.delete(author)
    db.commit()
    return {"ok": True, "id": author_id}


@app.post("/admin/community-builds/disable")
def admin_disable_community_builds(request: Request, x_admin_key: str = Header(None)):
    global _community_builds_disabled
    _require_admin(request, x_admin_key)
    _community_builds_disabled = True
    open(_COMMUNITY_BUILDS_LOCK_FILE, "w").close()
    return {"community_builds_enabled": False}


@app.post("/admin/community-builds/enable")
def admin_enable_community_builds(request: Request, x_admin_key: str = Header(None)):
    global _community_builds_disabled
    _require_admin(request, x_admin_key)
    _community_builds_disabled = False
    if os.path.exists(_COMMUNITY_BUILDS_LOCK_FILE):
        os.remove(_COMMUNITY_BUILDS_LOCK_FILE)
    return {"community_builds_enabled": True}


@app.get("/admin/community-builds/status")
def admin_community_builds_status(request: Request, x_admin_key: str = Header(None)):
    _require_admin(request, x_admin_key)
    return {"community_builds_enabled": not _community_builds_disabled}


@app.get("/announcements")
def get_announcements(db: Session = Depends(get_builds_db)):
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    rows = (
        db.query(ServerAnnouncement)
        .filter((ServerAnnouncement.expires_at == None) | (ServerAnnouncement.expires_at > now))  # noqa: E711
        .order_by(ServerAnnouncement.created_at.desc())
        .all()
    )
    return [
        {
            "id": r.id,
            "message": r.message,
            "level": r.level,
            "created_at": r.created_at.isoformat(),
            "expires_at": r.expires_at.isoformat() if r.expires_at else None,
            "dismissible": r.dismissible,
        }
        for r in rows
    ]


# ---------------------------------------------------
# Admin - Announcements
# ---------------------------------------------------

_ANNOUNCEMENT_LEVEL_COLORS = {
    "info": "#4a90d9",
    "success": "#4CAF50",
    "warning": "#f5a623",
    "error": "#e74c3c",
    "critical": "#9b59b6",
}


@app.post("/admin/announcements")
def admin_create_announcement(
    request: Request,
    x_admin_key: str = Header(None),
    message: str = Body(...),
    level: Literal["info", "success", "warning", "error", "critical"] = Body(
        default="info",
        description=(
            "Toast accent color per level: "
            "info=#4a90d9 (blue), "
            "success=#4CAF50 (green), "
            "warning=#f5a623 (orange), "
            "error=#e74c3c (red, stays until dismissed), "
            "critical=#9b59b6 (purple, stays until dismissed)"
        ),
    ),
    expires_in_hours: int | None = Body(default=None),
    dismissible: bool = Body(
        default=True,
        description="When false, the toast cannot be dismissed by clicking - user must wait for it to expire or for an admin to delete it. Use for critical notices that must not be accidentally cleared.",
    ),
    db: Session = Depends(get_builds_db),
):
    """
    Post a toast announcement to all active users.

    **Choosing a level:**
    - **info** (blue) - Neutral updates: new content, features, patch notes, reminders.
    - **success** (green) - Positive news: a fix shipped, a requested feature landed, downtime resolved.
    - **warning** (orange) - Action advised: upcoming maintenance, known issue to watch out for, degraded service.
    - **error** (red) - Something is broken right now that affects users. Toast stays until dismissed.
    - **critical** (purple) - Urgent and severe: data loss risk, security issue, immediate action required. Toast stays until dismissed.

    **expires_in_hours:** leave null for a permanent announcement; set a value (e.g. 2) for time-sensitive ones that should auto-expire.

    **dismissible:** set to false to prevent users from clicking the toast away - useful for critical alerts you need everyone to see.
    """
    _require_admin(request, x_admin_key)
    expires_at = None
    if expires_in_hours is not None:
        expires_at = datetime.now(timezone.utc) + timedelta(hours=expires_in_hours)
    row = ServerAnnouncement(message=message, level=level, expires_at=expires_at, dismissible=dismissible)
    db.add(row)
    db.commit()
    db.refresh(row)
    return {
        "id": row.id,
        "message": row.message,
        "level": row.level,
        "created_at": row.created_at.isoformat(),
        "expires_at": row.expires_at.isoformat() if row.expires_at else None,
        "dismissible": row.dismissible,
    }


@app.delete("/admin/announcements/{announcement_id}")
def admin_delete_announcement(
    announcement_id: int,
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    deleted = db.query(ServerAnnouncement).filter(ServerAnnouncement.id == announcement_id).delete()
    db.commit()
    if not deleted:
        raise HTTPException(status_code=404, detail="Announcement not found.")
    return {"deleted": True, "id": announcement_id}


@app.get("/admin/announcements")
def admin_list_announcements(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    rows = db.query(ServerAnnouncement).order_by(ServerAnnouncement.created_at.desc()).all()
    return [
        {
            "id": r.id,
            "message": r.message,
            "level": r.level,
            "created_at": r.created_at.isoformat(),
            "expires_at": r.expires_at.isoformat() if r.expires_at else None,
            "is_active": r.expires_at is None or r.expires_at > now,
            "dismissible": r.dismissible,
        }
        for r in rows
    ]


@app.get("/admin/authors")
def admin_list_authors(
    request: Request,
    x_admin_key: str = Header(None),
    db: Session = Depends(get_builds_db),
):
    _require_admin(request, x_admin_key)
    authors = db.query(PublicBuildAuthor).all()
    return [
        {
            "id": a.id,
            "display_name": a.display_name,
            "display_name_zh": a.display_name_zh,
            "avatar_url": a.avatar_url,
        }
        for a in authors
    ]


# ---------------------------------------------------
# Desktop app mode - must stay at the very bottom: the static-frontend mount
# it registers is a catch-all, so every API route has to be defined first.
# ---------------------------------------------------

if DESKTOP_MODE:
    from desktop import init_desktop

    def _desktop_clear_caches():
        _clear_solver_caches()

    init_desktop(app, clear_caches=_desktop_clear_caches)
